
<div class="input-group m-t-10">
    <input type="email" id="bfiltro" name="bfiltro" class="form-control" placeholder="Ingrese Titulo o Autor a buscar...">
    <span class="input-group-btn">
    <button type="button" class="btn waves-effect waves-light btn-primary" onclick="buscarBiblio()">Buscar</button>
    </span>
</div>
<br>
<div id="contenido"><div class="panel-body"><div id="listacon"></div></div></div>