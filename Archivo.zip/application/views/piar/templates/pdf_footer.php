<div style="text-align: center; font-size: 12px;">
    V14.16/02/2018. - Ver documento de instrucciones. Ministerio de Educación Nacional – Viceministerio de Educación Preescolar, Básica y Media – Decreto 1421 de 2017
</div>