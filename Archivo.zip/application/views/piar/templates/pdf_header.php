<table class="text-center">
    <tr>
        <td style="border: 0;">
            <img class="logo-img" src="<?= base_url() ?>img/min_educacion.png" alt="Min Educación">
        </td>
        <td style="border: 0; vertical-align: middle">
            <img style="height: 34px" src="<?= base_url() ?>img/gobierno_colombia.png" alt="Min Educación">
        </td>
        <td class="text-content" style="width: 130px; vertical-align: middle">
            <p>PIAR<br>Decreto 1421/2017</p>
        </td>
    </tr>
</table>