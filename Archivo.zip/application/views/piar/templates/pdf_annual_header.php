<table class="text-center" style="border: 0;">
    <tr style="border: 0">
        <td style="border: 0 !important; text-align: center">
            <img width="310px"  class="logo-img" src="<?= base_url() ?>img/gobernacion_quindio.png" alt="Min Educación">
        </td>
    </tr>
</table>