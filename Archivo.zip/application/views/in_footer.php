<footer class="footer text-right">
    <label><?= date("Y") ?> © Plataforma Virtual Educativa - IntegraTIC v4.0&nbsp; &nbsp;</label>
    <button type="button" class="btn btn-primary waves-effect btn-sm m-b-5" onclick="creditos();">Créditos</button>
</footer>
<script>
    $( document ).ready(function() {
        actualizar_notificaciones();
    });
</script>