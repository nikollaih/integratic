<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-08-06 09:35:31 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-06 09:35:31 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-06 09:35:31 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-06 09:35:31 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-06 09:35:31 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-08-06 09:35:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 09:35:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 09:35:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 09:35:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 09:35:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 09:35:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 09:35:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 09:35:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 09:35:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 09:35:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 09:35:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 09:35:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 09:35:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 09:35:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 09:35:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 09:35:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 09:35:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 09:35:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 09:35:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 09:35:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 09:35:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 09:35:34 --> 404 Page Not Found: Images/small
ERROR - 2024-08-06 09:35:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 09:35:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 09:35:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 09:35:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 09:35:37 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 70
ERROR - 2024-08-06 09:41:22 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:41:22 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:41:37 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:41:37 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:42:25 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:42:25 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:43:48 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:43:48 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:43:54 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:43:54 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:44:21 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:44:21 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:45:17 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:45:17 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:45:32 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:45:32 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:45:36 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:45:36 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:45:58 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:45:58 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:49:42 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:49:42 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:49:58 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:49:58 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:50:47 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:50:47 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:51:33 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:51:33 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:51:44 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:51:44 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:52:30 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:52:30 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:52:45 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:52:46 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:53:04 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:53:04 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:53:18 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:53:18 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:57:39 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:57:39 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:57:53 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:57:53 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:57:58 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:57:58 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:58:26 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:58:26 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:58:56 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:58:57 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:59:00 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:59:00 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:59:13 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:59:13 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:59:30 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:59:30 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:59:39 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:59:39 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:59:46 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:59:46 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 09:59:54 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 09:59:54 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 10:01:41 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-06 10:01:41 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-06 10:01:41 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-06 10:01:41 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-06 10:01:42 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-08-06 10:01:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 10:01:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 10:01:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 10:01:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 10:01:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 10:01:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 10:01:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 10:01:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 10:01:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 10:01:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 10:01:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 10:01:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 10:01:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 10:01:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 10:01:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 10:01:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 10:01:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 10:01:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 10:01:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 10:01:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 10:01:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 10:01:43 --> 404 Page Not Found: Images/small
ERROR - 2024-08-06 10:01:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 10:01:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 10:01:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 10:01:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 10:01:52 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.cm.codmateria' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT *
FROM `cfg_areas` `ca`
JOIN `cfg_materias` `cm` ON `ca`.`codarea` = `cm`.`area`
JOIN `asg_materias` `am` ON `am`.`materia` = `cm`.`codmateria`
WHERE `am`.`docente` = '12345'
GROUP BY `ca`.`codarea`
ERROR - 2024-08-06 10:02:13 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 10:02:13 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 10:02:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 10:02:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 10:02:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 10:02:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 10:11:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 10:11:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 10:11:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 10:11:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 10:30:30 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 10:30:30 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 10:30:43 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 10:30:43 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 10:31:02 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 10:31:03 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 10:40:57 --> Severity: Warning --> mkdir(): No such file or directory /Applications/MAMP/htdocs/integratic/application/controllers/EvidenciasAprendizajeSoportes.php 16
ERROR - 2024-08-06 10:47:41 --> Severity: Warning --> mkdir(): File exists /Applications/MAMP/htdocs/integratic/application/controllers/EvidenciasAprendizajeSoportes.php 32
ERROR - 2024-08-06 10:52:45 --> Severity: Warning --> mkdir(): Permission denied /Applications/MAMP/htdocs/integratic/application/controllers/EvidenciasAprendizajeSoportes.php 38
ERROR - 2024-08-06 10:53:05 --> Severity: Warning --> mkdir(): Permission denied /Applications/MAMP/htdocs/integratic/application/controllers/EvidenciasAprendizajeSoportes.php 38
ERROR - 2024-08-06 11:04:06 --> Severity: Notice --> Undefined index: name /Applications/MAMP/htdocs/integratic/application/controllers/EvidenciasAprendizajeSoportes.php 33
ERROR - 2024-08-06 11:04:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/controllers/EvidenciasAprendizajeSoportes.php 33
ERROR - 2024-08-06 11:04:51 --> Severity: Notice --> Undefined index: name /Applications/MAMP/htdocs/integratic/application/controllers/EvidenciasAprendizajeSoportes.php 34
ERROR - 2024-08-06 11:04:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/controllers/EvidenciasAprendizajeSoportes.php 34
ERROR - 2024-08-06 11:20:46 --> Severity: Notice --> Undefined property: EvidenciasAprendizajeSoportes::$load /Applications/MAMP/htdocs/integratic/application/controllers/EvidenciasAprendizajeSoportes.php 10
ERROR - 2024-08-06 11:20:46 --> Severity: error --> Exception: Call to a member function model() on null /Applications/MAMP/htdocs/integratic/application/controllers/EvidenciasAprendizajeSoportes.php 10
ERROR - 2024-08-06 11:21:11 --> Severity: Notice --> Undefined index: comentarios /Applications/MAMP/htdocs/integratic/application/controllers/EvidenciasAprendizajeSoportes.php 30
ERROR - 2024-08-06 11:21:11 --> Query error: Column 'comentarios' cannot be null - Invalid query: INSERT INTO `evidencias_aprendizaje_soportes` (`id_evidencia_aprendizaje`, `comentarios`, `titulo_archivo`, `nombre_archivo`) VALUES ('1', NULL, 'composer.json', '1722961271_composer.json')
ERROR - 2024-08-06 11:21:30 --> Severity: Notice --> Undefined index: comentarios /Applications/MAMP/htdocs/integratic/application/controllers/EvidenciasAprendizajeSoportes.php 33
ERROR - 2024-08-06 11:21:30 --> Query error: Column 'comentarios' cannot be null - Invalid query: INSERT INTO `evidencias_aprendizaje_soportes` (`id_evidencia_aprendizaje`, `comentarios`, `titulo_archivo`, `nombre_archivo`) VALUES ('1', NULL, 'composer.json', '1722961290_composer.json')
ERROR - 2024-08-06 11:57:01 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-06 11:57:01 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-06 11:57:04 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-06 11:57:04 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-06 11:57:04 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-06 11:57:04 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-06 11:57:04 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-08-06 11:57:04 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 11:57:04 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 11:57:04 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 11:57:04 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 11:57:04 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 11:57:04 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 11:57:04 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 11:57:04 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 11:57:04 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 11:57:04 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 11:57:04 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 11:57:04 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 11:57:04 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 11:57:04 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 11:57:04 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 11:57:04 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 11:57:04 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 11:57:04 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 11:57:04 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 11:57:04 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 11:57:04 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 11:57:05 --> 404 Page Not Found: Images/small
ERROR - 2024-08-06 11:57:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 11:57:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 11:57:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 11:57:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 11:57:08 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 70
ERROR - 2024-08-06 11:57:16 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 70
ERROR - 2024-08-06 11:57:23 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 11:57:23 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 11:57:39 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 70
ERROR - 2024-08-06 11:57:39 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 11:57:39 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 11:58:45 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 70
ERROR - 2024-08-06 11:58:45 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 11:58:45 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 11:58:51 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 70
ERROR - 2024-08-06 11:58:52 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 11:58:52 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 12:00:58 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 70
ERROR - 2024-08-06 12:00:58 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 12:00:58 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 12:01:08 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 12:01:08 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 12:06:57 --> Severity: Notice --> Undefined offset: 1 /Applications/MAMP/htdocs/integratic/application/controllers/EvidenciasAprendizajeSoportes.php 30
ERROR - 2024-08-06 12:10:45 --> Severity: error --> Exception: Call to undefined method CI_Session::getFlashdata() /Applications/MAMP/htdocs/integratic/application/views/plan_aula/create.php 40
ERROR - 2024-08-06 17:00:39 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-06 17:00:39 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-06 17:00:39 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-06 17:00:39 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-06 17:00:39 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-08-06 17:00:39 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:00:40 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:00:40 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:00:40 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:00:40 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:00:40 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:00:40 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:00:40 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:00:40 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:00:40 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:00:40 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:00:40 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:00:40 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:00:40 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:00:40 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:00:40 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:00:40 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:00:40 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:00:40 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:00:40 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:00:40 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:00:41 --> 404 Page Not Found: Images/small
ERROR - 2024-08-06 17:00:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 17:00:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 17:00:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 17:00:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 17:00:43 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 70
ERROR - 2024-08-06 17:12:27 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:12:27 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:13:13 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:13:13 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:13:41 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:13:41 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:14:26 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:14:26 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:14:43 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:14:43 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:15:11 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:15:11 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:15:19 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:15:19 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:15:47 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:15:47 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:16:00 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:16:00 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:16:26 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:16:26 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:17:01 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:17:01 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:17:23 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:17:23 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:23:34 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:23:34 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:23:40 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:23:40 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:26:21 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:26:22 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:27:10 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:27:10 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:27:49 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:27:49 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:28:04 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:28:04 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:28:27 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:28:27 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:37:49 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:37:49 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:37:53 --> 404 Page Not Found: EvidenciasAprendizajeSoporte/getAll
ERROR - 2024-08-06 17:38:09 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:38:10 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:42:06 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:42:06 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:43:55 --> 404 Page Not Found: Uploads/evidencias_aprendizaje
ERROR - 2024-08-06 17:44:44 --> 404 Page Not Found: Uploads/evidencias_aprendizaje
ERROR - 2024-08-06 17:46:54 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:46:54 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:47:38 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:47:38 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:49:20 --> 404 Page Not Found: Uploads/evidencias_aprendizaje
ERROR - 2024-08-06 17:49:20 --> 404 Page Not Found: Uploads/evidencias_aprendizaje
ERROR - 2024-08-06 17:49:20 --> 404 Page Not Found: Uploads/evidencias_aprendizaje
ERROR - 2024-08-06 17:49:20 --> 404 Page Not Found: Uploads/evidencias_aprendizaje
ERROR - 2024-08-06 17:50:36 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:50:36 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:51:22 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:51:22 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:51:28 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:51:28 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:52:05 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 17:52:05 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 17:52:13 --> 404 Page Not Found: Uploads/evidencias_aprendizaje
ERROR - 2024-08-06 17:52:13 --> 404 Page Not Found: Uploads/evidencias_aprendizaje
ERROR - 2024-08-06 17:52:13 --> 404 Page Not Found: Uploads/evidencias_aprendizaje
ERROR - 2024-08-06 17:52:13 --> 404 Page Not Found: Uploads/evidencias_aprendizaje
ERROR - 2024-08-06 17:56:34 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-06 17:56:34 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-06 17:56:34 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-06 17:56:34 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-06 17:56:34 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-08-06 17:56:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:56:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:56:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:56:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:56:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:56:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:56:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:56:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:56:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:56:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:56:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:56:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:56:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:56:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:56:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:56:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:56:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:56:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:56:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:56:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:56:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 17:56:35 --> 404 Page Not Found: Images/small
ERROR - 2024-08-06 17:56:41 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 17:56:41 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 17:56:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 17:56:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 17:56:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 17:56:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 17:56:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 17:56:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:07:15 --> Severity: error --> Exception: Call to undefined method EvidenciasAprendizajeSoportes_Model::find() /Applications/MAMP/htdocs/integratic/application/controllers/EvidenciasAprendizajeSoportes.php 99
ERROR - 2024-08-06 18:07:20 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 18:07:20 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 18:07:29 --> Severity: error --> Exception: Call to undefined method EvidenciasAprendizajeSoportes_Model::find() /Applications/MAMP/htdocs/integratic/application/controllers/EvidenciasAprendizajeSoportes.php 99
ERROR - 2024-08-06 18:08:17 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 18:08:17 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 18:08:23 --> Severity: error --> Exception: Call to undefined method EvidenciasAprendizajeSoportes_Model::delete() /Applications/MAMP/htdocs/integratic/application/controllers/EvidenciasAprendizajeSoportes.php 102
ERROR - 2024-08-06 18:08:34 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 18:08:34 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 18:11:25 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 18:11:25 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 18:13:50 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 18:13:50 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 18:15:19 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 18:15:19 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 18:15:38 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 18:15:38 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 18:15:52 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 18:15:52 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 18:17:02 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 18:17:02 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 18:17:29 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 18:17:30 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 18:18:04 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-06 18:18:04 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-06 18:19:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:19:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:19:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:19:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:19:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:19:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:19:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:19:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:20:02 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:20:02 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:20:04 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:20:04 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:20:08 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:20:08 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:20:10 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:20:10 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:20:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:20:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:21:02 --> 404 Page Not Found: Fjfrghh/index
ERROR - 2024-08-06 18:21:24 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:21:24 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:21:33 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:21:33 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:36:34 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:36:34 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:42:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:42:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:42:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:42:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:42:33 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:42:33 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:42:33 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:42:33 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:42:34 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:42:34 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:42:35 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:42:35 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:42:40 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 70
ERROR - 2024-08-06 18:43:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:43:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:43:48 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-06 18:43:48 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-06 18:43:48 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-06 18:43:48 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-06 18:43:48 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-06 18:43:48 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-06 18:43:48 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-06 18:43:48 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-06 18:43:48 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-08-06 18:43:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 18:43:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 18:43:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 18:43:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 18:43:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 18:43:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 18:43:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 18:43:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 18:43:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 18:43:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 18:43:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 18:43:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 18:43:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 18:43:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 18:43:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 18:43:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 18:43:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 18:43:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 18:43:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 18:43:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 18:43:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-06 18:43:50 --> 404 Page Not Found: Images/small
ERROR - 2024-08-06 18:43:58 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:43:58 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:43:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:43:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:44:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:44:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:44:02 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:44:02 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:44:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:44:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:48:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:48:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:53:28 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:53:28 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:53:28 --> 404 Page Not Found: PlanAula/index.php
ERROR - 2024-08-06 18:53:35 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:53:35 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:53:35 --> 404 Page Not Found: PlanAula/index.php
ERROR - 2024-08-06 18:53:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:53:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:53:39 --> 404 Page Not Found: PlanAula/index.php
ERROR - 2024-08-06 18:57:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:57:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:57:27 --> 404 Page Not Found: PlanAula/index.php
ERROR - 2024-08-06 18:58:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:58:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:58:31 --> 404 Page Not Found: PlanAula/index.php
ERROR - 2024-08-06 18:58:51 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:58:51 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:58:51 --> 404 Page Not Found: PlanAula/index.php
ERROR - 2024-08-06 18:59:02 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:59:02 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 18:59:02 --> 404 Page Not Found: PlanAula/index.php
ERROR - 2024-08-06 19:00:01 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 19:00:01 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-06 19:00:02 --> 404 Page Not Found: PlanAula/index.php
