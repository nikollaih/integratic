<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-12-11 09:20:03 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-12-11 09:20:03 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-12-11 09:20:03 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-12-11 09:20:03 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-12-11 09:20:03 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-12-11 09:20:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:20:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:20:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:20:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:20:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:20:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:20:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:20:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:20:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:20:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:20:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:20:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:20:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:20:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:20:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:20:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:20:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:20:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:20:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:20:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:20:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:20:25 --> 404 Page Not Found: Images/small
ERROR - 2024-12-11 09:20:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 09:20:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 09:20:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 09:20:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 09:21:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/controllers/Actividades.php 213
ERROR - 2024-12-11 09:21:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Actividades.php 214
ERROR - 2024-12-11 09:21:54 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Actividades.php 214
ERROR - 2024-12-11 09:21:54 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/actividades/lista_estudiantes_respuestas.php 6
ERROR - 2024-12-11 09:21:54 --> Severity: Notice --> Undefined index: nombre /Applications/MAMP/htdocs/integratic/application/views/actividades/lista_estudiantes_respuestas.php 7
ERROR - 2024-12-11 09:21:54 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/actividades/lista_estudiantes_respuestas.php 20
ERROR - 2024-12-11 09:21:54 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/actividades/lista_estudiantes_respuestas.php 29
ERROR - 2024-12-11 09:22:11 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-11 09:22:11 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-11 09:22:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/controllers/Actividades.php 213
ERROR - 2024-12-11 09:22:18 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Actividades.php 214
ERROR - 2024-12-11 09:22:18 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Actividades.php 214
ERROR - 2024-12-11 09:22:18 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/actividades/lista_estudiantes_respuestas.php 6
ERROR - 2024-12-11 09:22:18 --> Severity: Notice --> Undefined index: nombre /Applications/MAMP/htdocs/integratic/application/views/actividades/lista_estudiantes_respuestas.php 7
ERROR - 2024-12-11 09:22:18 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/actividades/lista_estudiantes_respuestas.php 20
ERROR - 2024-12-11 09:22:18 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/actividades/lista_estudiantes_respuestas.php 29
ERROR - 2024-12-11 09:23:29 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/actividades/lista_estudiantes_respuestas.php 3
ERROR - 2024-12-11 09:24:38 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 09:24:38 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 09:25:02 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-12-11 09:25:02 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-12-11 09:25:02 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-12-11 09:25:02 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-12-11 09:25:02 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-12-11 09:25:02 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-12-11 09:25:02 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-12-11 09:25:02 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-12-11 09:25:02 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-12-11 09:25:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:25:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:25:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:25:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:25:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:25:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:25:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:25:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:25:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:25:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:25:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:25:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:25:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:25:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:25:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:25:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:25:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:25:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:25:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:25:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:25:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:25:03 --> 404 Page Not Found: Images/small
ERROR - 2024-12-11 09:25:10 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 09:25:10 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 09:25:10 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.m.codmateria' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: Select * from cfg_areas a left join cfg_materias m on a.codarea = m.area join asg_materias am on am.materia = m.codmateria where m.grado = '11' and am.grupo = 'A' group by a.codarea
ERROR - 2024-12-11 09:25:16 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.m.codmateria' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: Select * from cfg_areas a left join cfg_materias m on a.codarea = m.area join asg_materias am on am.materia = m.codmateria where m.grado = '11' and am.grupo = 'A' group by a.codarea
ERROR - 2024-12-11 09:25:20 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-11 09:25:20 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-11 09:25:23 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.m.codmateria' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: Select * from cfg_areas a left join cfg_materias m on a.codarea = m.area join asg_materias am on am.materia = m.codmateria where m.grado = '11' and am.grupo = 'A' group by a.codarea
ERROR - 2024-12-11 09:26:20 --> Severity: Warning --> mkdir(): File exists /Applications/MAMP/htdocs/integratic/application/controllers/Actividades.php 176
ERROR - 2024-12-11 09:27:14 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-12-11 09:27:14 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-12-11 09:27:14 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-12-11 09:27:14 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-12-11 09:27:14 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-12-11 09:27:14 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-12-11 09:27:14 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-12-11 09:27:14 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-12-11 09:27:14 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-12-11 09:27:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:27:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:27:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:27:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:27:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:27:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:27:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:27:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:27:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:27:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:27:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:27:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:27:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:27:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:27:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:27:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:27:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:27:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:27:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:27:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:27:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:27:16 --> 404 Page Not Found: Images/small
ERROR - 2024-12-11 09:27:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 09:27:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 09:27:31 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-11 09:27:31 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-11 09:27:58 --> Severity: Warning --> mkdir(): File exists /Applications/MAMP/htdocs/integratic/application/controllers/Actividades.php 176
ERROR - 2024-12-11 09:29:16 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-12-11 09:29:16 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-12-11 09:29:16 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-12-11 09:29:16 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-12-11 09:29:16 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-12-11 09:29:16 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-12-11 09:29:16 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-12-11 09:29:16 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-12-11 09:29:16 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-12-11 09:29:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:29:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:29:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:29:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:29:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:29:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:29:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:29:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:29:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:29:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:29:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:29:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:29:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:29:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:29:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:29:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:29:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:29:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:29:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:29:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:29:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:29:17 --> 404 Page Not Found: Images/small
ERROR - 2024-12-11 09:29:22 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 09:29:22 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 09:29:45 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-11 09:29:45 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-11 09:31:23 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-12-11 09:31:23 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-12-11 09:31:23 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-12-11 09:31:23 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-12-11 09:31:23 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-12-11 09:31:23 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-12-11 09:31:23 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-12-11 09:31:23 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-12-11 09:31:23 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-12-11 09:31:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:31:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:31:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:31:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:31:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:31:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:31:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:31:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:31:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:31:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:31:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:31:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:31:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:31:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:31:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:31:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:31:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:31:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:31:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:31:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:31:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 09:31:25 --> 404 Page Not Found: Images/small
ERROR - 2024-12-11 09:31:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 09:31:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 09:31:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 09:31:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 09:37:03 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-11 09:37:03 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-11 09:37:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '== `ra`.`id_actividad`
WHERE `id_actividad` = '8'' at line 3 - Invalid query: SELECT *
FROM `respuestas_actividades` `ra`
JOIN `actividades` `a` ON `a`.`id_actividad` == `ra`.`id_actividad`
WHERE `id_actividad` = '8'
ERROR - 2024-12-11 09:37:57 --> Query error: Column 'id_actividad' in where clause is ambiguous - Invalid query: SELECT *
FROM `respuestas_actividades` `ra`
JOIN `actividades` `a` ON `a`.`id_actividad` = `ra`.`id_actividad`
WHERE `id_actividad` = '8'
ERROR - 2024-12-11 09:42:19 --> Query error: Unknown column 'u.documento' in 'on clause' - Invalid query: SELECT *
FROM `respuestas_actividades` `ra`
JOIN `actividades` `a` ON `a`.`id_actividad` = `ra`.`id_actividad`
JOIN `usuarios` `u` ON `ra`.`created_by` = `u`.`documento`
WHERE `ra`.`id_actividad` = '8'
ERROR - 2024-12-11 09:43:14 --> Query error: Unknown column 'u.nombre' in 'field list' - Invalid query: SELECT `ra`.*, `u`.`nombre`
FROM `respuestas_actividades` `ra`
JOIN `actividades` `a` ON `a`.`id_actividad` = `ra`.`id_actividad`
JOIN `usuarios` `u` ON `ra`.`created_by` = `u`.`id`
WHERE `ra`.`id_actividad` = '8'
ERROR - 2024-12-11 09:53:11 --> Severity: error --> Exception: Call to undefined function now() /Applications/MAMP/htdocs/integratic/application/controllers/RespuestasActividades.php 30
ERROR - 2024-12-11 09:54:01 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/RespuestasActividades.php 30
ERROR - 2024-12-11 09:54:01 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/RespuestasActividades.php 30
ERROR - 2024-12-11 09:54:55 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/RespuestasActividades.php 28
ERROR - 2024-12-11 09:54:55 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/RespuestasActividades.php 28
ERROR - 2024-12-11 09:54:55 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/RespuestasActividades.php 30
ERROR - 2024-12-11 09:54:55 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/RespuestasActividades.php 30
ERROR - 2024-12-11 09:55:06 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/RespuestasActividades.php 28
ERROR - 2024-12-11 09:55:06 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/RespuestasActividades.php 28
ERROR - 2024-12-11 09:55:06 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/RespuestasActividades.php 30
ERROR - 2024-12-11 09:55:06 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/RespuestasActividades.php 30
ERROR - 2024-12-11 09:55:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/RespuestasActividades.php 28
ERROR - 2024-12-11 09:55:18 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/RespuestasActividades.php 28
ERROR - 2024-12-11 09:58:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 09:58:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 10:00:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 10:00:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 10:01:14 --> Severity: Notice --> Undefined variable: actividad /Applications/MAMP/htdocs/integratic/application/views/actividades/lista_respuestas_modal.php 12
ERROR - 2024-12-11 10:01:14 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/actividades/lista_respuestas_modal.php 12
ERROR - 2024-12-11 10:01:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 10:01:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 10:01:39 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-11 10:01:39 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-11 10:03:30 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-11 10:03:30 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 10:03:30 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 10:03:30 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-11 10:03:33 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 10:03:33 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 10:06:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 10:06:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-11 13:28:46 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-12-11 13:28:46 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-12-11 13:28:46 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-12-11 13:28:46 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-12-11 13:28:46 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-12-11 13:28:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 13:28:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 13:28:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 13:28:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 13:28:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 13:28:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 13:28:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 13:28:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 13:28:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 13:28:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 13:28:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 13:28:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 13:28:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 13:28:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 13:28:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 13:28:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 13:28:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 13:28:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 13:28:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 13:28:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-11 13:28:46 --> 404 Page Not Found: Img/botones
