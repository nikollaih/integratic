<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-02-15 08:18:01 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-15 08:18:01 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-15 08:18:01 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-15 08:18:01 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-15 08:18:01 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-02-15 08:18:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-15 08:18:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-15 08:18:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-15 08:18:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-15 08:18:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-15 08:18:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-15 08:18:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-15 08:18:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-15 08:18:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-15 08:18:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-15 08:18:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-15 08:18:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-15 08:18:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-15 08:18:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-15 08:18:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-15 08:18:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-15 08:18:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-15 08:18:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-15 08:18:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-15 08:18:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-15 08:18:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-15 08:27:39 --> 404 Page Not Found: Images/small
ERROR - 2025-02-15 08:27:47 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-15 08:27:48 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-15 08:41:11 --> Severity: Notice --> Undefined index: nomarea /Applications/MAMP/htdocs/integratic/application/views/piar/view.php 273
ERROR - 2025-02-15 08:47:02 --> Severity: Notice --> Undefined index: nomarea /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 63
ERROR - 2025-02-15 08:47:02 --> Severity: Notice --> Undefined index: nomarea /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 63
ERROR - 2025-02-15 08:47:02 --> Severity: Notice --> Undefined index: nomarea /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 63
ERROR - 2025-02-15 08:47:41 --> Severity: Notice --> Undefined index: nomarea /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 65
ERROR - 2025-02-15 08:47:41 --> Severity: Notice --> Undefined index: nomarea /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 65
ERROR - 2025-02-15 08:47:41 --> Severity: Notice --> Undefined index: nomarea /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 65
ERROR - 2025-02-15 08:47:57 --> Severity: Notice --> Undefined index: nomarea /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 65
ERROR - 2025-02-15 08:47:57 --> Severity: Notice --> Undefined index: nomarea /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 65
ERROR - 2025-02-15 08:47:57 --> Severity: Notice --> Undefined index: nomarea /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 65
