<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-03-29 16:47:18 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-29 16:47:18 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-29 16:47:18 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-29 16:47:18 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-29 16:47:18 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-29 16:47:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-29 16:47:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-29 16:47:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-29 16:47:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-29 16:47:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-29 16:47:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-29 16:47:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-29 16:47:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-29 16:47:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-29 16:47:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-29 16:47:19 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-29 16:47:19 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-29 16:47:19 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-29 16:47:19 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-29 16:47:19 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-29 16:47:19 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-29 16:47:19 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-29 16:47:19 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-29 16:47:19 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-29 16:47:19 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-29 16:47:19 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-29 16:48:37 --> 404 Page Not Found: Images/small
ERROR - 2025-03-29 16:49:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 110
ERROR - 2025-03-29 16:53:03 --> Severity: error --> Exception: Class 'Mpdf' not found /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 18
ERROR - 2025-03-29 16:54:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 130
ERROR - 2025-03-29 16:55:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 130
ERROR - 2025-03-29 16:57:27 --> Severity: error --> Exception: Too few arguments to function Preguntas_Model::get_preguntas_prueba(), 0 passed in /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php on line 478 and at least 1 expected /Applications/MAMP/htdocs/integratic/application/models/Preguntas_Model.php 79
ERROR - 2025-03-29 16:57:50 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 130
ERROR - 2025-03-29 17:02:29 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.am.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT *
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE `am`.`docente` = '12345'
GROUP BY `am`.`materia`
ORDER BY `cm`.`nommateria` ASC, `am`.`grupo` ASC
ERROR - 2025-03-29 17:02:50 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-03-29 17:04:35 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-03-29 17:06:22 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-03-29 17:09:29 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-03-29 17:09:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/ver_pregunta.php 18
ERROR - 2025-03-29 17:09:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/ver_pregunta.php 18
ERROR - 2025-03-29 17:09:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/ver_pregunta.php 19
ERROR - 2025-03-29 17:09:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/ver_pregunta.php 21
ERROR - 2025-03-29 17:09:55 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-29 17:10:31 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-29 17:10:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 130
ERROR - 2025-03-29 17:30:06 --> 404 Page Not Found: Uploads/respuesta
ERROR - 2025-03-29 17:30:06 --> 404 Page Not Found: Uploads/respuesta
ERROR - 2025-03-29 17:30:17 --> 404 Page Not Found: Uploads/respuesta
ERROR - 2025-03-29 17:30:17 --> 404 Page Not Found: Uploads/respuesta
ERROR - 2025-03-29 17:30:59 --> 404 Page Not Found: Uploads/respuesta
ERROR - 2025-03-29 17:30:59 --> 404 Page Not Found: Uploads/respuesta
ERROR - 2025-03-29 17:31:03 --> 404 Page Not Found: Uploads/respuesta
ERROR - 2025-03-29 17:31:03 --> 404 Page Not Found: Uploads/respuesta
ERROR - 2025-03-29 17:31:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/ver_pregunta.php 18
ERROR - 2025-03-29 17:31:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/ver_pregunta.php 18
ERROR - 2025-03-29 17:31:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/ver_pregunta.php 19
ERROR - 2025-03-29 17:31:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/ver_pregunta.php 21
ERROR - 2025-03-29 17:33:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 132
ERROR - 2025-03-29 17:33:36 --> 404 Page Not Found: Uploads/respuesta
ERROR - 2025-03-29 17:33:36 --> 404 Page Not Found: Uploads/respuesta
ERROR - 2025-03-29 17:36:06 --> Severity: Notice --> Undefined variable: preguntas /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 84
ERROR - 2025-03-29 17:36:06 --> 404 Page Not Found: Pruebas/cuadernillo
