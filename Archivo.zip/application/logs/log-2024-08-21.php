<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-08-21 13:55:43 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-08-21 13:55:43 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-21 13:55:43 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-21 13:55:43 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-21 13:55:44 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-08-21 13:55:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:45 --> 404 Page Not Found: Images/small
ERROR - 2024-08-21 13:55:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:47 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-21 13:55:47 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-21 13:55:47 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-21 13:55:47 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-21 13:55:47 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-21 13:55:47 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-21 13:55:47 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-21 13:55:47 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-21 13:55:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:47 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-08-21 13:55:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:48 --> 404 Page Not Found: Images/small
ERROR - 2024-08-21 13:55:49 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:49 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:50 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:55:50 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:56:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:56:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:56:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:57:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:57:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:58:56 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-21 13:58:56 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-21 13:58:56 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-21 13:58:56 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-21 13:58:56 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-21 13:58:56 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-21 13:58:56 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-21 13:58:56 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-21 13:58:57 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-08-21 13:58:57 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:58:57 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:58:57 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:58:57 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:58:57 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:58:57 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:58:57 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:58:57 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:58:57 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:58:57 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:58:57 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:58:57 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:58:57 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:58:57 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:58:57 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:58:57 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:58:57 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:58:57 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:58:57 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:58:57 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:58:57 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 13:58:58 --> 404 Page Not Found: Images/small
ERROR - 2024-08-21 13:59:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 13:59:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 13:59:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 13:59:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:00:34 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:00:34 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:03:41 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:03:41 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:03:41 --> 404 Page Not Found: Images/small
ERROR - 2024-08-21 14:03:44 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-21 14:03:44 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-21 14:03:44 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-21 14:03:44 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-21 14:03:44 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-21 14:03:44 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-21 14:03:44 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-21 14:03:44 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-21 14:03:44 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-08-21 14:03:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:03:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:03:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:03:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:03:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:03:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:03:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:03:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:03:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:03:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:03:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:03:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:03:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:03:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:03:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:03:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:03:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:03:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:03:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:03:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:03:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:03:45 --> 404 Page Not Found: Images/small
ERROR - 2024-08-21 14:03:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:03:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:03:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:03:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:03:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:03:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:03:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:03:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:03:49 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.m.codmateria' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: Select * from cfg_areas a left join cfg_materias m on a.codarea = m.area join asg_materias am on am.materia = m.codmateria where m.grado = '11' and am.grupo = 'A' group by a.codarea
ERROR - 2024-08-21 14:03:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:03:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:03:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:03:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:03:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:03:52 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.m.codmateria' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: Select * from cfg_areas a left join cfg_materias m on a.codarea = m.area join asg_materias am on am.materia = m.codmateria where m.grado = '11' and am.grupo = 'A' group by a.codarea
ERROR - 2024-08-21 14:06:03 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-21 14:06:03 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-21 14:06:03 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-21 14:06:03 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-21 14:06:03 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-21 14:06:03 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-21 14:06:03 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-21 14:06:03 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-21 14:06:03 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-08-21 14:06:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:06:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:06:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:06:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:06:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:06:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:06:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:06:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:06:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:06:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:06:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:06:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:06:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:06:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:06:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:06:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:06:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:06:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:06:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:06:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:06:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-21 14:06:04 --> 404 Page Not Found: Images/small
ERROR - 2024-08-21 14:06:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:30 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:30 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:30 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:30 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:30 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:34 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:34 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:34 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:34 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:34 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:56 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:56 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:56 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:56 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:56 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:06:57 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-21 14:07:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:07:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:07:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:07:52 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-21 14:07:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:07:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:07:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:07:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:08:04 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:08:04 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:08:04 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:08:04 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-21 14:08:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:08:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:08:39 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-21 14:11:32 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-21 14:11:32 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
