<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-01-30 17:30:27 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-01-30 17:30:27 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-01-30 17:30:27 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-01-30 17:30:27 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-01-30 17:30:27 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-01-30 17:30:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-30 17:30:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-30 17:30:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-30 17:30:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-30 17:30:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-30 17:30:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-30 17:30:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-30 17:30:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-30 17:30:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-30 17:30:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-30 17:30:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-30 17:30:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-30 17:30:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-30 17:30:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-30 17:30:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-30 17:30:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-30 17:30:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-30 17:30:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-30 17:30:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-30 17:30:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-30 17:30:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-30 17:30:29 --> 404 Page Not Found: Images/small
ERROR - 2025-01-30 17:30:36 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-30 17:30:36 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-30 17:34:15 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-30 17:34:15 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-30 17:35:55 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-30 17:35:55 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-30 17:35:57 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-30 17:35:57 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-30 17:36:51 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-30 17:36:52 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-30 17:39:05 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-30 17:39:05 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-30 17:39:17 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-30 17:39:17 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-30 17:39:20 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-30 17:39:20 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-30 17:39:33 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-30 17:39:33 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-30 17:39:36 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-30 17:39:36 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-30 17:39:47 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-30 17:39:47 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-30 17:40:22 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-30 17:40:22 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-30 17:40:26 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-30 17:40:26 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-30 17:40:40 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-30 17:40:40 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-30 17:41:42 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-30 17:41:42 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-30 17:42:00 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-30 17:42:00 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-30 17:49:41 --> Query error: Unknown column 'piar_id' in 'field list' - Invalid query: INSERT INTO `piar` (`piar_id`, `objetivos`, `barreras`, `ajustes_razonables`, `evaluacion`) VALUES ('1', '<p>fghfghf</p>', '<p>hgfhfg</p>', '<p>gfhfgh</p>', '<p>hfghfg</p>')
ERROR - 2025-01-30 17:50:29 --> Query error: Unknown column 'objetivos' in 'field list' - Invalid query: INSERT INTO `piar` (`id_piar`, `objetivos`, `barreras`, `ajustes_razonables`, `evaluacion`) VALUES ('1', '<p>ghfhfh</p>', '<p>gfhgfh</p>', '<p>fghfgh</p>', '<p>fghfghgf</p><p>gfhfgh</p>')
ERROR - 2025-01-30 18:04:29 --> Severity: Notice --> Undefined index: id /Applications/MAMP/htdocs/integratic/application/controllers/Piar.php 83
ERROR - 2025-01-30 18:04:29 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/application/models/Estudiante_Model.php 69
ERROR - 2025-01-30 18:04:29 --> Severity: Notice --> Trying to get property 'grado' of non-object /Applications/MAMP/htdocs/integratic/application/models/Estudiante_Model.php 69
ERROR - 2025-01-30 18:04:29 --> Severity: Notice --> Undefined index: id /Applications/MAMP/htdocs/integratic/application/controllers/Piar.php 84
ERROR - 2025-01-30 18:04:29 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/application/models/Estudiante_Model.php 63
ERROR - 2025-01-30 18:04:29 --> Severity: Notice --> Trying to get property 'grado' of non-object /Applications/MAMP/htdocs/integratic/application/models/Estudiante_Model.php 63
ERROR - 2025-01-30 18:04:41 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-30 18:04:41 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-30 18:04:56 --> Severity: Notice --> Undefined index: id /Applications/MAMP/htdocs/integratic/application/controllers/Piar.php 84
ERROR - 2025-01-30 18:04:56 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/application/models/Estudiante_Model.php 63
ERROR - 2025-01-30 18:04:56 --> Severity: Notice --> Trying to get property 'grado' of non-object /Applications/MAMP/htdocs/integratic/application/models/Estudiante_Model.php 63
ERROR - 2025-01-30 18:04:57 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-30 18:04:57 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-30 18:05:05 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-30 18:05:05 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-30 18:05:47 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-30 18:05:47 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-30 18:06:22 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-30 18:06:22 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-30 18:06:56 --> Query error: Unknown column 'am.codmateria' in 'group statement' - Invalid query: SELECT *
FROM `cfg_materias` `cm`
JOIN `asg_materias` `am` ON `cm`.`codmateria` = `am`.`materia`
WHERE `cm`.`grado` = '11'
AND `am`.`grupo` = 'A'
GROUP BY `am`.`codmateria`
ERROR - 2025-01-30 18:07:08 --> Query error: Expression #9 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.am.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT *
FROM `cfg_materias` `cm`
JOIN `asg_materias` `am` ON `cm`.`codmateria` = `am`.`materia`
WHERE `cm`.`grado` = '11'
AND `am`.`grupo` = 'A'
GROUP BY `cm`.`codmateria`
ERROR - 2025-01-30 18:08:50 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.am.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `am`.*, `cm`.*
FROM `cfg_materias` `cm`
JOIN `asg_materias` `am` ON `cm`.`codmateria` = `am`.`materia`
WHERE `cm`.`grado` = '11'
AND `am`.`grupo` = 'A'
GROUP BY `cm`.`codmateria`
ERROR - 2025-01-30 18:08:55 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.am.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `am`.*, `cm`.`codmateria`
FROM `cfg_materias` `cm`
JOIN `asg_materias` `am` ON `cm`.`codmateria` = `am`.`materia`
WHERE `cm`.`grado` = '11'
AND `am`.`grupo` = 'A'
GROUP BY `cm`.`codmateria`
ERROR - 2025-01-30 18:09:36 --> Severity: Notice --> Undefined index: nommateria /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 109
ERROR - 2025-01-30 18:09:36 --> Severity: Notice --> Undefined index: nommateria /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 109
ERROR - 2025-01-30 18:09:37 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-30 18:09:37 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-30 18:10:39 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-30 18:10:39 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-30 18:10:53 --> Query error: Expression #5 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.am.docente' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `cm`.`area`, `cm`.`grado`, `am`.`docente`, `am`.`materia`, `am`.`grupo`
FROM `cfg_materias` `cm`
JOIN `asg_materias` `am` ON `cm`.`codmateria` = `am`.`materia`
WHERE `cm`.`grado` = '11'
AND `am`.`grupo` = 'A'
GROUP BY `cm`.`codmateria`
ERROR - 2025-01-30 18:11:06 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-30 18:11:06 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-30 18:12:58 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-30 18:12:58 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-30 18:13:16 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-30 18:13:16 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-30 18:13:58 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-30 18:13:58 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-30 18:14:16 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-30 18:14:16 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-30 18:48:22 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-30 18:48:27 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 44
ERROR - 2025-01-30 18:48:27 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 44
ERROR - 2025-01-30 18:48:27 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 62
ERROR - 2025-01-30 18:48:27 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 62
ERROR - 2025-01-30 18:48:27 --> Severity: Notice --> Undefined index: id_piar /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 104
ERROR - 2025-01-30 18:48:27 --> Severity: Notice --> Undefined index: entorno_personal /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 234
ERROR - 2025-01-30 18:49:16 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 44
ERROR - 2025-01-30 18:49:16 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 44
ERROR - 2025-01-30 18:49:16 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 62
ERROR - 2025-01-30 18:49:16 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 62
ERROR - 2025-01-30 18:49:16 --> Severity: Notice --> Undefined index: entorno_personal /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 237
ERROR - 2025-01-30 18:49:43 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 44
ERROR - 2025-01-30 18:49:43 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 44
ERROR - 2025-01-30 18:49:43 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 62
ERROR - 2025-01-30 18:49:43 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 62
ERROR - 2025-01-30 19:09:10 --> Severity: Warning --> Illegal string offset 'nommateria' /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:09:10 --> Severity: Warning --> Illegal string offset 'nommateria' /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:09:10 --> Severity: Warning --> Illegal string offset 'nommateria' /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:09:10 --> Severity: Warning --> Illegal string offset 'nommateria' /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:09:10 --> Severity: Warning --> Illegal string offset 'nommateria' /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:09:10 --> Severity: Warning --> Illegal string offset 'nommateria' /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:09:10 --> Severity: Warning --> Illegal string offset 'nommateria' /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:09:10 --> Severity: Warning --> Illegal string offset 'nommateria' /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:09:10 --> Severity: Warning --> Illegal string offset 'nommateria' /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:09:10 --> Severity: Warning --> Illegal string offset 'nommateria' /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:09:10 --> Severity: Warning --> Illegal string offset 'nommateria' /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:09:10 --> Severity: Warning --> Illegal string offset 'nommateria' /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:09:10 --> Severity: Warning --> Illegal string offset 'nommateria' /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:09:16 --> Severity: Warning --> Illegal string offset 'codmateria' /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:09:16 --> Severity: Warning --> Illegal string offset 'codmateria' /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:09:16 --> Severity: Warning --> Illegal string offset 'codmateria' /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:09:16 --> Severity: Warning --> Illegal string offset 'codmateria' /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:09:16 --> Severity: Warning --> Illegal string offset 'codmateria' /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:09:16 --> Severity: Warning --> Illegal string offset 'codmateria' /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:09:16 --> Severity: Warning --> Illegal string offset 'codmateria' /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:09:16 --> Severity: Warning --> Illegal string offset 'codmateria' /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:09:16 --> Severity: Warning --> Illegal string offset 'codmateria' /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:09:16 --> Severity: Warning --> Illegal string offset 'codmateria' /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:09:16 --> Severity: Warning --> Illegal string offset 'codmateria' /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:09:16 --> Severity: Warning --> Illegal string offset 'codmateria' /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:09:16 --> Severity: Warning --> Illegal string offset 'codmateria' /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:10:20 --> Query error: Unknown column 'piar_item.piar_id' in 'where clause' - Invalid query: SELECT *
FROM `piar_item`
JOIN `piar` ON `piar_item`.`piar_id` = `piar`.`piar_id`
WHERE `piar_item`.`piar_id` = '1'
ERROR - 2025-01-30 19:10:38 --> Severity: Notice --> Undefined index: codmateria /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:10:38 --> Severity: Notice --> Undefined index: codmateria /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:10:38 --> Severity: Notice --> Undefined index: codmateria /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 223
ERROR - 2025-01-30 19:11:46 --> Query error: Not unique table/alias: 'piar' - Invalid query: SELECT *
FROM `piar_item`
JOIN `piar` ON `piar_item`.`id_piar` = `piar`.`id_piar`
JOIN `piar` ON `cfg_materias`.`codmateria` = `piar`.`id_materia`
WHERE `piar_item`.`id_piar` = '1'
ERROR - 2025-01-30 19:12:20 --> Query error: Unknown column 'piar.id_materia' in 'on clause' - Invalid query: SELECT *
FROM `piar_item`
JOIN `piar` ON `piar_item`.`id_piar` = `piar`.`id_piar`
JOIN `cfg_materias` ON `cfg_materias`.`codmateria` = `piar`.`id_materia`
WHERE `piar_item`.`id_piar` = '1'
ERROR - 2025-01-30 19:14:07 --> Severity: Notice --> Undefined index: ajustes /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 226
ERROR - 2025-01-30 19:14:07 --> Severity: Notice --> Undefined index: ajustes /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 226
ERROR - 2025-01-30 19:14:07 --> Severity: Notice --> Undefined index: ajustes /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 226
ERROR - 2025-01-30 19:24:25 --> Severity: Notice --> Undefined index: id_piar_item /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 230
ERROR - 2025-01-30 19:24:26 --> Severity: Notice --> Undefined index: id_piar_item /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 230
