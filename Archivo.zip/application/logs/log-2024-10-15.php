<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-10-15 09:26:13 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-10-15 09:26:13 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-10-15 09:26:13 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-10-15 09:26:13 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-10-15 09:26:13 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-10-15 09:26:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-15 09:26:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-15 09:26:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-15 09:26:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-15 09:26:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-15 09:26:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-15 09:26:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-15 09:26:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-15 09:26:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-15 09:26:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-15 09:26:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-15 09:26:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-15 09:26:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-15 09:26:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-15 09:26:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-15 09:26:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-15 09:26:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-15 09:26:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-15 09:26:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-15 09:26:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-15 09:26:14 --> 404 Page Not Found: Img/botones
