<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-03-18 18:34:41 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-18 18:34:41 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-18 18:34:41 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-18 18:34:41 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-18 18:34:41 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-18 18:34:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:34:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:34:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:34:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:34:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:34:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:34:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:34:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:34:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:34:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:34:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:34:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:34:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:34:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:34:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:34:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:34:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:34:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:34:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:34:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:34:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:34:44 --> 404 Page Not Found: Images/small
ERROR - 2025-03-18 18:34:51 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-18 18:34:51 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-18 18:43:49 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 98
ERROR - 2025-03-18 18:43:50 --> Query error: Expression #11 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.pp.id_asignacion_participante_prueba' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT *
FROM `core_participantes_pruebas` `cpp`
JOIN `asignacion_participantes_prueba` `pp` ON `pp`.`id_participante` = `cpp`.`id_participante_prueba`
LEFT JOIN `municipios` `m` ON `m`.`id_municipio` = `cpp`.`municipio`
LEFT JOIN `instituciones_educativas` `ie` ON `ie`.`id_institucion_educativa` = `cpp`.`institucion`
WHERE `pp`.`id_prueba` = '6'
GROUP BY `cpp`.`id_participante_prueba`
ORDER BY `cpp`.`apellidos` ASC
ERROR - 2025-03-18 18:44:18 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 255
ERROR - 2025-03-18 18:44:18 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 256
ERROR - 2025-03-18 18:44:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-18 18:44:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 255
ERROR - 2025-03-18 18:44:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 256
ERROR - 2025-03-18 18:44:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-18 18:44:36 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-18 18:44:38 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-18 18:44:38 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-18 18:44:38 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-18 18:44:38 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-18 18:44:38 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-18 18:44:38 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-18 18:44:38 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-18 18:44:38 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-18 18:44:38 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-18 18:44:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:44:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:44:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:44:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:44:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:44:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:44:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:44:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:44:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:44:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:44:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:44:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:44:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:44:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:44:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:44:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:44:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:44:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:44:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:44:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:44:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 18:44:39 --> 404 Page Not Found: Images/small
ERROR - 2025-03-18 18:44:41 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-18 18:44:41 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-18 18:44:45 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2025-03-18 18:44:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2025-03-18 18:44:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2025-03-18 18:44:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-03-18 18:44:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-03-18 18:44:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-03-18 18:44:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-03-18 18:44:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-03-18 18:44:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-03-18 18:44:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-03-18 18:44:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-03-18 18:44:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-03-18 18:44:47 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-18 19:03:27 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-18 19:03:31 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-18 19:03:31 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-18 19:03:31 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-18 19:03:31 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-18 19:03:31 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-18 19:03:31 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-18 19:03:31 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-18 19:03:31 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-18 19:03:31 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-18 19:03:31 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 19:03:31 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 19:03:31 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 19:03:31 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 19:03:31 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 19:03:31 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 19:03:31 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 19:03:31 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 19:03:31 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 19:03:31 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 19:03:31 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 19:03:31 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 19:03:31 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 19:03:31 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 19:03:31 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 19:03:31 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 19:03:31 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 19:03:31 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 19:03:31 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 19:03:31 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 19:03:31 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-18 19:03:32 --> 404 Page Not Found: Images/small
ERROR - 2025-03-18 19:03:50 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-18 19:03:50 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-18 19:03:53 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-18 19:04:36 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-03-18 19:05:00 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-18 19:31:07 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-18 19:31:30 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-18 19:31:30 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-18 19:31:34 --> 404 Page Not Found: Img/iconos
