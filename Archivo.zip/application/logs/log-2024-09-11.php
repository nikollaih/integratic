<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-09-11 12:27:20 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-09-11 12:27:20 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-09-11 12:27:20 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-09-11 12:27:20 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-09-11 12:27:20 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-09-11 12:27:20 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-11 12:27:20 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-11 12:27:20 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-11 12:27:20 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-11 12:27:20 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-11 12:27:20 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-11 12:27:20 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-11 12:27:20 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-11 12:27:20 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-11 12:27:20 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-11 12:27:20 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-11 12:27:20 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-11 12:27:20 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-11 12:27:20 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-11 12:27:20 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-11 12:27:20 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-11 12:27:20 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-11 12:27:20 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-11 12:27:20 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-11 12:27:20 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-11 12:27:20 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-11 12:27:21 --> 404 Page Not Found: Images/small
ERROR - 2024-09-11 12:27:22 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-11 12:27:22 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-11 12:27:23 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-11 12:27:23 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-11 12:27:24 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 85
