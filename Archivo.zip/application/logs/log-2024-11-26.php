<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-11-26 17:29:42 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-11-26 17:29:42 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-26 17:29:42 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-26 17:29:42 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-26 17:29:42 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-11-26 17:29:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-26 17:29:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-26 17:29:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-26 17:29:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-26 17:29:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-26 17:29:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-26 17:29:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-26 17:29:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-26 17:29:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-26 17:29:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-26 17:29:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-26 17:29:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-26 17:29:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-26 17:29:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-26 17:29:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-26 17:29:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-26 17:29:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-26 17:29:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-26 17:29:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-26 17:29:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-26 17:29:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-26 17:29:43 --> 404 Page Not Found: Images/small
ERROR - 2024-11-26 17:29:55 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-26 17:29:55 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-26 17:29:56 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-26 17:29:56 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-26 17:30:54 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-11-26 17:30:54 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-11-26 17:31:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-26 17:31:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-26 17:31:21 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-11-26 17:31:21 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-11-26 17:31:32 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-11-26 17:31:32 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-11-26 17:31:32 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-26 17:31:32 --> 404 Page Not Found: Img/iconos
