<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-10-23 17:15:43 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-10-23 17:15:43 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-10-23 17:15:43 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-10-23 17:15:43 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-10-23 17:15:43 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-10-23 17:15:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-23 17:15:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-23 17:15:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-23 17:15:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-23 17:15:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-23 17:15:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-23 17:15:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-23 17:15:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-23 17:15:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-23 17:15:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-23 17:15:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-23 17:15:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-23 17:15:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-23 17:15:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-23 17:15:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-23 17:15:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-23 17:15:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-23 17:15:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-23 17:15:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-23 17:15:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-23 17:15:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-23 17:15:44 --> 404 Page Not Found: Images/small
ERROR - 2024-10-23 17:15:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:15:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:15:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:15:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:15:54 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:15:54 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:16:01 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:16:01 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:19:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:19:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:20:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:20:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:22:30 --> 404 Page Not Found: Recuperaciones/estudiante
ERROR - 2024-10-23 17:24:23 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-10-23 17:24:23 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-10-23 17:24:23 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-10-23 17:24:23 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-10-23 17:24:23 --> Severity: Notice --> Undefined variable: actividades /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 34
ERROR - 2024-10-23 17:24:23 --> Severity: Notice --> Undefined variable: pruebas /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 74
ERROR - 2024-10-23 17:24:23 --> Severity: Notice --> Undefined variable: estudiantes /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 111
ERROR - 2024-10-23 17:24:23 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:24:23 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:24:23 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-23 17:24:23 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:24:23 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:24:23 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:24:23 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:24:23 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-23 17:24:23 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:24:23 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:24:23 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:24:23 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:24:23 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-23 17:24:23 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:24:23 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:24:23 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:24:23 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:24:24 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-10-23 17:24:24 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-10-23 17:24:24 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-10-23 17:24:24 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-10-23 17:24:24 --> Severity: Notice --> Undefined variable: actividades /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 34
ERROR - 2024-10-23 17:24:24 --> Severity: Notice --> Undefined variable: pruebas /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 74
ERROR - 2024-10-23 17:24:24 --> Severity: Notice --> Undefined variable: estudiantes /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 111
ERROR - 2024-10-23 17:24:24 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:24:24 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:24:24 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-23 17:24:24 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:24:24 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:24:24 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:24:24 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:24:24 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-23 17:24:24 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:24:24 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:24:24 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:24:24 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:24:24 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-23 17:24:24 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:24:24 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:25:02 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-10-23 17:25:02 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-10-23 17:25:02 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-10-23 17:25:02 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-10-23 17:25:02 --> Severity: Notice --> Undefined variable: actividades /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 34
ERROR - 2024-10-23 17:25:02 --> Severity: Notice --> Undefined variable: pruebas /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 74
ERROR - 2024-10-23 17:25:02 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:25:02 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:25:02 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-23 17:25:02 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:25:02 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:25:02 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:25:02 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:25:02 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-23 17:25:02 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:25:02 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:25:02 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:25:02 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:25:02 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-23 17:25:02 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:25:02 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:25:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:25:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:25:03 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-10-23 17:25:03 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-10-23 17:25:03 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-10-23 17:25:03 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-10-23 17:25:03 --> Severity: Notice --> Undefined variable: actividades /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 34
ERROR - 2024-10-23 17:25:03 --> Severity: Notice --> Undefined variable: pruebas /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 74
ERROR - 2024-10-23 17:25:03 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:25:03 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:25:03 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-23 17:25:03 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:25:03 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:25:03 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:25:03 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:25:03 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-23 17:25:03 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:25:03 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:25:03 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:25:03 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:25:03 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-23 17:25:03 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:25:03 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Undefined variable: actividades /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 34
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Undefined variable: pruebas /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 74
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:28:05 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:28:05 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:28:05 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:28:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:28:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Undefined variable: actividades /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 34
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Undefined variable: pruebas /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 74
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:28:05 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:28:05 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-23 17:28:05 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:28:05 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Undefined variable: actividades /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 34
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Undefined variable: pruebas /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 74
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:28:27 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:28:27 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:28:27 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:28:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:28:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Undefined variable: actividades /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 34
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Undefined variable: pruebas /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 74
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:28:27 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:28:27 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-23 17:28:27 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:28:27 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Undefined variable: actividades /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 33
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Undefined variable: pruebas /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 73
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:28:45 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:28:45 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:28:45 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:28:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:28:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Undefined variable: actividades /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 33
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Undefined variable: pruebas /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 73
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:28:45 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:28:45 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-23 17:28:45 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:28:45 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Undefined variable: actividades /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 33
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Undefined variable: pruebas /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 73
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:29:39 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:29:39 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:29:39 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:29:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:29:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Undefined variable: actividades /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 33
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Undefined variable: pruebas /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 73
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:29:39 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:29:39 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-23 17:29:39 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:29:39 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 41
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 41
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 41
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 41
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Undefined index: disponible_desde /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 78
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Undefined index: disponible_hasta /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 79
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 81
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 81
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:35:30 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:35:30 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:35:30 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:35:30 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:35:30 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Undefined index: disponible_desde /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 78
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Undefined index: disponible_hasta /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 79
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 81
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 81
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:35:30 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:35:30 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-23 17:35:30 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:35:30 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:36:59 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 41
ERROR - 2024-10-23 17:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 41
ERROR - 2024-10-23 17:36:59 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 41
ERROR - 2024-10-23 17:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 41
ERROR - 2024-10-23 17:36:59 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 81
ERROR - 2024-10-23 17:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 81
ERROR - 2024-10-23 17:36:59 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:36:59 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-23 17:36:59 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:36:59 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:36:59 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:36:59 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-23 17:36:59 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:36:59 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:36:59 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:36:59 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-23 17:36:59 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:36:59 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:37:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:37:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:37:00 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 81
ERROR - 2024-10-23 17:37:00 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 81
ERROR - 2024-10-23 17:37:00 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:37:00 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:37:00 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-23 17:37:00 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:37:00 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:37:00 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:37:00 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:37:00 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-23 17:37:00 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:37:00 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:37:00 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:37:00 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:37:00 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-23 17:37:00 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:37:00 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:37:33 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:37:33 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:37:33 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-23 17:37:33 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:37:33 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:37:33 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:37:33 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:37:33 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-23 17:37:33 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:37:33 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:37:33 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:37:33 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:37:33 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-23 17:37:33 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:37:33 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:37:33 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:37:33 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:37:33 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:37:33 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:37:33 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-23 17:37:33 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:37:33 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:37:33 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:37:33 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:37:33 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-23 17:37:33 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:37:33 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:37:33 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:37:33 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:37:33 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-23 17:37:33 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:37:33 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:37:49 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:37:49 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:37:49 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-23 17:37:49 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:37:49 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:37:49 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:37:49 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:37:49 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-23 17:37:49 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:37:49 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:37:49 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:37:49 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:37:49 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-23 17:37:49 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:37:49 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:37:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:37:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:37:49 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:37:49 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:37:49 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-23 17:37:49 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:37:49 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:37:49 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:37:49 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:37:49 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-23 17:37:49 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:37:49 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:37:49 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:37:49 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:37:49 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-23 17:37:49 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:37:49 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:38:59 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:38:59 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:38:59 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-23 17:38:59 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:38:59 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:38:59 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:38:59 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:38:59 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-23 17:38:59 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:38:59 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:38:59 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:38:59 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:38:59 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-23 17:38:59 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:38:59 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:38:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:38:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:39:00 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:39:00 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:39:00 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-23 17:39:00 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:39:00 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:39:00 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:39:00 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:39:00 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-23 17:39:00 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:39:00 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:39:00 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:39:00 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:39:00 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-23 17:39:00 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:39:00 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:40:22 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:40:22 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:40:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:40:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:41:10 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:41:10 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:41:10 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-23 17:41:10 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:41:10 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:41:10 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:41:10 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:41:10 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-23 17:41:10 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:41:10 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:41:10 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:41:10 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:41:10 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-23 17:41:10 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:41:10 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:41:10 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:41:10 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:41:10 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:41:10 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:41:10 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-23 17:41:10 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:41:10 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:41:10 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:41:10 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:41:10 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-23 17:41:10 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:41:10 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:41:10 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:41:10 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:41:10 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-23 17:41:10 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:41:10 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:41:52 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:41:52 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:41:52 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-23 17:41:52 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:41:52 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:41:52 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:41:52 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:41:52 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-23 17:41:52 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:41:52 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:41:52 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:41:52 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:41:52 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-23 17:41:52 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:41:52 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:41:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:41:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-23 17:41:52 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:41:52 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-23 17:41:52 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-23 17:41:52 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:41:52 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-23 17:41:52 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:41:52 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-23 17:41:52 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-23 17:41:52 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:41:52 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-23 17:41:52 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:41:52 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-23 17:41:52 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-23 17:41:52 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-23 17:41:52 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
