<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-01-28 17:46:00 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-01-28 17:46:00 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-01-28 17:46:00 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-01-28 17:46:00 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-01-28 17:46:00 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-01-28 17:46:00 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-28 17:46:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-28 17:46:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-28 17:46:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-28 17:46:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-28 17:46:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-28 17:46:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-28 17:46:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-28 17:46:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-28 17:46:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-28 17:46:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-28 17:46:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-28 17:46:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-28 17:46:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-28 17:46:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-28 17:46:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-28 17:46:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-28 17:46:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-28 17:46:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-28 17:46:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-28 17:46:01 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-28 17:46:02 --> 404 Page Not Found: Images/small
ERROR - 2025-01-28 17:46:09 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-28 17:46:09 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-28 17:46:22 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/piar/view.php 19
ERROR - 2025-01-28 17:46:22 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/piar/view.php 20
ERROR - 2025-01-28 17:46:22 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/piar/view.php 21
ERROR - 2025-01-28 17:46:22 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/piar/view.php 22
ERROR - 2025-01-28 17:46:22 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/piar/view.php 23
ERROR - 2025-01-28 17:46:22 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/piar/view.php 26
ERROR - 2025-01-28 17:59:38 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 123
ERROR - 2025-01-28 17:59:38 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 137
ERROR - 2025-01-28 17:59:38 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 151
ERROR - 2025-01-28 17:59:38 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 165
ERROR - 2025-01-28 17:59:38 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 179
ERROR - 2025-01-28 17:59:56 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 123
ERROR - 2025-01-28 17:59:56 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 137
ERROR - 2025-01-28 17:59:56 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 151
ERROR - 2025-01-28 17:59:56 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 165
ERROR - 2025-01-28 18:00:11 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 123
ERROR - 2025-01-28 18:00:11 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 137
ERROR - 2025-01-28 18:00:11 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 151
ERROR - 2025-01-28 18:00:11 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 165
ERROR - 2025-01-28 18:00:39 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 123
ERROR - 2025-01-28 18:00:39 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 137
ERROR - 2025-01-28 18:00:39 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 151
ERROR - 2025-01-28 18:00:39 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 165
ERROR - 2025-01-28 18:01:57 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 122
ERROR - 2025-01-28 18:01:57 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 135
ERROR - 2025-01-28 18:01:57 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 148
ERROR - 2025-01-28 18:01:57 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 161
ERROR - 2025-01-28 18:03:24 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 122
ERROR - 2025-01-28 18:03:24 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 135
ERROR - 2025-01-28 18:03:24 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 148
ERROR - 2025-01-28 18:03:24 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 161
ERROR - 2025-01-28 18:03:40 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-28 18:03:40 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-28 18:05:23 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 122
ERROR - 2025-01-28 18:05:23 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 135
ERROR - 2025-01-28 18:05:23 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 148
ERROR - 2025-01-28 18:05:23 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 161
ERROR - 2025-01-28 18:05:23 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 122
ERROR - 2025-01-28 18:05:23 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 135
ERROR - 2025-01-28 18:05:23 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 148
ERROR - 2025-01-28 18:05:23 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 161
ERROR - 2025-01-28 18:05:23 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-28 18:05:24 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-28 18:05:24 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-28 18:05:24 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 122
ERROR - 2025-01-28 18:05:24 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 135
ERROR - 2025-01-28 18:05:24 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 148
ERROR - 2025-01-28 18:05:24 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 161
ERROR - 2025-01-28 18:05:24 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-28 18:05:24 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-28 18:05:47 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 122
ERROR - 2025-01-28 18:05:47 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 135
ERROR - 2025-01-28 18:05:47 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 148
ERROR - 2025-01-28 18:05:47 --> Severity: Notice --> Undefined variable: selectedEvidencia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 161
