<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated /Applications/MAMP/htdocs/integratic/system/core/URI.php 101
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated /Applications/MAMP/htdocs/integratic/system/core/Router.php 127
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CaracterizacionEstudiantes::$benchmark is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CaracterizacionEstudiantes::$hooks is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CaracterizacionEstudiantes::$config is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CaracterizacionEstudiantes::$log is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CaracterizacionEstudiantes::$utf8 is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CaracterizacionEstudiantes::$uri is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CaracterizacionEstudiantes::$exceptions is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CaracterizacionEstudiantes::$router is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CaracterizacionEstudiantes::$output is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CaracterizacionEstudiantes::$security is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CaracterizacionEstudiantes::$input is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CaracterizacionEstudiantes::$lang is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CaracterizacionEstudiantes::$load is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 78
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Return type of CI_Session_database_driver::open($save_path, $name) should either be compatible with SessionHandlerInterface::open(string $path, string $name): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 126
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Return type of CI_Session_database_driver::close() should either be compatible with SessionHandlerInterface::close(): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 275
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Return type of CI_Session_database_driver::read($session_id) should either be compatible with SessionHandlerInterface::read(string $id): string|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 146
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Return type of CI_Session_database_driver::write($session_id, $session_data) should either be compatible with SessionHandlerInterface::write(string $id, string $data): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 203
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Return type of CI_Session_database_driver::destroy($session_id) should either be compatible with SessionHandlerInterface::destroy(string $id): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 292
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Return type of CI_Session_database_driver::gc($maxlifetime) should either be compatible with SessionHandlerInterface::gc(int $max_lifetime): int|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 330
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CaracterizacionEstudiantes::$db is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 390
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated /Applications/MAMP/htdocs/integratic/system/database/DB_driver.php 371
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CaracterizacionEstudiantes::$session is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 1275
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CaracterizacionEstudiantes::$CaracterizacionEstudiantesPreguntas_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CaracterizacionEstudiantesRespuestas_Model::$table_students is deprecated /Applications/MAMP/htdocs/integratic/application/models/CaracterizacionEstudiantesRespuestas_Model.php 15
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CaracterizacionEstudiantes::$CaracterizacionEstudiantesRespuestas_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CaracterizacionEstudiantes::$Estudiante_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CaracterizacionEstudiantes::$DireccionGrupo_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> str_replace(): Passing null to parameter #3 ($subject) of type array|string is deprecated /Applications/MAMP/htdocs/integratic/system/core/Output.php 447
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated /Applications/MAMP/htdocs/integratic/system/core/URI.php 101
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated /Applications/MAMP/htdocs/integratic/system/core/Router.php 127
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Principal::$benchmark is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Principal::$hooks is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Principal::$config is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Principal::$log is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Principal::$utf8 is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Principal::$uri is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Principal::$exceptions is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Principal::$router is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Principal::$output is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Principal::$security is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Principal::$input is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Principal::$lang is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Principal::$load is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 78
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Return type of CI_Session_database_driver::open($save_path, $name) should either be compatible with SessionHandlerInterface::open(string $path, string $name): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 126
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Return type of CI_Session_database_driver::close() should either be compatible with SessionHandlerInterface::close(): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 275
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Return type of CI_Session_database_driver::read($session_id) should either be compatible with SessionHandlerInterface::read(string $id): string|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 146
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Return type of CI_Session_database_driver::write($session_id, $session_data) should either be compatible with SessionHandlerInterface::write(string $id, string $data): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 203
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Return type of CI_Session_database_driver::destroy($session_id) should either be compatible with SessionHandlerInterface::destroy(string $id): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 292
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Return type of CI_Session_database_driver::gc($maxlifetime) should either be compatible with SessionHandlerInterface::gc(int $max_lifetime): int|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 330
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Principal::$db is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 390
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated /Applications/MAMP/htdocs/integratic/system/database/DB_driver.php 371
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Principal::$session is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 1275
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Principal::$Consultas_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Principal::$Usuarios_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Principal::$Participantes_Prueba_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Principal::$Estudiante_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Consultas_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Usuarios_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Participantes_Prueba_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Estudiante_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Principal::$Configuracion_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Configuracion_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Principal::$Periodos_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Periodos_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated /Applications/MAMP/htdocs/integratic/system/core/URI.php 101
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated /Applications/MAMP/htdocs/integratic/system/core/Router.php 127
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated /Applications/MAMP/htdocs/integratic/system/core/URI.php 101
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$benchmark is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated /Applications/MAMP/htdocs/integratic/system/core/Router.php 127
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$hooks is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$config is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$log is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$utf8 is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$uri is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$exceptions is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$router is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$output is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$security is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$input is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$lang is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$load is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 78
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$benchmark is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$hooks is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$config is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$log is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$utf8 is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$uri is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$exceptions is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$router is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$output is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$security is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$input is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$lang is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$load is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 78
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Return type of CI_Session_database_driver::open($save_path, $name) should either be compatible with SessionHandlerInterface::open(string $path, string $name): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 126
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Return type of CI_Session_database_driver::close() should either be compatible with SessionHandlerInterface::close(): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 275
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Return type of CI_Session_database_driver::read($session_id) should either be compatible with SessionHandlerInterface::read(string $id): string|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 146
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Return type of CI_Session_database_driver::write($session_id, $session_data) should either be compatible with SessionHandlerInterface::write(string $id, string $data): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 203
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Return type of CI_Session_database_driver::destroy($session_id) should either be compatible with SessionHandlerInterface::destroy(string $id): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 292
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Return type of CI_Session_database_driver::gc($maxlifetime) should either be compatible with SessionHandlerInterface::gc(int $max_lifetime): int|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 330
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$db is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 390
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Return type of CI_Session_database_driver::open($save_path, $name) should either be compatible with SessionHandlerInterface::open(string $path, string $name): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 126
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Return type of CI_Session_database_driver::close() should either be compatible with SessionHandlerInterface::close(): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 275
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Return type of CI_Session_database_driver::read($session_id) should either be compatible with SessionHandlerInterface::read(string $id): string|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 146
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Return type of CI_Session_database_driver::write($session_id, $session_data) should either be compatible with SessionHandlerInterface::write(string $id, string $data): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 203
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Return type of CI_Session_database_driver::destroy($session_id) should either be compatible with SessionHandlerInterface::destroy(string $id): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 292
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Return type of CI_Session_database_driver::gc($maxlifetime) should either be compatible with SessionHandlerInterface::gc(int $max_lifetime): int|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 330
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$db is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 390
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated /Applications/MAMP/htdocs/integratic/system/database/DB_driver.php 371
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$session is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 1275
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$Anuncio_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:36:55 --> Severity: Warning --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> strtolower(): Passing null to parameter #1 ($string) of type string is deprecated /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-15 10:36:55 --> Severity: Warning --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated /Applications/MAMP/htdocs/integratic/system/database/DB_driver.php 371
ERROR - 2024-08-15 10:36:55 --> Severity: 8192 --> strtolower(): Passing null to parameter #1 ($string) of type string is deprecated /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$session is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 1275
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$Anuncio_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:36:56 --> Severity: Warning --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> strtolower(): Passing null to parameter #1 ($string) of type string is deprecated /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-15 10:36:56 --> Severity: Warning --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> strtolower(): Passing null to parameter #1 ($string) of type string is deprecated /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated /Applications/MAMP/htdocs/integratic/system/core/URI.php 101
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated /Applications/MAMP/htdocs/integratic/system/core/Router.php 127
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Creation of dynamic property Config::$benchmark is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Creation of dynamic property Config::$hooks is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Creation of dynamic property Config::$config is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Creation of dynamic property Config::$log is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Creation of dynamic property Config::$utf8 is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Creation of dynamic property Config::$uri is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Creation of dynamic property Config::$exceptions is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Creation of dynamic property Config::$router is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Creation of dynamic property Config::$output is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Creation of dynamic property Config::$security is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Creation of dynamic property Config::$input is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Creation of dynamic property Config::$lang is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Creation of dynamic property Config::$load is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 78
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Return type of CI_Session_database_driver::open($save_path, $name) should either be compatible with SessionHandlerInterface::open(string $path, string $name): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 126
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Return type of CI_Session_database_driver::close() should either be compatible with SessionHandlerInterface::close(): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 275
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Return type of CI_Session_database_driver::read($session_id) should either be compatible with SessionHandlerInterface::read(string $id): string|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 146
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Return type of CI_Session_database_driver::write($session_id, $session_data) should either be compatible with SessionHandlerInterface::write(string $id, string $data): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 203
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Return type of CI_Session_database_driver::destroy($session_id) should either be compatible with SessionHandlerInterface::destroy(string $id): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 292
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Return type of CI_Session_database_driver::gc($maxlifetime) should either be compatible with SessionHandlerInterface::gc(int $max_lifetime): int|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 330
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Creation of dynamic property Config::$db is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 390
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated /Applications/MAMP/htdocs/integratic/system/database/DB_driver.php 371
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Creation of dynamic property Config::$session is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 1275
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Creation of dynamic property Config::$General_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Creation of dynamic property Config::$Config_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Creation of dynamic property Config::$Consultas_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> Creation of dynamic property Config::$upload is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 1275
ERROR - 2024-08-15 10:36:56 --> Severity: 8192 --> str_replace(): Passing null to parameter #3 ($subject) of type array|string is deprecated /Applications/MAMP/htdocs/integratic/system/core/Output.php 447
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated /Applications/MAMP/htdocs/integratic/system/core/URI.php 101
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated /Applications/MAMP/htdocs/integratic/system/core/Router.php 127
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Principal::$benchmark is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Principal::$hooks is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Principal::$config is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Principal::$log is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Principal::$utf8 is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Principal::$uri is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Principal::$exceptions is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Principal::$router is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Principal::$output is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Principal::$security is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Principal::$input is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Principal::$lang is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Principal::$load is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 78
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Return type of CI_Session_database_driver::open($save_path, $name) should either be compatible with SessionHandlerInterface::open(string $path, string $name): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 126
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Return type of CI_Session_database_driver::close() should either be compatible with SessionHandlerInterface::close(): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 275
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Return type of CI_Session_database_driver::read($session_id) should either be compatible with SessionHandlerInterface::read(string $id): string|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 146
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Return type of CI_Session_database_driver::write($session_id, $session_data) should either be compatible with SessionHandlerInterface::write(string $id, string $data): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 203
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Return type of CI_Session_database_driver::destroy($session_id) should either be compatible with SessionHandlerInterface::destroy(string $id): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 292
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Return type of CI_Session_database_driver::gc($maxlifetime) should either be compatible with SessionHandlerInterface::gc(int $max_lifetime): int|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 330
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Principal::$db is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 390
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated /Applications/MAMP/htdocs/integratic/system/database/DB_driver.php 371
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Principal::$session is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 1275
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Principal::$Consultas_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Principal::$Usuarios_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Principal::$Participantes_Prueba_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Principal::$Estudiante_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Consultas_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Usuarios_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Participantes_Prueba_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Estudiante_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Principal::$Configuracion_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Configuracion_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Principal::$Periodos_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Periodos_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 918
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated /Applications/MAMP/htdocs/integratic/system/core/URI.php 101
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated /Applications/MAMP/htdocs/integratic/system/core/Router.php 127
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated /Applications/MAMP/htdocs/integratic/system/core/URI.php 101
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$benchmark is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$hooks is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$config is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$log is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$utf8 is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated /Applications/MAMP/htdocs/integratic/system/core/Router.php 127
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$uri is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$exceptions is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$router is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$output is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$security is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$input is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$lang is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$load is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 78
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$benchmark is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$hooks is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$config is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$log is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$utf8 is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$uri is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$exceptions is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$router is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$output is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$security is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$input is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$lang is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$load is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 78
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Return type of CI_Session_database_driver::open($save_path, $name) should either be compatible with SessionHandlerInterface::open(string $path, string $name): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 126
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Return type of CI_Session_database_driver::close() should either be compatible with SessionHandlerInterface::close(): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 275
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Return type of CI_Session_database_driver::read($session_id) should either be compatible with SessionHandlerInterface::read(string $id): string|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 146
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Return type of CI_Session_database_driver::write($session_id, $session_data) should either be compatible with SessionHandlerInterface::write(string $id, string $data): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 203
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Return type of CI_Session_database_driver::destroy($session_id) should either be compatible with SessionHandlerInterface::destroy(string $id): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 292
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Return type of CI_Session_database_driver::gc($maxlifetime) should either be compatible with SessionHandlerInterface::gc(int $max_lifetime): int|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 330
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$db is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 390
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Return type of CI_Session_database_driver::open($save_path, $name) should either be compatible with SessionHandlerInterface::open(string $path, string $name): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 126
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Return type of CI_Session_database_driver::close() should either be compatible with SessionHandlerInterface::close(): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 275
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Return type of CI_Session_database_driver::read($session_id) should either be compatible with SessionHandlerInterface::read(string $id): string|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 146
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Return type of CI_Session_database_driver::write($session_id, $session_data) should either be compatible with SessionHandlerInterface::write(string $id, string $data): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 203
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Return type of CI_Session_database_driver::destroy($session_id) should either be compatible with SessionHandlerInterface::destroy(string $id): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 292
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Return type of CI_Session_database_driver::gc($maxlifetime) should either be compatible with SessionHandlerInterface::gc(int $max_lifetime): int|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 330
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$db is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 390
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated /Applications/MAMP/htdocs/integratic/system/database/DB_driver.php 371
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$session is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 1275
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$Anuncio_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:37:01 --> Severity: Warning --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> strtolower(): Passing null to parameter #1 ($string) of type string is deprecated /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-15 10:37:01 --> Severity: Warning --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> strtolower(): Passing null to parameter #1 ($string) of type string is deprecated /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated /Applications/MAMP/htdocs/integratic/system/database/DB_driver.php 371
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated /Applications/MAMP/htdocs/integratic/system/core/URI.php 101
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated /Applications/MAMP/htdocs/integratic/system/core/Router.php 127
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$session is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 1275
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Notificaciones::$Anuncio_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:37:01 --> Severity: Warning --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> strtolower(): Passing null to parameter #1 ($string) of type string is deprecated /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-15 10:37:01 --> Severity: Warning --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> strtolower(): Passing null to parameter #1 ($string) of type string is deprecated /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Config::$benchmark is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Config::$hooks is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Config::$config is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Config::$log is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Config::$utf8 is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Config::$uri is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Config::$exceptions is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Config::$router is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Config::$output is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Config::$security is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Config::$input is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Config::$lang is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Config::$load is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 78
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Return type of CI_Session_database_driver::open($save_path, $name) should either be compatible with SessionHandlerInterface::open(string $path, string $name): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 126
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Return type of CI_Session_database_driver::close() should either be compatible with SessionHandlerInterface::close(): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 275
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Return type of CI_Session_database_driver::read($session_id) should either be compatible with SessionHandlerInterface::read(string $id): string|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 146
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Return type of CI_Session_database_driver::write($session_id, $session_data) should either be compatible with SessionHandlerInterface::write(string $id, string $data): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 203
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Return type of CI_Session_database_driver::destroy($session_id) should either be compatible with SessionHandlerInterface::destroy(string $id): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 292
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Return type of CI_Session_database_driver::gc($maxlifetime) should either be compatible with SessionHandlerInterface::gc(int $max_lifetime): int|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 330
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Config::$db is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 390
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated /Applications/MAMP/htdocs/integratic/system/database/DB_driver.php 371
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Config::$session is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 1275
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Config::$General_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Config::$Config_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Config::$Consultas_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> Creation of dynamic property Config::$upload is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 1275
ERROR - 2024-08-15 10:37:01 --> Severity: 8192 --> str_replace(): Passing null to parameter #3 ($subject) of type array|string is deprecated /Applications/MAMP/htdocs/integratic/system/core/Output.php 447
ERROR - 2024-08-15 10:37:03 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated /Applications/MAMP/htdocs/integratic/system/core/URI.php 101
ERROR - 2024-08-15 10:37:03 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated /Applications/MAMP/htdocs/integratic/system/core/Router.php 127
ERROR - 2024-08-15 10:37:03 --> 404 Page Not Found: Images/small
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated /Applications/MAMP/htdocs/integratic/system/core/URI.php 101
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated /Applications/MAMP/htdocs/integratic/system/core/Router.php 127
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Creation of dynamic property Config::$benchmark is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Creation of dynamic property Config::$hooks is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Creation of dynamic property Config::$config is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Creation of dynamic property Config::$log is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Creation of dynamic property Config::$utf8 is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Creation of dynamic property Config::$uri is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Creation of dynamic property Config::$exceptions is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Creation of dynamic property Config::$router is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Creation of dynamic property Config::$output is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Creation of dynamic property Config::$security is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Creation of dynamic property Config::$input is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Creation of dynamic property Config::$lang is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 75
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Creation of dynamic property Config::$load is deprecated /Applications/MAMP/htdocs/integratic/system/core/Controller.php 78
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Return type of CI_Session_database_driver::open($save_path, $name) should either be compatible with SessionHandlerInterface::open(string $path, string $name): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 126
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Return type of CI_Session_database_driver::close() should either be compatible with SessionHandlerInterface::close(): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 275
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Return type of CI_Session_database_driver::read($session_id) should either be compatible with SessionHandlerInterface::read(string $id): string|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 146
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Return type of CI_Session_database_driver::write($session_id, $session_data) should either be compatible with SessionHandlerInterface::write(string $id, string $data): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 203
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Return type of CI_Session_database_driver::destroy($session_id) should either be compatible with SessionHandlerInterface::destroy(string $id): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 292
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Return type of CI_Session_database_driver::gc($maxlifetime) should either be compatible with SessionHandlerInterface::gc(int $max_lifetime): int|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /Applications/MAMP/htdocs/integratic/system/libraries/Session/drivers/Session_database_driver.php 330
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Creation of dynamic property Config::$db is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 390
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated /Applications/MAMP/htdocs/integratic/system/database/DB_driver.php 371
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Creation of dynamic property Config::$session is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 1275
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Creation of dynamic property Config::$General_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Creation of dynamic property Config::$Config_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Creation of dynamic property Config::$Consultas_Model is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 353
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> Creation of dynamic property Config::$upload is deprecated /Applications/MAMP/htdocs/integratic/system/core/Loader.php 1275
ERROR - 2024-08-15 10:37:04 --> Severity: 8192 --> str_replace(): Passing null to parameter #3 ($subject) of type array|string is deprecated /Applications/MAMP/htdocs/integratic/system/core/Output.php 447
ERROR - 2024-08-15 10:37:22 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-15 10:37:22 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-15 10:37:22 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-15 10:37:22 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-15 10:37:22 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-08-15 10:37:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 10:37:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 10:37:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 10:37:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 10:37:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 10:37:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 10:37:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 10:37:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 10:37:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 10:37:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 10:37:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 10:37:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 10:37:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 10:37:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 10:37:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 10:37:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 10:37:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 10:37:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 10:37:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 10:37:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 10:37:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 10:37:27 --> 404 Page Not Found: Images/small
ERROR - 2024-08-15 10:37:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 10:37:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 10:37:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 10:37:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 10:37:41 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.u.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `u`.*, `e`.*, `e`.`email` as `email`, `cer`.`id_pregunta`
FROM `estudiante` `e`
LEFT JOIN `usuarios` `u` ON `e`.`documento` = `u`.`id`
LEFT OUTER JOIN `caracterizacion_estudiantes_respuestas` `cer` ON `cer`.`id_estudiante` = `u`.`id`
GROUP BY `e`.`documento`
ORDER BY `e`.`grado` ASC, `e`.`nombre` ASC
ERROR - 2024-08-15 10:38:13 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2024-08-15 10:47:23 --> Severity: Notice --> Undefined variable: plan_area /Applications/MAMP/htdocs/integratic/application/views/caracterizacion_estudiantes/pdf.php 18
ERROR - 2024-08-15 10:47:23 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/caracterizacion_estudiantes/pdf.php 18
ERROR - 2024-08-15 10:48:05 --> Severity: Notice --> Undefined variable: plan_area /Applications/MAMP/htdocs/integratic/application/views/caracterizacion_estudiantes/pdf.php 18
ERROR - 2024-08-15 10:48:05 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/caracterizacion_estudiantes/pdf.php 18
ERROR - 2024-08-15 12:38:56 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/application/views/caracterizacion_estudiantes/pdf.php 322
ERROR - 2024-08-15 12:38:56 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 56
ERROR - 2024-08-15 12:38:56 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 56
ERROR - 2024-08-15 12:40:16 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/application/views/caracterizacion_estudiantes/pdf.php 322
ERROR - 2024-08-15 12:40:16 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/application/views/caracterizacion_estudiantes/pdf.php 325
ERROR - 2024-08-15 12:40:16 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 56
ERROR - 2024-08-15 12:40:16 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 56
ERROR - 2024-08-15 12:41:29 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/application/views/caracterizacion_estudiantes/pdf.php 322
ERROR - 2024-08-15 12:41:29 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/application/views/caracterizacion_estudiantes/pdf.php 325
ERROR - 2024-08-15 12:41:29 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 56
ERROR - 2024-08-15 12:41:29 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 56
ERROR - 2024-08-15 12:41:30 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/application/views/caracterizacion_estudiantes/pdf.php 322
ERROR - 2024-08-15 12:41:30 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/application/views/caracterizacion_estudiantes/pdf.php 325
ERROR - 2024-08-15 12:41:30 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 56
ERROR - 2024-08-15 12:41:30 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 56
ERROR - 2024-08-15 12:41:44 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/application/views/caracterizacion_estudiantes/pdf.php 325
ERROR - 2024-08-15 12:41:44 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 56
ERROR - 2024-08-15 12:41:44 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 56
ERROR - 2024-08-15 12:42:21 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/application/views/caracterizacion_estudiantes/pdf.php 325
ERROR - 2024-08-15 12:42:21 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 56
ERROR - 2024-08-15 12:42:21 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 56
ERROR - 2024-08-15 13:33:36 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2024-08-15 13:33:37 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-15 13:33:37 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-15 13:33:37 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-15 13:33:37 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-15 13:33:38 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-08-15 13:33:38 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:33:38 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:33:38 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:33:38 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:33:38 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:33:38 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:33:38 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:33:38 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:33:38 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:33:38 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:33:38 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:33:38 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:33:38 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:33:38 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:33:38 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:33:38 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:33:38 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:33:38 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:33:38 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:33:38 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:33:38 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:33:39 --> 404 Page Not Found: Images/small
ERROR - 2024-08-15 13:33:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-15 13:33:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-15 13:33:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-15 13:33:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-15 13:33:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-15 13:33:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-15 13:33:54 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-15 13:33:54 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-15 13:33:54 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-15 13:33:55 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-15 13:33:55 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-15 13:33:55 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-15 13:33:55 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-15 13:40:06 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-15 13:40:06 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-15 13:40:06 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-15 13:45:43 --> Severity: error --> Exception: Class 'Options' not found /Applications/MAMP/htdocs/integratic/application/controllers/CaracterizacionEstudiantes.php 144
ERROR - 2024-08-15 13:49:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-15 13:49:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-15 13:49:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-15 13:49:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-15 13:49:41 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-15 13:49:41 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-15 13:49:41 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-15 13:49:41 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-15 13:49:41 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-15 13:49:41 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-15 13:49:41 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-15 13:49:41 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-15 13:49:41 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-08-15 13:49:41 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:49:41 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:49:41 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:49:41 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:49:41 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:49:41 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:49:41 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:49:41 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:49:41 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:49:41 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:49:41 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:49:41 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:49:41 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:49:41 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:49:41 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:49:41 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:49:41 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:49:41 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:49:41 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:49:41 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:49:41 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:49:42 --> 404 Page Not Found: Images/small
ERROR - 2024-08-15 13:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-15 13:53:26 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2024-08-15 13:53:27 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-15 13:54:24 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-15 13:54:39 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-15 13:55:01 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-15 13:55:13 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-15 13:56:15 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-15 13:56:27 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-15 13:56:38 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-15 13:56:46 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-15 13:57:12 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-15 13:57:22 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
