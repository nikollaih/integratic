<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-02-27 08:37:09 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-27 08:37:09 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-27 08:37:09 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-27 08:37:09 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-27 08:37:09 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-02-27 08:37:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 08:37:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 08:37:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 08:37:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 08:37:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 08:37:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 08:37:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 08:37:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 08:37:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 08:37:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 08:37:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 08:37:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 08:37:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 08:37:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 08:37:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 08:37:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 08:37:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 08:37:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 08:37:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 08:37:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 08:37:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 08:37:11 --> 404 Page Not Found: Images/small
ERROR - 2025-02-27 08:37:22 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-27 08:37:23 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-27 08:56:33 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-27 08:56:33 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-27 08:56:48 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-27 08:56:48 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-27 08:58:35 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-27 08:58:35 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-27 09:15:09 --> Severity: Notice --> Undefined variable: item_piar_annual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_annual_form.php 6
ERROR - 2025-02-27 09:15:09 --> Severity: Notice --> Undefined variable: item_piar_annual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_annual_form.php 53
ERROR - 2025-02-27 09:40:12 --> Severity: Notice --> Undefined variable: item_piar_annual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_annual_form.php 6
ERROR - 2025-02-27 09:40:12 --> Severity: Notice --> Undefined variable: item_piar_annual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_annual_form.php 53
ERROR - 2025-02-27 09:40:12 --> Severity: Notice --> Undefined variable: item_piar_annual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_annual_form.php 63
ERROR - 2025-02-27 09:40:12 --> Severity: Notice --> Undefined variable: item_piar_annual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_annual_form.php 73
ERROR - 2025-02-27 09:40:12 --> Severity: Notice --> Undefined variable: item_piar_annual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_annual_form.php 83
ERROR - 2025-02-27 09:40:12 --> Severity: Notice --> Undefined variable: item_piar_annual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_annual_form.php 93
ERROR - 2025-02-27 09:40:32 --> Severity: Notice --> Undefined index: id_piar_item_anual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_annual_form.php 6
ERROR - 2025-02-27 09:40:32 --> Severity: Notice --> Undefined index: destrezas_obtenidas /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_annual_form.php 53
ERROR - 2025-02-27 09:40:32 --> Severity: Notice --> Undefined index: dificultades /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_annual_form.php 63
ERROR - 2025-02-27 09:40:32 --> Severity: Notice --> Undefined index: comportamiento /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_annual_form.php 73
ERROR - 2025-02-27 09:40:32 --> Severity: Notice --> Undefined index: desempeno /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_annual_form.php 83
ERROR - 2025-02-27 09:40:32 --> Severity: Notice --> Undefined index: recomendaciones /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_annual_form.php 93
ERROR - 2025-02-27 09:50:29 --> Severity: Notice --> Undefined index: id_piar_annual_item /Applications/MAMP/htdocs/integratic/application/controllers/PIAR.php 268
ERROR - 2025-02-27 09:50:34 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-27 09:50:34 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-27 09:50:40 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-27 09:50:40 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-27 09:50:46 --> Severity: Notice --> Undefined index: id_piar_annual_item /Applications/MAMP/htdocs/integratic/application/controllers/PIAR.php 268
ERROR - 2025-02-27 09:51:00 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-27 09:51:00 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-27 09:51:08 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-27 09:51:08 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-27 10:28:51 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-27 10:28:54 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-27 10:28:54 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-27 10:28:54 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-27 10:28:54 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-27 10:28:54 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-27 10:28:54 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-27 10:28:54 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-27 10:28:54 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-27 10:28:54 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-02-27 10:28:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 10:28:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 10:28:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 10:28:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 10:28:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 10:28:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 10:28:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 10:28:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 10:28:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 10:28:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 10:28:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 10:28:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 10:28:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 10:28:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 10:28:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 10:28:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 10:28:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 10:28:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 10:28:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 10:28:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 10:28:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-27 10:28:56 --> 404 Page Not Found: Images/small
ERROR - 2025-02-27 10:29:03 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-27 10:29:03 --> 404 Page Not Found: Img/iconos
