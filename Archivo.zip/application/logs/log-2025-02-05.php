<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-02-05 15:59:24 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-05 15:59:24 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-05 15:59:24 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-05 15:59:24 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-05 15:59:24 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-02-05 15:59:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 15:59:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 15:59:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 15:59:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 15:59:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 15:59:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 15:59:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 15:59:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 15:59:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 15:59:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 15:59:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 15:59:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 15:59:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 15:59:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 15:59:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 15:59:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 15:59:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 15:59:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 15:59:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 15:59:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 15:59:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 15:59:57 --> 404 Page Not Found: Images/small
ERROR - 2025-02-05 15:59:59 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 15:59:59 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 15:59:59 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 15:59:59 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:02:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:02:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:03:54 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-05 16:03:54 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-05 16:03:54 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-05 16:03:54 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-05 16:03:54 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-05 16:03:54 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-05 16:03:54 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-05 16:03:54 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-05 16:03:54 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-02-05 16:03:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:03:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:03:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:03:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:03:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:03:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:03:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:03:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:03:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:03:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:03:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:03:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:03:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:03:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:03:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:03:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:03:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:03:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:03:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:03:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:03:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:03:55 --> 404 Page Not Found: Images/small
ERROR - 2025-02-05 16:04:57 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-05 16:05:02 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-05 16:06:16 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-05 16:06:33 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 44
ERROR - 2025-02-05 16:06:33 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 44
ERROR - 2025-02-05 16:06:33 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 62
ERROR - 2025-02-05 16:06:33 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 62
ERROR - 2025-02-05 16:06:33 --> Severity: Notice --> Undefined variable: items_piar /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 212
ERROR - 2025-02-05 16:07:08 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 44
ERROR - 2025-02-05 16:07:08 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 44
ERROR - 2025-02-05 16:07:08 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 62
ERROR - 2025-02-05 16:07:08 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 62
ERROR - 2025-02-05 16:07:08 --> Severity: Notice --> Undefined variable: items_piar /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 212
ERROR - 2025-02-05 16:08:17 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 44
ERROR - 2025-02-05 16:08:17 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 44
ERROR - 2025-02-05 16:08:17 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 62
ERROR - 2025-02-05 16:08:17 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 62
ERROR - 2025-02-05 16:09:11 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 44
ERROR - 2025-02-05 16:09:11 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 44
ERROR - 2025-02-05 16:09:11 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 62
ERROR - 2025-02-05 16:09:11 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 62
ERROR - 2025-02-05 16:20:18 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-05 16:20:20 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-05 16:20:20 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-05 16:20:20 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-05 16:20:20 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-05 16:20:20 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-05 16:20:20 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-05 16:20:20 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-05 16:20:20 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-05 16:20:20 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-02-05 16:20:20 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:20 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:20 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:20 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:20 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:20 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:20 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:20 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:20 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:20 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:20 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:20 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:20 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:20 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:20 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:20 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:20 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:20 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:20 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:22 --> 404 Page Not Found: Images/small
ERROR - 2025-02-05 16:20:23 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:23 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:23 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:23 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:30 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-05 16:20:30 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-05 16:20:30 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-05 16:20:30 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-05 16:20:30 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-05 16:20:30 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-05 16:20:30 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-05 16:20:30 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-05 16:20:30 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-02-05 16:20:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 16:20:31 --> 404 Page Not Found: Images/small
ERROR - 2025-02-05 16:20:37 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-05 16:20:37 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-05 16:20:41 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.u.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `u`.*, `e`.*, `e`.`email` as `email`, `cer_responses`.`caracterizacion_respuestas`
FROM `estudiante` `e`
LEFT JOIN `usuarios` `u` ON `e`.`documento` = `u`.`id`
LEFT OUTER JOIN (SELECT `cer`.`id_estudiante`, JSON_ARRAYAGG(JSON_OBJECT("id_pregunta", `cer`.`id_pregunta`, "respuesta", cer.respuesta)) as caracterizacion_respuestas
FROM `caracterizacion_estudiantes_respuestas` `cer`
GROUP BY `cer`.`id_estudiante`) as cer_responses ON `cer_responses`.`id_estudiante` = `u`.`id`
WHERE `e`.`grado` = '11A'
GROUP BY `e`.`documento`
ORDER BY `e`.`grado` ASC, `e`.`nombre` ASC
ERROR - 2025-02-05 16:21:33 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2025-02-05 16:22:23 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-05 16:26:27 --> Severity: error --> Exception: Call to undefined function obtenerRespuesta() /Applications/MAMP/htdocs/integratic/application/views/piar/view.php 48
ERROR - 2025-02-05 16:26:44 --> Severity: error --> Exception: Call to undefined function obtenerRespuesta() /Applications/MAMP/htdocs/integratic/application/views/piar/view.php 48
ERROR - 2025-02-05 16:32:58 --> Severity: Notice --> Undefined index: created_at /Applications/MAMP/htdocs/integratic/application/views/piar/view.php 24
ERROR - 2025-02-05 18:41:50 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-05 18:41:50 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-05 18:41:50 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-05 18:41:50 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-05 18:41:50 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-02-05 18:41:50 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 18:41:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 18:41:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 18:41:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 18:41:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 18:41:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 18:41:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 18:41:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 18:41:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 18:41:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 18:41:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 18:41:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 18:41:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 18:41:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 18:41:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 18:41:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 18:41:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 18:41:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 18:41:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 18:41:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 18:41:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-05 18:41:52 --> 404 Page Not Found: Images/small
ERROR - 2025-02-05 18:42:00 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-05 18:42:00 --> 404 Page Not Found: Img/iconos
