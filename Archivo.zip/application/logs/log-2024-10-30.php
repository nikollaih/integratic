<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-10-30 13:35:03 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-10-30 13:35:03 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-10-30 13:35:03 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-10-30 13:35:03 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-10-30 13:35:03 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-10-30 13:35:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 13:35:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 13:35:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 13:35:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 13:35:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 13:35:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 13:35:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 13:35:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 13:35:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 13:35:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 13:35:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 13:35:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 13:35:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 13:35:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 13:35:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 13:35:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 13:35:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 13:35:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 13:35:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 13:35:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 13:35:03 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 13:35:05 --> 404 Page Not Found: Images/small
ERROR - 2024-10-30 13:35:10 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:35:10 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:35:10 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:35:10 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:36:38 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:36:38 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:36:38 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:36:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:36:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:36:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:36:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:36:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:36:48 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:36:48 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:38:07 --> Severity: error --> Exception: Call to undefined function toLowerCase() /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/index.php 16
ERROR - 2024-10-30 13:38:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:38:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:39:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:39:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:39:12 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:39:12 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:41:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:48:49 --> Severity: Notice --> Undefined property: Recuperaciones::$Usuarios_Model /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 23
ERROR - 2024-10-30 13:48:49 --> Severity: error --> Exception: Call to a member function get_by_role() on null /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 23
ERROR - 2024-10-30 13:49:06 --> Severity: Notice --> Undefined index: user_id /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/index.php 25
ERROR - 2024-10-30 13:49:06 --> Severity: Notice --> Undefined index: first_name /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/index.php 25
ERROR - 2024-10-30 13:49:06 --> Severity: Notice --> Undefined index: user_id /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/index.php 25
ERROR - 2024-10-30 13:49:06 --> Severity: Notice --> Undefined index: first_name /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/index.php 25
ERROR - 2024-10-30 13:49:06 --> Severity: Notice --> Undefined variable: recuperaciones /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/index.php 60
ERROR - 2024-10-30 13:49:06 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:50:16 --> Severity: Notice --> Undefined variable: recuperaciones /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/index.php 60
ERROR - 2024-10-30 13:50:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:51:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:51:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:52:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:52:22 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:52:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:52:29 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:52:34 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:52:41 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 13:52:41 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 13:52:41 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 13:52:41 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 13:52:41 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 13:52:41 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 13:52:41 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 13:52:41 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 13:52:41 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 13:52:41 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 13:52:41 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 13:52:41 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 13:52:41 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 13:52:41 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 13:52:41 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 13:52:41 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:52:42 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 13:52:42 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 13:52:42 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 13:52:42 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 13:52:42 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 13:52:42 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 13:52:42 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 13:52:42 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 13:52:42 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 13:52:42 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 13:52:42 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 13:52:42 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 13:52:42 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 13:52:42 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 13:52:42 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 13:52:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:52:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:54:17 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:54:55 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:55:19 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:55:33 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:55:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:56:01 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:56:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:56:15 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:56:15 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:56:15 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:56:16 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 85
ERROR - 2024-10-30 13:56:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:56:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:56:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:56:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:56:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:57:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:58:15 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:58:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:58:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:58:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:58:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 13:58:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:02:23 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:02:28 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:02:29 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:02:32 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:02:48 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:02:51 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:03:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:04:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:06:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:07:19 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:07:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:07:56 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:11:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:12:58 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:13:00 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:13:00 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:13:00 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 14:13:00 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:13:00 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:13:00 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:13:00 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:13:00 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 14:13:00 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:13:00 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:13:00 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:13:00 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:13:00 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 14:13:00 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:13:00 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:13:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:13:01 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:13:01 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:13:01 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 14:13:01 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:13:01 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:13:01 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:13:01 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:13:01 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 14:13:01 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:13:01 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:13:01 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:13:01 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:13:01 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 14:13:01 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:13:01 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:13:12 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:13:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:13:17 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:13:29 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:13:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:13:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:13:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:14:35 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:15:12 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:15:12 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:15:12 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:15:14 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-10-30 14:15:14 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-10-30 14:15:14 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-10-30 14:15:14 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-10-30 14:15:14 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-10-30 14:15:14 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-10-30 14:15:14 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-10-30 14:15:14 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-10-30 14:15:14 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-10-30 14:15:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:15 --> 404 Page Not Found: Images/small
ERROR - 2024-10-30 14:15:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:15:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:15:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:15:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:15:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:15:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:15:33 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-10-30 14:15:33 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-10-30 14:15:33 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-10-30 14:15:33 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-10-30 14:15:33 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-10-30 14:15:33 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-10-30 14:15:33 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-10-30 14:15:33 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-10-30 14:15:33 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-10-30 14:15:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:15:34 --> 404 Page Not Found: Images/small
ERROR - 2024-10-30 14:15:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:15:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:15:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:15:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:15:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:15:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:15:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:15:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:15:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:16:38 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:16:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 98
ERROR - 2024-10-30 14:16:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 99
ERROR - 2024-10-30 14:16:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 100
ERROR - 2024-10-30 14:16:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 21
ERROR - 2024-10-30 14:16:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 23
ERROR - 2024-10-30 14:16:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 24
ERROR - 2024-10-30 14:16:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 25
ERROR - 2024-10-30 14:16:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 42
ERROR - 2024-10-30 14:16:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 46
ERROR - 2024-10-30 14:16:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 50
ERROR - 2024-10-30 14:16:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 54
ERROR - 2024-10-30 14:16:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 58
ERROR - 2024-10-30 14:16:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 62
ERROR - 2024-10-30 14:16:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 66
ERROR - 2024-10-30 14:16:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 70
ERROR - 2024-10-30 14:16:48 --> Query error: Expression #11 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.pp.id_asignacion_participante_prueba' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT *
FROM `core_participantes_pruebas` `cpp`
JOIN `asignacion_participantes_prueba` `pp` ON `pp`.`id_participante` = `cpp`.`id_participante_prueba`
LEFT JOIN `municipios` `m` ON `m`.`id_municipio` = `cpp`.`municipio`
LEFT JOIN `instituciones_educativas` `ie` ON `ie`.`id_institucion_educativa` = `cpp`.`institucion`
WHERE `pp`.`id_prueba` = '1'
GROUP BY `cpp`.`id_participante_prueba`
ORDER BY `cpp`.`apellidos` ASC
ERROR - 2024-10-30 14:16:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 98
ERROR - 2024-10-30 14:16:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 99
ERROR - 2024-10-30 14:16:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 100
ERROR - 2024-10-30 14:16:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 21
ERROR - 2024-10-30 14:16:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 23
ERROR - 2024-10-30 14:16:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 24
ERROR - 2024-10-30 14:16:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 25
ERROR - 2024-10-30 14:16:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 42
ERROR - 2024-10-30 14:16:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 46
ERROR - 2024-10-30 14:16:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 50
ERROR - 2024-10-30 14:16:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 54
ERROR - 2024-10-30 14:16:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 58
ERROR - 2024-10-30 14:16:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 62
ERROR - 2024-10-30 14:16:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 66
ERROR - 2024-10-30 14:16:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 70
ERROR - 2024-10-30 14:17:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 98
ERROR - 2024-10-30 14:17:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 99
ERROR - 2024-10-30 14:17:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 100
ERROR - 2024-10-30 14:17:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 21
ERROR - 2024-10-30 14:17:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 23
ERROR - 2024-10-30 14:17:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 24
ERROR - 2024-10-30 14:17:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 25
ERROR - 2024-10-30 14:17:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 42
ERROR - 2024-10-30 14:17:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 46
ERROR - 2024-10-30 14:17:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 50
ERROR - 2024-10-30 14:17:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 54
ERROR - 2024-10-30 14:17:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 58
ERROR - 2024-10-30 14:17:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 62
ERROR - 2024-10-30 14:17:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 66
ERROR - 2024-10-30 14:17:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 70
ERROR - 2024-10-30 14:17:35 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:17:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 98
ERROR - 2024-10-30 14:17:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 99
ERROR - 2024-10-30 14:17:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 100
ERROR - 2024-10-30 14:17:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 21
ERROR - 2024-10-30 14:17:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 23
ERROR - 2024-10-30 14:17:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 24
ERROR - 2024-10-30 14:17:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 25
ERROR - 2024-10-30 14:17:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 42
ERROR - 2024-10-30 14:17:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 46
ERROR - 2024-10-30 14:17:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 50
ERROR - 2024-10-30 14:17:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 54
ERROR - 2024-10-30 14:17:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 58
ERROR - 2024-10-30 14:17:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 62
ERROR - 2024-10-30 14:17:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 66
ERROR - 2024-10-30 14:17:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 70
ERROR - 2024-10-30 14:18:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 98
ERROR - 2024-10-30 14:18:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 99
ERROR - 2024-10-30 14:18:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 100
ERROR - 2024-10-30 14:18:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 21
ERROR - 2024-10-30 14:18:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 29
ERROR - 2024-10-30 14:18:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 46
ERROR - 2024-10-30 14:18:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 50
ERROR - 2024-10-30 14:18:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 54
ERROR - 2024-10-30 14:18:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 58
ERROR - 2024-10-30 14:18:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 62
ERROR - 2024-10-30 14:18:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 66
ERROR - 2024-10-30 14:18:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 70
ERROR - 2024-10-30 14:18:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 74
ERROR - 2024-10-30 14:18:34 --> Query error: Expression #11 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.pp.id_asignacion_participante_prueba' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT *
FROM `core_participantes_pruebas` `cpp`
JOIN `asignacion_participantes_prueba` `pp` ON `pp`.`id_participante` = `cpp`.`id_participante_prueba`
LEFT JOIN `municipios` `m` ON `m`.`id_municipio` = `cpp`.`municipio`
LEFT JOIN `instituciones_educativas` `ie` ON `ie`.`id_institucion_educativa` = `cpp`.`institucion`
WHERE `pp`.`id_prueba` = '1'
GROUP BY `cpp`.`id_participante_prueba`
ORDER BY `cpp`.`apellidos` ASC
ERROR - 2024-10-30 14:18:57 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 237
ERROR - 2024-10-30 14:18:57 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 238
ERROR - 2024-10-30 14:18:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 4 - Invalid query: SELECT *
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE materia IN()
ERROR - 2024-10-30 14:20:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 237
ERROR - 2024-10-30 14:20:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 238
ERROR - 2024-10-30 14:20:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 4 - Invalid query: SELECT *
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE materia IN()
ERROR - 2024-10-30 14:21:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 237
ERROR - 2024-10-30 14:21:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 238
ERROR - 2024-10-30 14:21:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 4 - Invalid query: SELECT *
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE materia IN()
ERROR - 2024-10-30 14:22:58 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 237
ERROR - 2024-10-30 14:22:58 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 238
ERROR - 2024-10-30 14:22:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 4 - Invalid query: SELECT *
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE materia IN()
ERROR - 2024-10-30 14:23:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2024-10-30 14:23:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2024-10-30 14:23:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 237
ERROR - 2024-10-30 14:23:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 238
ERROR - 2024-10-30 14:23:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 4 - Invalid query: SELECT *
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE materia IN()
ERROR - 2024-10-30 14:23:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 237
ERROR - 2024-10-30 14:23:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 238
ERROR - 2024-10-30 14:23:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 4 - Invalid query: SELECT *
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE materia IN()
ERROR - 2024-10-30 14:24:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 237
ERROR - 2024-10-30 14:24:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 238
ERROR - 2024-10-30 14:24:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 4 - Invalid query: SELECT *
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE materia IN()
ERROR - 2024-10-30 14:24:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 98
ERROR - 2024-10-30 14:24:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 99
ERROR - 2024-10-30 14:24:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 100
ERROR - 2024-10-30 14:24:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 21
ERROR - 2024-10-30 14:24:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 29
ERROR - 2024-10-30 14:24:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 46
ERROR - 2024-10-30 14:24:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 50
ERROR - 2024-10-30 14:24:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 54
ERROR - 2024-10-30 14:24:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 58
ERROR - 2024-10-30 14:24:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 62
ERROR - 2024-10-30 14:24:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 66
ERROR - 2024-10-30 14:24:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 70
ERROR - 2024-10-30 14:24:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 74
ERROR - 2024-10-30 14:24:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 98
ERROR - 2024-10-30 14:24:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 99
ERROR - 2024-10-30 14:24:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 100
ERROR - 2024-10-30 14:24:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 21
ERROR - 2024-10-30 14:24:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 29
ERROR - 2024-10-30 14:24:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 46
ERROR - 2024-10-30 14:24:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 50
ERROR - 2024-10-30 14:24:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 54
ERROR - 2024-10-30 14:24:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 58
ERROR - 2024-10-30 14:24:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 62
ERROR - 2024-10-30 14:24:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 66
ERROR - 2024-10-30 14:24:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 70
ERROR - 2024-10-30 14:24:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/ver_prueba.php 74
ERROR - 2024-10-30 14:25:10 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:25:13 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:26:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:26:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:26:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:26:48 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-10-30 14:26:48 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-10-30 14:26:48 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-10-30 14:26:48 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-10-30 14:26:48 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-10-30 14:26:48 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-10-30 14:26:48 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-10-30 14:26:48 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-10-30 14:26:48 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-10-30 14:26:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:26:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:26:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:26:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:26:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:26:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:26:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:26:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:26:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:26:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:26:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:26:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:26:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:26:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:26:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:26:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:26:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:26:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:26:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:26:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:26:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 14:26:49 --> 404 Page Not Found: Images/small
ERROR - 2024-10-30 14:26:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:26:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:27:22 --> Severity: Warning --> mkdir(): File exists /Applications/MAMP/htdocs/integratic/application/controllers/Actividades.php 116
ERROR - 2024-10-30 14:27:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:27:46 --> Severity: Warning --> mkdir(): File exists /Applications/MAMP/htdocs/integratic/application/controllers/Actividades.php 116
ERROR - 2024-10-30 14:27:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:28:07 --> Severity: Warning --> mkdir(): File exists /Applications/MAMP/htdocs/integratic/application/controllers/Actividades.php 116
ERROR - 2024-10-30 14:28:09 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:29:58 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:30:04 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:31:04 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:31:05 --> Severity: Notice --> Undefined variable: recuperaciones /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/index.php 66
ERROR - 2024-10-30 14:31:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:32:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:35:01 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:35:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:35:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:35:48 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:36:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:36:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:39:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:39:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:40:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:40:22 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2024-10-30 14:40:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2024-10-30 14:40:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2024-10-30 14:40:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2024-10-30 14:40:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2024-10-30 14:40:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2024-10-30 14:40:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2024-10-30 14:40:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2024-10-30 14:40:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2024-10-30 14:40:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2024-10-30 14:40:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2024-10-30 14:40:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2024-10-30 14:40:30 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2024-10-30 14:40:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2024-10-30 14:40:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2024-10-30 14:40:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2024-10-30 14:40:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2024-10-30 14:40:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2024-10-30 14:40:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2024-10-30 14:40:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2024-10-30 14:40:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2024-10-30 14:40:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2024-10-30 14:40:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2024-10-30 14:40:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2024-10-30 14:40:34 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2024-10-30 14:40:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2024-10-30 14:40:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2024-10-30 14:40:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2024-10-30 14:40:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2024-10-30 14:40:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2024-10-30 14:40:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2024-10-30 14:40:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2024-10-30 14:40:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2024-10-30 14:40:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2024-10-30 14:40:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2024-10-30 14:40:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2024-10-30 14:40:48 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:40:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:44:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:45:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:45:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:45:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:47:06 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:47:16 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:47:16 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:47:16 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 14:47:16 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:47:16 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:47:16 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:47:16 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:47:16 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 14:47:16 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:47:16 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:47:16 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:47:16 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:47:16 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 14:47:16 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:47:16 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:47:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:47:16 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:47:16 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:47:16 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 14:47:16 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:47:16 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:47:16 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:47:16 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:47:16 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 14:47:16 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:47:16 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:47:16 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:47:16 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:47:16 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 14:47:16 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:47:16 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Undefined index: estudiante_notas /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 89
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Undefined index: docente_notas /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 90
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:50:56 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:50:56 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:50:56 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:50:56 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Undefined index: estudiante_notas /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 89
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Undefined index: docente_notas /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 90
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:50:56 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:50:56 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 14:50:56 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:50:56 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Undefined index: estudiante_notas /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 43
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Undefined index: docente_notas /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 44
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Undefined index: estudiante_notas /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 43
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Undefined index: docente_notas /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 44
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:51:23 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:51:23 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:51:23 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:51:23 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:51:23 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:51:23 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 14:51:23 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:51:23 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:51:53 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:51:53 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:51:53 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 14:51:53 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:51:53 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:51:53 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:51:53 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:51:53 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 14:51:53 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:51:53 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:51:53 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:51:53 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:51:53 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 14:51:53 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:51:53 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:51:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:51:53 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:51:53 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:51:53 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 14:51:53 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:51:53 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:51:53 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:51:53 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:51:53 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 14:51:53 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:51:53 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:51:53 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:51:53 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:51:53 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 14:51:53 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:51:53 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:52:11 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-30 14:52:11 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-30 14:53:39 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:53:39 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:53:39 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 14:53:39 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:53:39 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:53:39 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:53:39 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:53:39 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 14:53:39 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:53:39 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:53:39 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:53:39 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:53:39 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 14:53:39 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:53:39 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:53:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:53:39 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:53:40 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:53:40 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 14:53:40 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:53:40 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:53:40 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:53:40 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:53:40 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 14:53:40 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:53:40 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:53:40 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:53:40 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:53:40 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 14:53:40 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:53:40 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:53:40 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-30 14:53:40 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-30 14:54:18 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:54:18 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:54:18 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 14:54:18 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:54:18 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:54:18 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:54:18 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:54:18 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 14:54:18 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:54:18 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:54:18 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:54:18 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:54:18 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 14:54:18 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:54:18 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:54:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:54:18 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:54:18 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:54:18 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 14:54:18 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:54:18 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:54:18 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:54:18 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:54:18 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 14:54:18 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:54:18 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:54:18 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:54:18 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:54:18 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 14:54:18 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:54:18 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:54:56 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:54:56 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 14:54:56 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:54:56 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:54:56 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:54:56 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 14:54:56 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:54:56 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:54:56 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:54:56 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:54:56 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 14:54:56 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:54:56 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:54:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:54:57 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:54:57 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:54:57 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 14:54:57 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:54:57 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:54:57 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:54:57 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:54:57 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 14:54:57 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:54:57 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:54:57 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:54:57 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:54:57 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 14:54:57 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:54:57 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:55:43 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:55:43 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:55:43 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 14:55:43 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:55:43 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:55:43 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:55:43 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:55:43 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 14:55:43 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:55:43 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:55:43 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:55:43 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:55:43 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 14:55:43 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:55:43 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:55:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:55:44 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:55:44 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:55:44 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 14:55:44 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:55:44 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:55:44 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:55:44 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:55:44 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 14:55:44 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:55:44 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:55:44 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:55:44 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:55:44 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 14:55:44 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:55:44 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:56:13 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:56:13 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:56:13 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 14:56:13 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:56:13 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:56:13 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:56:13 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:56:13 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 14:56:13 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:56:13 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:56:13 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:56:13 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:56:13 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 14:56:13 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:56:13 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:56:13 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:56:13 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:56:13 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:56:13 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 14:56:13 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:56:13 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:56:13 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:56:13 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:56:13 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 14:56:13 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:56:13 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:56:13 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:56:13 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:56:13 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 14:56:13 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:56:13 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:56:49 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 88
ERROR - 2024-10-30 14:56:49 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:56:49 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:56:49 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 14:56:49 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:56:49 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:56:49 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:56:49 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:56:49 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 14:56:49 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:56:49 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:56:49 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:56:49 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:56:49 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 14:56:49 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:56:49 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:56:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:56:50 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 88
ERROR - 2024-10-30 14:56:50 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:56:50 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:56:50 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 14:56:50 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:56:50 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:56:50 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:56:50 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:56:50 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 14:56:50 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:56:50 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:56:50 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:56:50 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:56:50 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 14:56:50 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:56:50 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:57:06 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:57:06 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:57:06 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 14:57:06 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:57:06 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:57:06 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:57:06 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 14:57:06 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:57:06 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:57:06 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:57:06 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 14:57:06 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:57:06 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 14:57:06 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:57:06 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 14:57:06 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 14:57:06 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 14:57:06 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:57:06 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 14:57:06 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 14:57:06 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 14:57:06 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:57:06 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 14:57:06 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 14:57:06 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 14:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 15:00:30 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 15:00:33 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-10-30 15:00:33 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-10-30 15:00:33 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-10-30 15:00:33 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-10-30 15:00:33 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-10-30 15:00:33 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-10-30 15:00:33 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-10-30 15:00:33 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-10-30 15:00:33 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-10-30 15:00:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 15:00:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 15:00:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 15:00:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 15:00:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 15:00:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 15:00:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 15:00:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 15:00:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 15:00:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 15:00:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 15:00:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 15:00:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 15:00:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 15:00:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 15:00:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 15:00:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 15:00:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 15:00:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 15:00:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 15:00:33 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-30 15:00:34 --> 404 Page Not Found: Images/small
ERROR - 2024-10-30 15:00:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 15:00:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 15:00:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 15:00:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 15:01:01 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 15:01:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 15:01:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 15:01:58 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 15:01:58 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 15:01:58 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 15:01:58 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 15:01:58 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 15:01:58 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 15:01:58 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 15:01:58 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 15:01:58 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 15:01:58 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 15:01:58 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 15:01:58 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 15:01:58 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 15:01:58 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 15:01:58 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 15:01:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 15:01:59 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 15:01:59 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 15:01:59 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 15:01:59 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 15:01:59 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 15:01:59 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 15:01:59 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 15:01:59 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 15:01:59 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 15:01:59 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 15:01:59 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 15:01:59 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 15:01:59 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 15:01:59 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 15:01:59 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 15:02:08 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 15:02:10 --> 404 Page Not Found: Calendario/index.php
ERROR - 2024-10-30 15:02:30 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 15:02:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 15:02:33 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 15:02:34 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-10-30 15:03:56 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-10-30 15:03:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 15:04:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 15:04:04 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 15:04:04 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 15:04:04 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 15:04:04 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 15:04:04 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 15:04:04 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 15:04:04 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 15:04:04 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 15:04:04 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 15:04:04 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 15:04:04 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 15:04:04 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 15:04:04 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 15:04:04 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 15:04:04 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 15:04:04 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-30 15:04:04 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 15:04:04 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-10-30 15:04:04 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-10-30 15:04:04 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 15:04:04 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-10-30 15:04:04 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 15:04:04 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-10-30 15:04:04 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-10-30 15:04:04 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 15:04:04 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-10-30 15:04:04 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 15:04:04 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-10-30 15:04:04 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-10-30 15:04:04 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-10-30 15:04:04 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
