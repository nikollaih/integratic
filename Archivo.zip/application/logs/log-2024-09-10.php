<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-09-10 18:24:12 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-09-10 18:24:12 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-09-10 18:24:12 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-09-10 18:24:12 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-09-10 18:24:12 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-09-10 18:24:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-10 18:24:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-10 18:24:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-10 18:24:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-10 18:24:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-10 18:24:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-10 18:24:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-10 18:24:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-10 18:24:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-10 18:24:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-10 18:24:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-10 18:24:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-10 18:24:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-10 18:24:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-10 18:24:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-10 18:24:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-10 18:24:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-10 18:24:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-10 18:24:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-10 18:24:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-10 18:24:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-10 18:24:14 --> 404 Page Not Found: Images/small
ERROR - 2024-09-10 18:24:15 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-10 18:24:15 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-10 18:24:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-10 18:24:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-10 18:24:17 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 85
ERROR - 2024-09-10 18:27:44 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-09-10 18:27:44 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-09-10 18:28:13 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-09-10 18:28:13 --> 404 Page Not Found: Js/chart.umd.js.map
