<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-08-08 10:36:38 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-08 10:36:38 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-08 10:36:38 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-08 10:36:38 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-08 10:36:39 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-08-08 10:36:39 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:36:39 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:36:39 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:36:39 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:36:39 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:36:39 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:36:39 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:36:39 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:36:39 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:36:39 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:36:39 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:36:39 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:36:39 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:36:39 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:36:39 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:36:39 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:36:39 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:36:39 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:36:39 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:36:39 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:36:39 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:36:41 --> 404 Page Not Found: Images/small
ERROR - 2024-08-08 10:36:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:36:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:36:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:36:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:36:46 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 70
ERROR - 2024-08-08 10:38:29 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:38:29 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:38:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:38:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:39:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:39:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:39:03 --> 404 Page Not Found: Images/small
ERROR - 2024-08-08 10:39:05 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-08 10:39:05 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-08 10:39:05 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-08 10:39:05 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-08 10:39:05 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-08 10:39:05 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-08 10:39:05 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-08 10:39:05 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-08 10:39:05 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-08-08 10:39:05 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:39:05 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:39:05 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:39:05 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:39:05 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:39:05 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:39:05 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:39:05 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:39:05 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:39:05 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:39:05 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:39:05 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:39:05 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:39:05 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:39:05 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:39:05 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:39:05 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:39:05 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:39:05 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:39:06 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:39:06 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 10:39:07 --> 404 Page Not Found: Images/small
ERROR - 2024-08-08 10:39:13 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:39:13 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:39:13 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:39:13 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:39:15 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.cm.codmateria' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT *
FROM `cfg_areas` `ca`
JOIN `cfg_materias` `cm` ON `ca`.`codarea` = `cm`.`area`
JOIN `asg_materias` `am` ON `am`.`materia` = `cm`.`codmateria`
WHERE `am`.`docente` = '12345'
GROUP BY `ca`.`codarea`
ERROR - 2024-08-08 10:40:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:40:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:40:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:40:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:40:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:40:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:40:47 --> 404 Page Not Found: PlanAula/index.php
ERROR - 2024-08-08 10:40:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:40:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:40:55 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:40:55 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:41:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:41:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:51:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:51:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:51:58 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:51:58 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:52:06 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:52:06 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:52:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:52:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:52:35 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:52:35 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:54:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 10:54:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:07:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:07:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:07:14 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 11:07:14 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 11:08:08 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:08:08 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:08:30 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:08:30 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:08:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:08:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:08:52 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 11:08:52 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 11:09:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:09:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:09:11 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 11:09:11 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 11:20:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:20:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:24:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:24:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:24:33 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 11:24:33 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 11:25:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:25:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:25:44 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 11:25:44 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 11:27:08 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:27:08 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:27:08 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 11:27:08 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 11:35:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:35:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:35:16 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 11:35:16 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 11:36:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:36:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:36:31 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 11:36:31 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 11:37:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:37:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:40:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:40:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:41:35 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 11:41:35 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 11:42:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:42:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:42:36 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 11:42:36 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 11:44:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:44:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:44:05 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 11:44:05 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 11:44:35 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:44:35 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:47:56 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:47:56 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:48:48 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:48:48 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:48:56 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 11:48:56 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:01:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:01:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:01:28 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 12:01:28 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 12:14:51 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:14:51 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:14:51 --> 404 Page Not Found: PlanAula/index.php
ERROR - 2024-08-08 12:15:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:15:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:15:25 --> 404 Page Not Found: PlanAula/index.php
ERROR - 2024-08-08 12:15:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:15:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:15:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:15:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:15:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:15:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:15:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:15:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:16:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:16:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:17:51 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:17:51 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:17:58 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:17:58 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:30:09 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:30:09 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:30:12 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:30:12 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:31:10 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:31:10 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:31:12 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:31:12 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:31:37 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:31:37 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:31:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:31:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:31:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:31:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:32:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:32:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:32:01 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 12:32:01 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 12:32:04 --> Severity: Notice --> Undefined index: id_evidencia_aprendizaje /Applications/MAMP/htdocs/integratic/application/controllers/EvidenciasAprendizaje.php 128
ERROR - 2024-08-08 12:32:04 --> Severity: Notice --> Undefined index: id_plan_aula /Applications/MAMP/htdocs/integratic/application/controllers/EvidenciasAprendizaje.php 129
ERROR - 2024-08-08 12:32:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:32:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:32:43 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 12:32:43 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 12:33:30 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:33:30 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:33:30 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 12:33:30 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 12:34:02 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:34:02 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:34:02 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 12:34:02 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 12:35:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:35:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:35:15 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 12:35:15 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 12:36:15 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:36:15 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:36:15 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 12:36:15 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 12:37:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:37:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:37:42 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 12:37:42 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 12:37:42 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-08 12:37:42 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-08 12:37:59 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-08 12:37:59 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-08 12:37:59 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-08 12:37:59 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-08 12:37:59 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 12:37:59 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 12:37:59 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-08-08 12:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:38:02 --> 404 Page Not Found: Images/small
ERROR - 2024-08-08 12:38:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:38:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:38:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:38:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:38:04 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 70
ERROR - 2024-08-08 12:38:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:38:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:38:56 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 70
ERROR - 2024-08-08 12:38:58 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:38:58 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:39:02 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-08 12:39:02 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-08 12:39:02 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-08 12:39:02 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-08 12:39:02 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-08 12:39:02 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-08 12:39:02 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-08 12:39:02 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-08 12:39:02 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-08-08 12:39:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:39:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:39:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:39:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:39:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:39:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:39:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:39:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:39:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:39:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:39:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:39:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:39:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:39:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:39:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:39:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:39:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:39:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:39:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:39:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:39:02 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 12:39:03 --> 404 Page Not Found: Images/small
ERROR - 2024-08-08 12:39:12 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:39:12 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:39:13 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:39:13 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:39:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:39:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:39:17 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:39:17 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:39:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:39:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:40:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:40:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:40:44 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 12:40:44 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 12:40:49 --> Severity: Notice --> Undefined index: id_evidencia_aprendizaje /Applications/MAMP/htdocs/integratic/application/controllers/EvidenciasAprendizaje.php 145
ERROR - 2024-08-08 12:40:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:41:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:41:06 --> Severity: Notice --> Undefined index: id_evidencia_aprendizaje /Applications/MAMP/htdocs/integratic/application/controllers/EvidenciasAprendizaje.php 145
ERROR - 2024-08-08 12:41:09 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:41:09 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:41:35 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 12:41:35 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:37:11 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 14:37:11 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 14:38:31 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 14:38:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:38:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:38:32 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 14:38:32 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-08 14:38:32 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-08 14:38:59 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-08 14:38:59 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-08 14:38:59 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-08 14:38:59 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-08 14:38:59 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-08-08 14:38:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 14:38:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 14:38:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 14:38:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 14:38:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 14:38:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 14:38:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 14:38:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 14:38:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 14:38:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 14:38:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 14:38:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 14:38:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 14:38:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 14:38:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 14:38:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 14:38:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 14:38:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 14:38:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 14:38:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 14:38:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-08 14:39:00 --> 404 Page Not Found: Images/small
ERROR - 2024-08-08 14:39:08 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:39:08 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:39:08 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:39:08 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:39:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:39:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:39:15 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:39:15 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:39:17 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:39:17 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:42:28 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 14:42:28 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 14:42:52 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 14:42:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:42:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:42:52 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 14:43:36 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 14:43:36 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 14:44:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:44:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:44:32 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:44:32 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:44:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:44:37 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:44:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:44:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:45:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:45:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:45:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:45:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:46:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:46:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:46:32 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:46:32 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:49:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:49:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:49:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:49:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:49:25 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 14:49:25 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 14:49:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:49:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:49:42 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 14:49:42 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 14:50:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:50:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:50:11 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-08 14:50:11 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-08 14:50:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:50:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:50:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:50:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:52:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:52:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:52:32 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:52:32 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:52:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 14:52:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 15:00:17 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 15:00:17 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 15:00:28 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 15:00:28 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 15:00:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-08 15:00:57 --> 404 Page Not Found: Img/iconos
