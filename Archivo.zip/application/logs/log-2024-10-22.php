<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-10-22 13:25:22 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-10-22 13:25:22 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-10-22 13:25:22 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-10-22 13:25:22 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-10-22 13:25:22 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-10-22 13:25:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 13:25:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 13:25:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 13:25:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 13:25:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 13:25:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 13:25:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 13:25:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 13:25:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 13:25:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 13:25:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 13:25:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 13:25:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 13:25:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 13:25:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 13:25:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 13:25:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 13:25:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 13:25:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 13:25:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 13:25:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 13:25:24 --> 404 Page Not Found: Images/small
ERROR - 2024-10-22 13:25:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:25:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:25:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:25:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:25:37 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:25:37 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:25:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:25:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:32:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:32:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:32:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:32:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:32:58 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:32:58 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:33:02 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:33:02 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:33:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:33:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:54:35 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:54:35 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:54:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 198
ERROR - 2024-10-22 13:54:43 --> Severity: Notice --> Undefined variable: newPruebaParticipant /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 206
ERROR - 2024-10-22 13:55:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:55:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:55:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:55:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:56:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:56:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:58:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:58:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:58:55 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:58:55 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:59:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:59:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:59:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:59:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:59:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:59:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:59:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:59:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:59:54 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:59:54 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:59:58 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 13:59:58 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:00:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:00:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:00:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:00:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:00:33 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-22 14:00:33 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-22 14:06:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 200
ERROR - 2024-10-22 14:06:55 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:06:55 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:06:55 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-22 14:06:55 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-22 14:07:08 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:07:08 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:07:09 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-22 14:07:09 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-22 14:07:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:07:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:07:20 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-22 14:07:20 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-22 14:07:23 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:07:23 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:07:24 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-22 14:07:24 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-22 14:07:28 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:07:28 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:07:28 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-22 14:07:29 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-22 14:07:41 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:07:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:07:42 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-22 14:07:42 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-22 14:12:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:12:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:21:58 --> Severity: Notice --> Undefined property: Recuperaciones::$Participantes_prueba_Model /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 274
ERROR - 2024-10-22 14:21:58 --> Severity: error --> Exception: Call to a member function get_participante_by_identificacion() on null /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 274
ERROR - 2024-10-22 14:22:02 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-22 14:22:02 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-22 14:22:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:22:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:22:03 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-22 14:22:03 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-22 14:22:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:22:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:22:11 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-22 14:22:11 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-22 14:22:19 --> Severity: Notice --> Undefined property: Recuperaciones::$Participantes_prueba_Model /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 274
ERROR - 2024-10-22 14:22:19 --> Severity: error --> Exception: Call to a member function get_participante_by_identificacion() on null /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 274
ERROR - 2024-10-22 14:24:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:24:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:24:40 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-22 14:24:40 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-22 14:24:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:24:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:24:46 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-22 14:24:46 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-22 14:24:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:24:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:25:08 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 14:25:08 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-22 16:26:53 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-10-22 16:26:53 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-10-22 16:26:53 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-10-22 16:26:53 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-10-22 16:26:53 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-10-22 16:26:53 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 16:26:53 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 16:26:53 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 16:26:53 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 16:26:53 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 16:26:53 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 16:26:53 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 16:26:53 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 16:26:53 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 16:26:53 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 16:26:53 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 16:26:53 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 16:26:53 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 16:26:53 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 16:26:53 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 16:26:53 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 16:26:53 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 16:26:53 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 16:26:53 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 16:26:53 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 16:26:53 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-22 16:28:30 --> 404 Page Not Found: Images/small
