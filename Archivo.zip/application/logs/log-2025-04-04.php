<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-04-04 11:14:29 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-04-04 11:14:29 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-04-04 11:14:29 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-04-04 11:14:29 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-04-04 11:14:29 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-04-04 11:14:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:31 --> 404 Page Not Found: Images/small
ERROR - 2025-04-04 11:14:32 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.m.codmateria' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: Select * from cfg_areas a left join cfg_materias m on a.codarea = m.area join asg_materias am on am.materia = m.codmateria where m.grado = '11' and am.grupo = 'A' group by a.codarea
ERROR - 2025-04-04 11:14:37 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.m.codmateria' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: Select * from cfg_areas a left join cfg_materias m on a.codarea = m.area join asg_materias am on am.materia = m.codmateria where m.grado = '11' and am.grupo = 'A' group by a.codarea
ERROR - 2025-04-04 11:14:41 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-04-04 11:14:41 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-04-04 11:14:41 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-04-04 11:14:41 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-04-04 11:14:41 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-04-04 11:14:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:14:42 --> 404 Page Not Found: Images/small
ERROR - 2025-04-04 11:14:50 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.cm.codmateria' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT *
FROM `cfg_areas` `ca`
JOIN `cfg_materias` `cm` ON `ca`.`codarea` = `cm`.`area`
JOIN `asg_materias` `am` ON `am`.`materia` = `cm`.`codmateria`
WHERE `am`.`docente` = '12345'
GROUP BY `ca`.`codarea`
ERROR - 2025-04-04 11:29:28 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-04-04 11:29:28 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-04-04 11:29:28 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-04-04 11:29:28 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-04-04 11:29:28 --> 404 Page Not Found: Img/banner%202024.png
ERROR - 2025-04-04 11:29:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:29:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:29:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:29:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:29:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:29:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:29:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:29:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:29:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:29:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:29:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:29:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:29:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:29:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:29:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:29:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:29:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:29:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:29:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:29:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:29:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:29:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:29:29 --> 404 Page Not Found: Images/small
ERROR - 2025-04-04 11:30:09 --> Severity: Warning --> array_filter() expects parameter 1 to be array, bool given /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 84
ERROR - 2025-04-04 11:30:09 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 74
ERROR - 2025-04-04 11:30:09 --> Severity: Warning --> array_filter() expects parameter 1 to be array, bool given /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 84
ERROR - 2025-04-04 11:30:09 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 74
ERROR - 2025-04-04 11:30:09 --> Severity: error --> Exception: DateTime::__construct(): Failed to parse time string (No completo) at position 0 (N): The timezone could not be found in the database /Applications/MAMP/htdocs/integratic/application/helpers/general_helper.php 173
ERROR - 2025-04-04 11:31:22 --> Severity: Warning --> array_filter() expects parameter 1 to be array, bool given /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 86
ERROR - 2025-04-04 11:31:22 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 74
ERROR - 2025-04-04 11:31:22 --> Severity: Warning --> array_filter() expects parameter 1 to be array, bool given /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 86
ERROR - 2025-04-04 11:31:22 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 74
ERROR - 2025-04-04 11:31:22 --> Severity: error --> Exception: DateTime::__construct(): Failed to parse time string (No completo) at position 0 (N): The timezone could not be found in the database /Applications/MAMP/htdocs/integratic/application/helpers/general_helper.php 173
ERROR - 2025-04-04 11:31:26 --> Severity: Warning --> array_filter() expects parameter 1 to be array, bool given /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 86
ERROR - 2025-04-04 11:31:26 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 74
ERROR - 2025-04-04 11:31:26 --> Severity: Warning --> array_filter() expects parameter 1 to be array, bool given /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 86
ERROR - 2025-04-04 11:31:26 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 74
ERROR - 2025-04-04 11:31:26 --> Severity: error --> Exception: DateTime::__construct(): Failed to parse time string (No completo) at position 0 (N): The timezone could not be found in the database /Applications/MAMP/htdocs/integratic/application/helpers/general_helper.php 173
ERROR - 2025-04-04 11:31:27 --> Severity: Warning --> array_filter() expects parameter 1 to be array, bool given /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 86
ERROR - 2025-04-04 11:31:27 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 74
ERROR - 2025-04-04 11:31:27 --> Severity: Warning --> array_filter() expects parameter 1 to be array, bool given /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 86
ERROR - 2025-04-04 11:31:27 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 74
ERROR - 2025-04-04 11:31:27 --> Severity: error --> Exception: DateTime::__construct(): Failed to parse time string (No completo) at position 0 (N): The timezone could not be found in the database /Applications/MAMP/htdocs/integratic/application/helpers/general_helper.php 173
ERROR - 2025-04-04 11:31:31 --> Severity: Warning --> array_filter() expects parameter 1 to be array, bool given /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 86
ERROR - 2025-04-04 11:31:31 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 74
ERROR - 2025-04-04 11:31:31 --> Severity: Warning --> array_filter() expects parameter 1 to be array, bool given /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 86
ERROR - 2025-04-04 11:31:31 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 74
ERROR - 2025-04-04 11:31:31 --> Severity: error --> Exception: DateTime::__construct(): Failed to parse time string (No completo) at position 0 (N): The timezone could not be found in the database /Applications/MAMP/htdocs/integratic/application/helpers/general_helper.php 173
ERROR - 2025-04-04 11:32:03 --> Severity: error --> Exception: DateTime::__construct(): Failed to parse time string (No completo) at position 0 (N): The timezone could not be found in the database /Applications/MAMP/htdocs/integratic/application/helpers/general_helper.php 173
ERROR - 2025-04-04 11:32:50 --> Severity: error --> Exception: DateTime::__construct(): Failed to parse time string (1) at position 0 (1): Unexpected character /Applications/MAMP/htdocs/integratic/application/helpers/general_helper.php 173
ERROR - 2025-04-04 11:33:50 --> Severity: error --> Exception: DateTime::__construct(): Failed to parse time string (No completo) at position 0 (N): The timezone could not be found in the database /Applications/MAMP/htdocs/integratic/application/helpers/general_helper.php 173
ERROR - 2025-04-04 11:33:59 --> Severity: error --> Exception: DateTime::__construct(): Failed to parse time string (No completo) at position 0 (N): The timezone could not be found in the database /Applications/MAMP/htdocs/integratic/application/helpers/general_helper.php 173
ERROR - 2025-04-04 11:34:09 --> Severity: error --> Exception: DateTime::__construct(): Failed to parse time string (No completo) at position 0 (N): The timezone could not be found in the database /Applications/MAMP/htdocs/integratic/application/helpers/general_helper.php 174
ERROR - 2025-04-04 11:34:21 --> Severity: error --> Exception: DateTime::__construct(): Failed to parse time string (No completo) at position 0 (N): The timezone could not be found in the database /Applications/MAMP/htdocs/integratic/application/helpers/general_helper.php 174
ERROR - 2025-04-04 11:35:28 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-04-04 11:35:28 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-04-04 11:35:28 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-04-04 11:35:28 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-04-04 11:35:29 --> 404 Page Not Found: Img/banner%202024.png
ERROR - 2025-04-04 11:35:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:35:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:35:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:35:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:35:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:35:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:35:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:35:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:35:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:35:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:35:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:35:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:35:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:35:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:35:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:35:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:35:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:35:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:35:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:35:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:35:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:35:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-04 11:35:30 --> 404 Page Not Found: Images/small
ERROR - 2025-04-04 11:40:29 --> 404 Page Not Found: EstadisticasPruebas/index.php
ERROR - 2025-04-04 11:40:32 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-04-04 11:40:42 --> 404 Page Not Found: Pruebas/index.php
