<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-02-11 21:07:28 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-11 21:07:28 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-11 21:07:28 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-11 21:07:28 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-11 21:07:28 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-02-11 21:07:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-11 21:07:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-11 21:07:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-11 21:07:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-11 21:07:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-11 21:07:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-11 21:07:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-11 21:07:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-11 21:07:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-11 21:07:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-11 21:07:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-11 21:07:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-11 21:07:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-11 21:07:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-11 21:07:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-11 21:07:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-11 21:07:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-11 21:07:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-11 21:07:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-11 21:07:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-11 21:07:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-11 21:07:37 --> 404 Page Not Found: Images/small
ERROR - 2025-02-11 21:07:43 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-11 21:07:43 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-11 22:15:20 --> Severity: error --> Exception: Object of class CI_Loader could not be converted to string /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Mpdf.php 27543
