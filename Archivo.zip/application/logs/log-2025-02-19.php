<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-02-19 12:11:09 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-19 12:11:09 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-19 12:11:09 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-19 12:11:09 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-19 12:11:09 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-02-19 12:11:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 12:11:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 12:11:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 12:11:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 12:11:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 12:11:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 12:11:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 12:11:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 12:11:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 12:11:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 12:11:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 12:11:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 12:11:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 12:11:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 12:11:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 12:11:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 12:11:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 12:11:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 12:11:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 12:11:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 12:11:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 12:11:18 --> 404 Page Not Found: Images/small
ERROR - 2025-02-19 12:11:27 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 12:11:27 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 12:25:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0 = ''
WHERE `id_piar` = '1'' at line 1 - Invalid query: UPDATE `piar` SET `id_docente_aula` = '12345', `id_docente_apoyo` = '43543535', `lugar_nacimiento` = 'fdfcsf', `departamento` = 'Quindio', `municipio` = 'LA TEBAIDA', `es_centro_proteccion` = '1', `centro_proteccion` = 'CASIC', `es_victima_conflicto_armado` = '0', `registro_victima_conflicto_armado` = '1', `afiliacion_sistema_salud` = '1', `tipo_afiliacion_sistema_salud` = 'contributivo', `lugar_atencion_emergencia` = 'Hospital pio X', `es_atendido_sector_salud` = '0', `es_atendido_frecuencia` = 'Diario', `recibe_tratamiento_enfermedad_particular` = '0', `recibe_tratamiento_enfermedad_particular_cual` = 'Diabetes', `nivel_educativo_madre` = 'Profesional', `nivel_educativo_padre` = 'Tecnólogo', `nombre_cuidador` = 'Nikollai', `parentesco_cuidador` = 'Otro', `nivel_educativo_cuidador` = 'Profesional', `telefono_cuidador` = '423432423', `correo_electronico_cuidador` = 'nikollaihernandez@gmail.com', `lugar_que_ocupa_hermanos` = '1', `quienes_apoyan_crianza` = 'Familiares', `esta_bajo_proteccion` = '0', `recibe_subsidio_entidad` = '1', `recibe_subsidio_entidad_cual` = 'Familias en accion', `es_vinculado_otra_institucion` = '0', `es_vinculado_otra_institucion_cual` = 'Instebaida', `ultimo_grado_cursado` = 'Septimo', `ultimo_grado_cursado_aprobo` = '1', `ultimo_grado_cursado_observaciones` = 'Ninguna', `recibe_informe_pedagogico` = '1', `recibe_informe_pedagogico_institucion` = 'Otra', `asiste_programas_complementarios` = '1', `asiste_programas_complementarios_cuales` = 'Futbol', `medio_de_transporte` = '', `distancia_institucion_hogar` = '30 minutos', `entorno_personal` = '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam imperdiet sapien vel lectus semper eleifend. Morbi vel justo metus. Vivamus elementum nisl eu gravida tempus. Vivamus non venenatis enim. Vivamus bibendum massa sit amet rhoncus gravida. Donec nec egestas dolor. Cras ut dui posuere, porta ex et, convallis mauris. Curabitur ut ullamcorper nunc. Curabitur molestie dolor vel orci lobortis tincidunt. Fusce vulputate nisi eget ex pulvinar, quis rutrum felis maximus. Integer fringilla turpis sit amet est hendrerit pulvinar. Aliquam non elit sed dolor laoreet pharetra.</p><p>Ut bibendum tempor tortor. Donec ut lorem eget orci auctor sollicitudin. Integer et ante porta, ornare elit in, efficitur nisi. Nunc imperdiet dictum ante, quis sagittis enim molestie at. Nam consequat sit amet sapien vel interdum. Suspendisse potenti. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>', `descripcion_general` = '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam imperdiet sapien vel lectus semper eleifend. Morbi vel justo metus. Vivamus elementum nisl eu gravida tempus. Vivamus non venenatis enim. Vivamus bibendum massa sit amet rhoncus gravida. Donec nec egestas dolor. Cras ut dui posuere, porta ex et, convallis mauris. Curabitur ut ullamcorper nunc. Curabitur molestie dolor vel orci lobortis tincidunt. Fusce vulputate nisi eget ex pulvinar, quis rutrum felis maximus. Integer fringilla turpis sit amet est hendrerit pulvinar. Aliquam non elit sed dolor laoreet pharetra.</p><p><br></p><p>Ut bibendum tempor tortor. Donec ut lorem eget orci auctor sollicitudin. Integer et ante porta, ornare elit in, efficitur nisi. Nunc imperdiet dictum ante, quis sagittis enim molestie at. Nam consequat sit amet sapien vel interdum. Suspendisse potenti. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>', `descripcion_que_hace` = '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam imperdiet sapien vel lectus semper eleifend. Morbi vel justo metus. Vivamus elementum nisl eu gravida tempus. Vivamus non venenatis enim. Vivamus bibendum massa sit amet rhoncus gravida. Donec nec egestas dolor. Cras ut dui posuere, porta ex et, convallis mauris. Curabitur ut ullamcorper nunc. Curabitur molestie dolor vel orci lobortis tincidunt. Fusce vulputate nisi eget ex pulvinar, quis rutrum felis maximus. Integer fringilla turpis sit amet est hendrerit pulvinar. Aliquam non elit sed dolor laoreet pharetra.</p><p>Ut bibendum tempor tortor. Donec ut lorem eget orci auctor sollicitudin. Integer et ante porta, ornare elit in, efficitur nisi. Nunc imperdiet dictum ante, quis sagittis enim molestie at. Nam consequat sit amet sapien vel interdum. Suspendisse potenti. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>', `acciones_familia` = 'prueba\r\n\r\nHola', `estrategias_familia` = '', `acciones_docentes` = '', `estrategias_docentes` = '', `acciones_directivos` = '', `estrategias_directivos` = '', `acciones_administrativos` = '', `estrategias_administrativos` = '', `acciones_compañeros` = '', `estrategias_compañeros` = '', 0 = ''
WHERE `id_piar` = '1'
ERROR - 2025-02-19 12:30:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0 = ''
WHERE `id_piar` = '1'' at line 1 - Invalid query: UPDATE `piar` SET `id_docente_aula` = '12345', `id_docente_apoyo` = '43543535', `lugar_nacimiento` = 'fdfcsf', `departamento` = 'Quindio', `municipio` = 'LA TEBAIDA', `es_centro_proteccion` = '1', `centro_proteccion` = 'CASIC', `es_victima_conflicto_armado` = '0', `registro_victima_conflicto_armado` = '1', `afiliacion_sistema_salud` = '1', `tipo_afiliacion_sistema_salud` = 'contributivo', `lugar_atencion_emergencia` = 'Hospital pio X', `es_atendido_sector_salud` = '0', `es_atendido_frecuencia` = 'Diario', `recibe_tratamiento_enfermedad_particular` = '0', `recibe_tratamiento_enfermedad_particular_cual` = 'Diabetes', `nivel_educativo_madre` = 'Profesional', `nivel_educativo_padre` = 'Tecnólogo', `nombre_cuidador` = 'Nikollai', `parentesco_cuidador` = 'Otro', `nivel_educativo_cuidador` = 'Profesional', `telefono_cuidador` = '423432423', `correo_electronico_cuidador` = 'nikollaihernandez@gmail.com', `lugar_que_ocupa_hermanos` = '1', `quienes_apoyan_crianza` = 'Familiares', `esta_bajo_proteccion` = '0', `recibe_subsidio_entidad` = '1', `recibe_subsidio_entidad_cual` = 'Familias en accion', `es_vinculado_otra_institucion` = '0', `es_vinculado_otra_institucion_cual` = 'Instebaida', `ultimo_grado_cursado` = 'Septimo', `ultimo_grado_cursado_aprobo` = '1', `ultimo_grado_cursado_observaciones` = 'Ninguna', `recibe_informe_pedagogico` = '1', `recibe_informe_pedagogico_institucion` = 'Otra', `asiste_programas_complementarios` = '1', `asiste_programas_complementarios_cuales` = 'Futbol', `medio_de_transporte` = '', `distancia_institucion_hogar` = '30 minutos', `entorno_personal` = '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam imperdiet sapien vel lectus semper eleifend. Morbi vel justo metus. Vivamus elementum nisl eu gravida tempus. Vivamus non venenatis enim. Vivamus bibendum massa sit amet rhoncus gravida. Donec nec egestas dolor. Cras ut dui posuere, porta ex et, convallis mauris. Curabitur ut ullamcorper nunc. Curabitur molestie dolor vel orci lobortis tincidunt. Fusce vulputate nisi eget ex pulvinar, quis rutrum felis maximus. Integer fringilla turpis sit amet est hendrerit pulvinar. Aliquam non elit sed dolor laoreet pharetra.</p><p>Ut bibendum tempor tortor. Donec ut lorem eget orci auctor sollicitudin. Integer et ante porta, ornare elit in, efficitur nisi. Nunc imperdiet dictum ante, quis sagittis enim molestie at. Nam consequat sit amet sapien vel interdum. Suspendisse potenti. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>', `descripcion_general` = '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam imperdiet sapien vel lectus semper eleifend. Morbi vel justo metus. Vivamus elementum nisl eu gravida tempus. Vivamus non venenatis enim. Vivamus bibendum massa sit amet rhoncus gravida. Donec nec egestas dolor. Cras ut dui posuere, porta ex et, convallis mauris. Curabitur ut ullamcorper nunc. Curabitur molestie dolor vel orci lobortis tincidunt. Fusce vulputate nisi eget ex pulvinar, quis rutrum felis maximus. Integer fringilla turpis sit amet est hendrerit pulvinar. Aliquam non elit sed dolor laoreet pharetra.</p><p><br></p><p>Ut bibendum tempor tortor. Donec ut lorem eget orci auctor sollicitudin. Integer et ante porta, ornare elit in, efficitur nisi. Nunc imperdiet dictum ante, quis sagittis enim molestie at. Nam consequat sit amet sapien vel interdum. Suspendisse potenti. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>', `descripcion_que_hace` = '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam imperdiet sapien vel lectus semper eleifend. Morbi vel justo metus. Vivamus elementum nisl eu gravida tempus. Vivamus non venenatis enim. Vivamus bibendum massa sit amet rhoncus gravida. Donec nec egestas dolor. Cras ut dui posuere, porta ex et, convallis mauris. Curabitur ut ullamcorper nunc. Curabitur molestie dolor vel orci lobortis tincidunt. Fusce vulputate nisi eget ex pulvinar, quis rutrum felis maximus. Integer fringilla turpis sit amet est hendrerit pulvinar. Aliquam non elit sed dolor laoreet pharetra.</p><p>Ut bibendum tempor tortor. Donec ut lorem eget orci auctor sollicitudin. Integer et ante porta, ornare elit in, efficitur nisi. Nunc imperdiet dictum ante, quis sagittis enim molestie at. Nam consequat sit amet sapien vel interdum. Suspendisse potenti. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>', `acciones_familia` = 'prueba\r\n\r\nHola', `estrategias_familia` = '', `acciones_docentes` = '', `estrategias_docentes` = '', `acciones_directivos` = '', `estrategias_directivos` = '', `acciones_administrativos` = '', `estrategias_administrativos` = '', `acciones_compañeros` = '', `estrategias_compañeros` = '', 0 = ''
WHERE `id_piar` = '1'
ERROR - 2025-02-19 12:30:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0 = ''
WHERE `id_piar` = '1'' at line 1 - Invalid query: UPDATE `piar` SET `id_docente_aula` = '12345', `id_docente_apoyo` = '43543535', `lugar_nacimiento` = 'fdfcsf', `departamento` = 'Quindio', `municipio` = 'LA TEBAIDA', `es_centro_proteccion` = '1', `centro_proteccion` = 'CASIC', `es_victima_conflicto_armado` = '0', `registro_victima_conflicto_armado` = '1', `afiliacion_sistema_salud` = '1', `tipo_afiliacion_sistema_salud` = 'contributivo', `lugar_atencion_emergencia` = 'Hospital pio X', `es_atendido_sector_salud` = '0', `es_atendido_frecuencia` = 'Diario', `recibe_tratamiento_enfermedad_particular` = '0', `recibe_tratamiento_enfermedad_particular_cual` = 'Diabetes', `nivel_educativo_madre` = 'Profesional', `nivel_educativo_padre` = 'Tecnólogo', `nombre_cuidador` = 'Nikollai', `parentesco_cuidador` = 'Otro', `nivel_educativo_cuidador` = 'Profesional', `telefono_cuidador` = '423432423', `correo_electronico_cuidador` = 'nikollaihernandez@gmail.com', `lugar_que_ocupa_hermanos` = '1', `quienes_apoyan_crianza` = 'Familiares', `esta_bajo_proteccion` = '0', `recibe_subsidio_entidad` = '1', `recibe_subsidio_entidad_cual` = 'Familias en accion', `es_vinculado_otra_institucion` = '0', `es_vinculado_otra_institucion_cual` = 'Instebaida', `ultimo_grado_cursado` = 'Septimo', `ultimo_grado_cursado_aprobo` = '1', `ultimo_grado_cursado_observaciones` = 'Ninguna', `recibe_informe_pedagogico` = '1', `recibe_informe_pedagogico_institucion` = 'Otra', `asiste_programas_complementarios` = '1', `asiste_programas_complementarios_cuales` = 'Futbol', `medio_de_transporte` = '', `distancia_institucion_hogar` = '30 minutos', `entorno_personal` = '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam imperdiet sapien vel lectus semper eleifend. Morbi vel justo metus. Vivamus elementum nisl eu gravida tempus. Vivamus non venenatis enim. Vivamus bibendum massa sit amet rhoncus gravida. Donec nec egestas dolor. Cras ut dui posuere, porta ex et, convallis mauris. Curabitur ut ullamcorper nunc. Curabitur molestie dolor vel orci lobortis tincidunt. Fusce vulputate nisi eget ex pulvinar, quis rutrum felis maximus. Integer fringilla turpis sit amet est hendrerit pulvinar. Aliquam non elit sed dolor laoreet pharetra.</p><p>Ut bibendum tempor tortor. Donec ut lorem eget orci auctor sollicitudin. Integer et ante porta, ornare elit in, efficitur nisi. Nunc imperdiet dictum ante, quis sagittis enim molestie at. Nam consequat sit amet sapien vel interdum. Suspendisse potenti. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>', `descripcion_general` = '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam imperdiet sapien vel lectus semper eleifend. Morbi vel justo metus. Vivamus elementum nisl eu gravida tempus. Vivamus non venenatis enim. Vivamus bibendum massa sit amet rhoncus gravida. Donec nec egestas dolor. Cras ut dui posuere, porta ex et, convallis mauris. Curabitur ut ullamcorper nunc. Curabitur molestie dolor vel orci lobortis tincidunt. Fusce vulputate nisi eget ex pulvinar, quis rutrum felis maximus. Integer fringilla turpis sit amet est hendrerit pulvinar. Aliquam non elit sed dolor laoreet pharetra.</p><p><br></p><p>Ut bibendum tempor tortor. Donec ut lorem eget orci auctor sollicitudin. Integer et ante porta, ornare elit in, efficitur nisi. Nunc imperdiet dictum ante, quis sagittis enim molestie at. Nam consequat sit amet sapien vel interdum. Suspendisse potenti. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>', `descripcion_que_hace` = '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam imperdiet sapien vel lectus semper eleifend. Morbi vel justo metus. Vivamus elementum nisl eu gravida tempus. Vivamus non venenatis enim. Vivamus bibendum massa sit amet rhoncus gravida. Donec nec egestas dolor. Cras ut dui posuere, porta ex et, convallis mauris. Curabitur ut ullamcorper nunc. Curabitur molestie dolor vel orci lobortis tincidunt. Fusce vulputate nisi eget ex pulvinar, quis rutrum felis maximus. Integer fringilla turpis sit amet est hendrerit pulvinar. Aliquam non elit sed dolor laoreet pharetra.</p><p>Ut bibendum tempor tortor. Donec ut lorem eget orci auctor sollicitudin. Integer et ante porta, ornare elit in, efficitur nisi. Nunc imperdiet dictum ante, quis sagittis enim molestie at. Nam consequat sit amet sapien vel interdum. Suspendisse potenti. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>', `acciones_familia` = 'prueba\r\n\r\nHola', `estrategias_familia` = '', `acciones_docentes` = '', `estrategias_docentes` = '', `acciones_directivos` = '', `estrategias_directivos` = '', `acciones_administrativos` = '', `estrategias_administrativos` = '', `acciones_compañeros` = '', `estrategias_compañeros` = '', 0 = ''
WHERE `id_piar` = '1'
ERROR - 2025-02-19 12:32:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0 = ''
WHERE `id_piar` = '1'' at line 1 - Invalid query: UPDATE `piar` SET `id_docente_aula` = '12345', `id_docente_apoyo` = '43543535', `lugar_nacimiento` = 'fdfcsf', `departamento` = 'Quindio', `municipio` = 'LA TEBAIDA', `es_centro_proteccion` = '1', `centro_proteccion` = 'CASIC', `es_victima_conflicto_armado` = '0', `registro_victima_conflicto_armado` = '1', `afiliacion_sistema_salud` = '1', `tipo_afiliacion_sistema_salud` = 'contributivo', `lugar_atencion_emergencia` = 'Hospital pio X', `es_atendido_sector_salud` = '0', `es_atendido_frecuencia` = 'Diario', `recibe_tratamiento_enfermedad_particular` = '0', `recibe_tratamiento_enfermedad_particular_cual` = 'Diabetes', `nivel_educativo_madre` = 'Profesional', `nivel_educativo_padre` = 'Tecnólogo', `nombre_cuidador` = 'Nikollai', `parentesco_cuidador` = 'Otro', `nivel_educativo_cuidador` = 'Profesional', `telefono_cuidador` = '423432423', `correo_electronico_cuidador` = 'nikollaihernandez@gmail.com', `lugar_que_ocupa_hermanos` = '1', `quienes_apoyan_crianza` = 'Familiares', `esta_bajo_proteccion` = '0', `recibe_subsidio_entidad` = '1', `recibe_subsidio_entidad_cual` = 'Familias en accion', `es_vinculado_otra_institucion` = '0', `es_vinculado_otra_institucion_cual` = 'Instebaida', `ultimo_grado_cursado` = 'Septimo', `ultimo_grado_cursado_aprobo` = '1', `ultimo_grado_cursado_observaciones` = 'Ninguna', `recibe_informe_pedagogico` = '1', `recibe_informe_pedagogico_institucion` = 'Otra', `asiste_programas_complementarios` = '1', `asiste_programas_complementarios_cuales` = 'Futbol', `medio_de_transporte` = '', `distancia_institucion_hogar` = '30 minutos', `entorno_personal` = '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam imperdiet sapien vel lectus semper eleifend. Morbi vel justo metus. Vivamus elementum nisl eu gravida tempus. Vivamus non venenatis enim. Vivamus bibendum massa sit amet rhoncus gravida. Donec nec egestas dolor. Cras ut dui posuere, porta ex et, convallis mauris. Curabitur ut ullamcorper nunc. Curabitur molestie dolor vel orci lobortis tincidunt. Fusce vulputate nisi eget ex pulvinar, quis rutrum felis maximus. Integer fringilla turpis sit amet est hendrerit pulvinar. Aliquam non elit sed dolor laoreet pharetra.</p><p>Ut bibendum tempor tortor. Donec ut lorem eget orci auctor sollicitudin. Integer et ante porta, ornare elit in, efficitur nisi. Nunc imperdiet dictum ante, quis sagittis enim molestie at. Nam consequat sit amet sapien vel interdum. Suspendisse potenti. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>', `descripcion_general` = '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam imperdiet sapien vel lectus semper eleifend. Morbi vel justo metus. Vivamus elementum nisl eu gravida tempus. Vivamus non venenatis enim. Vivamus bibendum massa sit amet rhoncus gravida. Donec nec egestas dolor. Cras ut dui posuere, porta ex et, convallis mauris. Curabitur ut ullamcorper nunc. Curabitur molestie dolor vel orci lobortis tincidunt. Fusce vulputate nisi eget ex pulvinar, quis rutrum felis maximus. Integer fringilla turpis sit amet est hendrerit pulvinar. Aliquam non elit sed dolor laoreet pharetra.</p><p><br></p><p>Ut bibendum tempor tortor. Donec ut lorem eget orci auctor sollicitudin. Integer et ante porta, ornare elit in, efficitur nisi. Nunc imperdiet dictum ante, quis sagittis enim molestie at. Nam consequat sit amet sapien vel interdum. Suspendisse potenti. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>', `descripcion_que_hace` = '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam imperdiet sapien vel lectus semper eleifend. Morbi vel justo metus. Vivamus elementum nisl eu gravida tempus. Vivamus non venenatis enim. Vivamus bibendum massa sit amet rhoncus gravida. Donec nec egestas dolor. Cras ut dui posuere, porta ex et, convallis mauris. Curabitur ut ullamcorper nunc. Curabitur molestie dolor vel orci lobortis tincidunt. Fusce vulputate nisi eget ex pulvinar, quis rutrum felis maximus. Integer fringilla turpis sit amet est hendrerit pulvinar. Aliquam non elit sed dolor laoreet pharetra.</p><p>Ut bibendum tempor tortor. Donec ut lorem eget orci auctor sollicitudin. Integer et ante porta, ornare elit in, efficitur nisi. Nunc imperdiet dictum ante, quis sagittis enim molestie at. Nam consequat sit amet sapien vel interdum. Suspendisse potenti. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>', `acciones_familia` = '', `estrategias_familia` = '', `acciones_docentes` = '', `estrategias_docentes` = '', `acciones_directivos` = '', `estrategias_directivos` = '', `acciones_administrativos` = '', `estrategias_administrativos` = '', `acciones_compañeros` = '', `estrategias_compañeros` = '', 0 = ''
WHERE `id_piar` = '1'
ERROR - 2025-02-19 12:32:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0 = ''
WHERE `id_piar` = '1'' at line 1 - Invalid query: UPDATE `piar` SET `id_docente_aula` = '12345', `id_docente_apoyo` = '43543535', `lugar_nacimiento` = 'fdfcsf', `departamento` = 'Quindio', `municipio` = 'LA TEBAIDA', `es_centro_proteccion` = '1', `centro_proteccion` = 'CASIC', `es_victima_conflicto_armado` = '0', `registro_victima_conflicto_armado` = '1', `afiliacion_sistema_salud` = '1', `tipo_afiliacion_sistema_salud` = 'contributivo', `lugar_atencion_emergencia` = 'Hospital pio X', `es_atendido_sector_salud` = '0', `es_atendido_frecuencia` = 'Diario', `recibe_tratamiento_enfermedad_particular` = '0', `recibe_tratamiento_enfermedad_particular_cual` = 'Diabetes', `nivel_educativo_madre` = 'Profesional', `nivel_educativo_padre` = 'Tecnólogo', `nombre_cuidador` = 'Nikollai', `parentesco_cuidador` = 'Otro', `nivel_educativo_cuidador` = 'Profesional', `telefono_cuidador` = '423432423', `correo_electronico_cuidador` = 'nikollaihernandez@gmail.com', `lugar_que_ocupa_hermanos` = '1', `quienes_apoyan_crianza` = 'Familiares', `esta_bajo_proteccion` = '0', `recibe_subsidio_entidad` = '1', `recibe_subsidio_entidad_cual` = 'Familias en accion', `es_vinculado_otra_institucion` = '0', `es_vinculado_otra_institucion_cual` = 'Instebaida', `ultimo_grado_cursado` = 'Septimo', `ultimo_grado_cursado_aprobo` = '1', `ultimo_grado_cursado_observaciones` = 'Ninguna', `recibe_informe_pedagogico` = '1', `recibe_informe_pedagogico_institucion` = 'Otra', `asiste_programas_complementarios` = '1', `asiste_programas_complementarios_cuales` = 'Futbol', `medio_de_transporte` = '', `distancia_institucion_hogar` = '30 minutos', `entorno_personal` = '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam imperdiet sapien vel lectus semper eleifend. Morbi vel justo metus. Vivamus elementum nisl eu gravida tempus. Vivamus non venenatis enim. Vivamus bibendum massa sit amet rhoncus gravida. Donec nec egestas dolor. Cras ut dui posuere, porta ex et, convallis mauris. Curabitur ut ullamcorper nunc. Curabitur molestie dolor vel orci lobortis tincidunt. Fusce vulputate nisi eget ex pulvinar, quis rutrum felis maximus. Integer fringilla turpis sit amet est hendrerit pulvinar. Aliquam non elit sed dolor laoreet pharetra.</p><p>Ut bibendum tempor tortor. Donec ut lorem eget orci auctor sollicitudin. Integer et ante porta, ornare elit in, efficitur nisi. Nunc imperdiet dictum ante, quis sagittis enim molestie at. Nam consequat sit amet sapien vel interdum. Suspendisse potenti. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>', `descripcion_general` = '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam imperdiet sapien vel lectus semper eleifend. Morbi vel justo metus. Vivamus elementum nisl eu gravida tempus. Vivamus non venenatis enim. Vivamus bibendum massa sit amet rhoncus gravida. Donec nec egestas dolor. Cras ut dui posuere, porta ex et, convallis mauris. Curabitur ut ullamcorper nunc. Curabitur molestie dolor vel orci lobortis tincidunt. Fusce vulputate nisi eget ex pulvinar, quis rutrum felis maximus. Integer fringilla turpis sit amet est hendrerit pulvinar. Aliquam non elit sed dolor laoreet pharetra.</p><p><br></p><p>Ut bibendum tempor tortor. Donec ut lorem eget orci auctor sollicitudin. Integer et ante porta, ornare elit in, efficitur nisi. Nunc imperdiet dictum ante, quis sagittis enim molestie at. Nam consequat sit amet sapien vel interdum. Suspendisse potenti. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>', `descripcion_que_hace` = '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam imperdiet sapien vel lectus semper eleifend. Morbi vel justo metus. Vivamus elementum nisl eu gravida tempus. Vivamus non venenatis enim. Vivamus bibendum massa sit amet rhoncus gravida. Donec nec egestas dolor. Cras ut dui posuere, porta ex et, convallis mauris. Curabitur ut ullamcorper nunc. Curabitur molestie dolor vel orci lobortis tincidunt. Fusce vulputate nisi eget ex pulvinar, quis rutrum felis maximus. Integer fringilla turpis sit amet est hendrerit pulvinar. Aliquam non elit sed dolor laoreet pharetra.</p><p>Ut bibendum tempor tortor. Donec ut lorem eget orci auctor sollicitudin. Integer et ante porta, ornare elit in, efficitur nisi. Nunc imperdiet dictum ante, quis sagittis enim molestie at. Nam consequat sit amet sapien vel interdum. Suspendisse potenti. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>', `acciones_familia` = '', `estrategias_familia` = '', `acciones_docentes` = '', `estrategias_docentes` = '', `acciones_directivos` = '', `estrategias_directivos` = '', `acciones_administrativos` = '', `estrategias_administrativos` = '', `acciones_compañeros` = '', 0 = ''
WHERE `id_piar` = '1'
ERROR - 2025-02-19 12:33:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0 = ''
WHERE `id_piar` = '1'' at line 1 - Invalid query: UPDATE `piar` SET `id_docente_aula` = '12345', `id_docente_apoyo` = '43543535', `lugar_nacimiento` = 'fdfcsf', `departamento` = 'Quindio', `municipio` = 'LA TEBAIDA', `es_centro_proteccion` = '1', `centro_proteccion` = 'CASIC', `es_victima_conflicto_armado` = '0', `registro_victima_conflicto_armado` = '1', `afiliacion_sistema_salud` = '1', `tipo_afiliacion_sistema_salud` = 'contributivo', `lugar_atencion_emergencia` = 'Hospital pio X', `es_atendido_sector_salud` = '0', `es_atendido_frecuencia` = 'Diario', `recibe_tratamiento_enfermedad_particular` = '0', `recibe_tratamiento_enfermedad_particular_cual` = 'Diabetes', `nivel_educativo_madre` = 'Profesional', `nivel_educativo_padre` = 'Tecnólogo', `nombre_cuidador` = 'Nikollai', `parentesco_cuidador` = 'Otro', `nivel_educativo_cuidador` = 'Profesional', `telefono_cuidador` = '423432423', `correo_electronico_cuidador` = 'nikollaihernandez@gmail.com', `lugar_que_ocupa_hermanos` = '1', `quienes_apoyan_crianza` = 'Familiares', `esta_bajo_proteccion` = '0', `recibe_subsidio_entidad` = '1', `recibe_subsidio_entidad_cual` = 'Familias en accion', `es_vinculado_otra_institucion` = '0', `es_vinculado_otra_institucion_cual` = 'Instebaida', `ultimo_grado_cursado` = 'Septimo', `ultimo_grado_cursado_aprobo` = '1', `ultimo_grado_cursado_observaciones` = 'Ninguna', `recibe_informe_pedagogico` = '1', `recibe_informe_pedagogico_institucion` = 'Otra', `asiste_programas_complementarios` = '1', `asiste_programas_complementarios_cuales` = 'Futbol', `medio_de_transporte` = '', `distancia_institucion_hogar` = '30 minutos', `entorno_personal` = '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam imperdiet sapien vel lectus semper eleifend. Morbi vel justo metus. Vivamus elementum nisl eu gravida tempus. Vivamus non venenatis enim. Vivamus bibendum massa sit amet rhoncus gravida. Donec nec egestas dolor. Cras ut dui posuere, porta ex et, convallis mauris. Curabitur ut ullamcorper nunc. Curabitur molestie dolor vel orci lobortis tincidunt. Fusce vulputate nisi eget ex pulvinar, quis rutrum felis maximus. Integer fringilla turpis sit amet est hendrerit pulvinar. Aliquam non elit sed dolor laoreet pharetra.</p><p>Ut bibendum tempor tortor. Donec ut lorem eget orci auctor sollicitudin. Integer et ante porta, ornare elit in, efficitur nisi. Nunc imperdiet dictum ante, quis sagittis enim molestie at. Nam consequat sit amet sapien vel interdum. Suspendisse potenti. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>', `descripcion_general` = '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam imperdiet sapien vel lectus semper eleifend. Morbi vel justo metus. Vivamus elementum nisl eu gravida tempus. Vivamus non venenatis enim. Vivamus bibendum massa sit amet rhoncus gravida. Donec nec egestas dolor. Cras ut dui posuere, porta ex et, convallis mauris. Curabitur ut ullamcorper nunc. Curabitur molestie dolor vel orci lobortis tincidunt. Fusce vulputate nisi eget ex pulvinar, quis rutrum felis maximus. Integer fringilla turpis sit amet est hendrerit pulvinar. Aliquam non elit sed dolor laoreet pharetra.</p><p><br></p><p>Ut bibendum tempor tortor. Donec ut lorem eget orci auctor sollicitudin. Integer et ante porta, ornare elit in, efficitur nisi. Nunc imperdiet dictum ante, quis sagittis enim molestie at. Nam consequat sit amet sapien vel interdum. Suspendisse potenti. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>', `descripcion_que_hace` = '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam imperdiet sapien vel lectus semper eleifend. Morbi vel justo metus. Vivamus elementum nisl eu gravida tempus. Vivamus non venenatis enim. Vivamus bibendum massa sit amet rhoncus gravida. Donec nec egestas dolor. Cras ut dui posuere, porta ex et, convallis mauris. Curabitur ut ullamcorper nunc. Curabitur molestie dolor vel orci lobortis tincidunt. Fusce vulputate nisi eget ex pulvinar, quis rutrum felis maximus. Integer fringilla turpis sit amet est hendrerit pulvinar. Aliquam non elit sed dolor laoreet pharetra.</p><p>Ut bibendum tempor tortor. Donec ut lorem eget orci auctor sollicitudin. Integer et ante porta, ornare elit in, efficitur nisi. Nunc imperdiet dictum ante, quis sagittis enim molestie at. Nam consequat sit amet sapien vel interdum. Suspendisse potenti. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>', `acciones_familia` = '', `estrategias_familia` = '', `acciones_docentes` = '', `estrategias_docentes` = '', `acciones_directivos` = '', `estrategias_directivos` = '', `acciones_administrativos` = '', `estrategias_administrativos` = '', `estrategias_compañeros` = '', 0 = ''
WHERE `id_piar` = '1'
ERROR - 2025-02-19 15:07:39 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-19 15:07:39 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-19 15:07:39 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-19 15:07:39 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-19 15:07:39 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-02-19 15:07:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 15:07:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 15:07:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 15:07:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 15:07:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 15:07:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 15:07:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 15:07:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 15:07:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 15:07:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 15:07:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 15:07:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 15:07:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 15:07:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 15:07:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 15:07:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 15:07:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 15:07:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 15:07:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 15:07:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 15:07:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 15:07:40 --> 404 Page Not Found: Images/small
ERROR - 2025-02-19 15:07:47 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 15:07:47 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 15:10:36 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 15:10:36 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 15:11:13 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 15:11:13 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 15:12:02 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 15:12:02 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 15:12:03 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 15:12:03 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 15:17:01 --> Severity: Notice --> Undefined index: comentarios_especificos /Applications/MAMP/htdocs/integratic/application/views/piar/view.php 415
ERROR - 2025-02-19 16:01:26 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 16:01:26 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 16:01:44 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 16:01:44 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 16:02:36 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 16:02:37 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 16:04:02 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 16:04:02 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 16:04:11 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 16:04:11 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 16:11:01 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 16:11:02 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 16:11:06 --> 404 Page Not Found: PIAR/saveActivity
ERROR - 2025-02-19 16:11:21 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 16:11:21 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 16:11:22 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 16:11:22 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 16:11:49 --> 404 Page Not Found: PIAR/saveActivity
ERROR - 2025-02-19 16:21:01 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 16:21:01 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 16:21:04 --> Severity: Notice --> Undefined property: PIAR::$PIAR_Actividad_Model /Applications/MAMP/htdocs/integratic/application/controllers/PIAR.php 190
ERROR - 2025-02-19 16:21:04 --> Severity: error --> Exception: Call to a member function get() on null /Applications/MAMP/htdocs/integratic/application/controllers/PIAR.php 190
ERROR - 2025-02-19 16:21:17 --> Severity: Notice --> Undefined index: id_piar /Applications/MAMP/htdocs/integratic/application/controllers/PIAR.php 190
ERROR - 2025-02-19 16:21:17 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 16:21:17 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 16:21:21 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 16:21:21 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 16:21:28 --> Severity: Notice --> Undefined index: id_piar /Applications/MAMP/htdocs/integratic/application/controllers/PIAR.php 190
ERROR - 2025-02-19 16:21:29 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 16:21:29 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 16:22:05 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 16:22:05 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 16:22:13 --> Query error: Unknown column 'actividad' in 'field list' - Invalid query: INSERT INTO `piar_item` (`actividad`, `descripcion`, `frecuenca`) VALUES ('fggd', 'dfgdf', 'Diaria')
ERROR - 2025-02-19 16:22:47 --> Query error: Unknown column 'frecuenca' in 'field list' - Invalid query: INSERT INTO `piar_actividades` (`actividad`, `descripcion`, `frecuenca`) VALUES ('fggd', 'dfgdf', 'Diaria')
ERROR - 2025-02-19 16:23:04 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 16:23:04 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 16:23:08 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 16:23:08 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 16:23:13 --> Severity: Notice --> Undefined index: id_piar /Applications/MAMP/htdocs/integratic/application/controllers/PIAR.php 198
ERROR - 2025-02-19 16:23:19 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 16:23:19 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 16:23:54 --> Severity: Notice --> Undefined variable: piar /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 38
ERROR - 2025-02-19 16:23:54 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 38
ERROR - 2025-02-19 16:23:54 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 16:23:55 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 16:24:24 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 16:24:24 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 16:24:38 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 16:24:38 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 16:24:41 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 16:24:41 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 16:25:24 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 16:25:24 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 16:25:30 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 16:25:30 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 16:29:03 --> Severity: Notice --> Undefined variable: actividades /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 52
ERROR - 2025-02-19 16:29:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 52
ERROR - 2025-02-19 16:29:24 --> Severity: Notice --> Undefined index: descripción /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 16:29:24 --> Severity: Notice --> Undefined index: descripción /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 16:29:33 --> Severity: Notice --> Undefined index: estrategia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 16:29:33 --> Severity: Notice --> Undefined index: estrategia /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 16:41:12 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 16:41:12 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 16:41:26 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 16:41:26 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 16:41:33 --> Severity: Notice --> Undefined index: id_piar_actividad /Applications/MAMP/htdocs/integratic/application/controllers/PIAR.php 232
ERROR - 2025-02-19 16:41:49 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 16:41:49 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 17:48:25 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-19 17:48:25 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-19 17:48:25 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-19 17:48:25 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-19 17:48:26 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-02-19 17:48:26 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 17:48:26 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 17:48:26 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 17:48:26 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 17:48:26 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 17:48:26 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 17:48:26 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 17:48:26 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 17:48:26 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 17:48:26 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 17:48:26 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 17:48:26 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 17:48:26 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 17:48:26 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 17:48:26 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 17:48:26 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 17:48:26 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 17:48:26 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 17:48:26 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 17:48:26 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 17:48:26 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 17:48:27 --> 404 Page Not Found: Images/small
ERROR - 2025-02-19 17:48:32 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 17:48:32 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 45
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: lugar_nacimiento /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 59
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: departamento /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 65
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: municipio /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 71
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: es_centro_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 82
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: es_centro_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 83
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: centro_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 90
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: es_victima_conflicto_armado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 98
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: es_victima_conflicto_armado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 99
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: registro_victima_conflicto_armado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 108
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: registro_victima_conflicto_armado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 109
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 118
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 119
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: tipo_afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 128
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: tipo_afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 129
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: lugar_atencion_emergencia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 136
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: es_atendido_sector_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 145
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: es_atendido_sector_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 146
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: es_atendido_frecuencia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 153
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: recibe_tratamiento_enfermedad_particular /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 163
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: recibe_tratamiento_enfermedad_particular /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 164
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: recibe_tratamiento_enfermedad_particular_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 171
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: nombre_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 206
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:13:00 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: telefono_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 240
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: correo_electronico_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 246
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: lugar_que_ocupa_hermanos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 252
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: quienes_apoyan_crianza /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 258
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: esta_bajo_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 266
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: esta_bajo_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 267
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 276
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 277
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 284
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 294
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 295
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 302
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_aprobo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 324
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_aprobo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 325
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_observaciones /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 332
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 342
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 343
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 350
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: asiste_programas_complementarios /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 358
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: asiste_programas_complementarios /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 359
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: asiste_programas_complementarios_cuales /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 366
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: medio_de_transporte /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 374
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: distancia_institucion_hogar /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 381
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: acciones_familia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 453
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: estrategias_familia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 454
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: acciones_docentes /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 458
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: estrategias_docentes /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 459
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: acciones_directivos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 463
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: estrategias_directivos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 464
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: acciones_administrativos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 468
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: estrategias_administrativos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 469
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: acciones_companeros /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 473
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: estrategias_companeros /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 474
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined index: id_piar /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 42
ERROR - 2025-02-19 18:13:01 --> Severity: Notice --> Undefined variable: activities /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:13:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 45
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: lugar_nacimiento /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 59
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: departamento /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 65
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: municipio /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 71
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: es_centro_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 82
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: es_centro_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 83
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: centro_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 90
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: es_victima_conflicto_armado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 98
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: es_victima_conflicto_armado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 99
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: registro_victima_conflicto_armado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 108
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: registro_victima_conflicto_armado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 109
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 118
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 119
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: tipo_afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 128
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: tipo_afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 129
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: lugar_atencion_emergencia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 136
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: es_atendido_sector_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 145
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: es_atendido_sector_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 146
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: es_atendido_frecuencia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 153
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: recibe_tratamiento_enfermedad_particular /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 163
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: recibe_tratamiento_enfermedad_particular /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 164
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: recibe_tratamiento_enfermedad_particular_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 171
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: nombre_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 206
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: telefono_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 240
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: correo_electronico_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 246
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: lugar_que_ocupa_hermanos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 252
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: quienes_apoyan_crianza /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 258
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: esta_bajo_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 266
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: esta_bajo_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 267
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 276
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 277
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 284
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 294
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 295
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 302
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_aprobo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 324
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_aprobo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 325
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_observaciones /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 332
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 342
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 343
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 350
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: asiste_programas_complementarios /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 358
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: asiste_programas_complementarios /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 359
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: asiste_programas_complementarios_cuales /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 366
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: medio_de_transporte /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 374
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: distancia_institucion_hogar /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 381
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: acciones_familia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 453
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: estrategias_familia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 454
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: acciones_docentes /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 458
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: estrategias_docentes /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 459
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: acciones_directivos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 463
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: estrategias_directivos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 464
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: acciones_administrativos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 468
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: estrategias_administrativos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 469
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: acciones_companeros /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 473
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: estrategias_companeros /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 474
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined index: id_piar /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 42
ERROR - 2025-02-19 18:13:51 --> Severity: Notice --> Undefined variable: activities /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:13:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 45
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: departamento /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 65
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: municipio /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 71
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: es_centro_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 82
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: es_centro_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 83
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: centro_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 90
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: es_victima_conflicto_armado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 98
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: es_victima_conflicto_armado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 99
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: registro_victima_conflicto_armado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 108
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: registro_victima_conflicto_armado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 109
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 118
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 119
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: tipo_afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 128
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: tipo_afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 129
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: lugar_atencion_emergencia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 136
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: es_atendido_sector_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 145
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: es_atendido_sector_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 146
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: es_atendido_frecuencia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 153
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: recibe_tratamiento_enfermedad_particular /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 163
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: recibe_tratamiento_enfermedad_particular /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 164
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: recibe_tratamiento_enfermedad_particular_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 171
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: nombre_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 206
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: telefono_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 240
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: correo_electronico_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 246
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: lugar_que_ocupa_hermanos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 252
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: quienes_apoyan_crianza /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 258
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: esta_bajo_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 266
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: esta_bajo_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 267
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 276
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 277
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 284
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 294
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 295
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 302
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_aprobo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 324
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_aprobo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 325
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_observaciones /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 332
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 342
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 343
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 350
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: asiste_programas_complementarios /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 358
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: asiste_programas_complementarios /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 359
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: asiste_programas_complementarios_cuales /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 366
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: medio_de_transporte /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 374
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: distancia_institucion_hogar /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 381
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: acciones_familia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 453
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: estrategias_familia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 454
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: acciones_docentes /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 458
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: estrategias_docentes /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 459
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: acciones_directivos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 463
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: estrategias_directivos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 464
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: acciones_administrativos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 468
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: estrategias_administrativos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 469
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: acciones_companeros /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 473
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: estrategias_companeros /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 474
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined index: id_piar /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 42
ERROR - 2025-02-19 18:14:06 --> Severity: Notice --> Undefined variable: activities /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:14:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 45
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: municipio /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 71
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: es_centro_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 82
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: es_centro_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 83
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: centro_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 90
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: es_victima_conflicto_armado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 98
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: es_victima_conflicto_armado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 99
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: registro_victima_conflicto_armado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 108
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: registro_victima_conflicto_armado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 109
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 118
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 119
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: tipo_afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 128
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: tipo_afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 129
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: lugar_atencion_emergencia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 136
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: es_atendido_sector_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 145
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: es_atendido_sector_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 146
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: es_atendido_frecuencia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 153
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: recibe_tratamiento_enfermedad_particular /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 163
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: recibe_tratamiento_enfermedad_particular /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 164
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: recibe_tratamiento_enfermedad_particular_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 171
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: nombre_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 206
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: telefono_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 240
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: correo_electronico_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 246
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: lugar_que_ocupa_hermanos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 252
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: quienes_apoyan_crianza /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 258
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: esta_bajo_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 266
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: esta_bajo_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 267
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 276
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 277
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 284
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 294
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 295
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 302
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_aprobo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 324
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_aprobo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 325
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_observaciones /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 332
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 342
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 343
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 350
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: asiste_programas_complementarios /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 358
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: asiste_programas_complementarios /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 359
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: asiste_programas_complementarios_cuales /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 366
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: medio_de_transporte /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 374
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: distancia_institucion_hogar /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 381
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: acciones_familia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 453
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: estrategias_familia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 454
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: acciones_docentes /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 458
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: estrategias_docentes /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 459
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: acciones_directivos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 463
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: estrategias_directivos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 464
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: acciones_administrativos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 468
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: estrategias_administrativos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 469
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: acciones_companeros /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 473
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: estrategias_companeros /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 474
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined index: id_piar /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 42
ERROR - 2025-02-19 18:14:26 --> Severity: Notice --> Undefined variable: activities /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:14:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 45
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: es_centro_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 82
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: es_centro_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 83
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: centro_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 90
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: es_victima_conflicto_armado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 98
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: es_victima_conflicto_armado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 99
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: registro_victima_conflicto_armado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 108
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: registro_victima_conflicto_armado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 109
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 118
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 119
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: tipo_afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 128
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: tipo_afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 129
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: lugar_atencion_emergencia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 136
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: es_atendido_sector_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 145
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: es_atendido_sector_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 146
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: es_atendido_frecuencia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 153
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: recibe_tratamiento_enfermedad_particular /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 163
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: recibe_tratamiento_enfermedad_particular /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 164
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: recibe_tratamiento_enfermedad_particular_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 171
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: nombre_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 206
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: telefono_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 240
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: correo_electronico_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 246
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: lugar_que_ocupa_hermanos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 252
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: quienes_apoyan_crianza /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 258
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: esta_bajo_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 266
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: esta_bajo_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 267
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 276
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 277
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 284
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 294
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 295
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 302
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_aprobo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 324
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_aprobo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 325
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_observaciones /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 332
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 342
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 343
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 350
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: asiste_programas_complementarios /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 358
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: asiste_programas_complementarios /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 359
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: asiste_programas_complementarios_cuales /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 366
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: medio_de_transporte /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 374
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: distancia_institucion_hogar /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 381
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: acciones_familia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 453
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: estrategias_familia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 454
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: acciones_docentes /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 458
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: estrategias_docentes /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 459
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: acciones_directivos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 463
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: estrategias_directivos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 464
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: acciones_administrativos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 468
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: estrategias_administrativos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 469
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: acciones_companeros /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 473
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: estrategias_companeros /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 474
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined index: id_piar /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 42
ERROR - 2025-02-19 18:14:41 --> Severity: Notice --> Undefined variable: activities /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:14:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 45
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: centro_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 90
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: es_victima_conflicto_armado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 98
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: es_victima_conflicto_armado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 99
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: registro_victima_conflicto_armado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 108
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: registro_victima_conflicto_armado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 109
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 118
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 119
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: tipo_afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 128
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: tipo_afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 129
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: lugar_atencion_emergencia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 136
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: es_atendido_sector_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 145
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: es_atendido_sector_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 146
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: es_atendido_frecuencia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 153
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: recibe_tratamiento_enfermedad_particular /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 163
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: recibe_tratamiento_enfermedad_particular /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 164
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: recibe_tratamiento_enfermedad_particular_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 171
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: nombre_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 206
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: telefono_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 240
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: correo_electronico_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 246
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: lugar_que_ocupa_hermanos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 252
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: quienes_apoyan_crianza /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 258
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: esta_bajo_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 266
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: esta_bajo_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 267
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 276
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 277
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 284
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 294
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 295
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 302
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_aprobo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 324
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_aprobo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 325
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_observaciones /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 332
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 342
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 343
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 350
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: asiste_programas_complementarios /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 358
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: asiste_programas_complementarios /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 359
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: asiste_programas_complementarios_cuales /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 366
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: medio_de_transporte /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 374
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: distancia_institucion_hogar /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 381
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: acciones_familia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 453
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: estrategias_familia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 454
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: acciones_docentes /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 458
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: estrategias_docentes /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 459
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: acciones_directivos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 463
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: estrategias_directivos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 464
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: acciones_administrativos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 468
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: estrategias_administrativos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 469
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: acciones_companeros /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 473
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: estrategias_companeros /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 474
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined index: id_piar /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 42
ERROR - 2025-02-19 18:15:24 --> Severity: Notice --> Undefined variable: activities /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:15:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 45
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: centro_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 90
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: tipo_afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 128
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: tipo_afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 129
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: lugar_atencion_emergencia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 136
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: es_atendido_sector_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 145
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: es_atendido_sector_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 146
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: es_atendido_frecuencia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 153
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: recibe_tratamiento_enfermedad_particular /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 163
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: recibe_tratamiento_enfermedad_particular /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 164
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: recibe_tratamiento_enfermedad_particular_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 171
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: nombre_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 206
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: telefono_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 240
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: correo_electronico_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 246
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: lugar_que_ocupa_hermanos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 252
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: quienes_apoyan_crianza /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 258
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: esta_bajo_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 266
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: esta_bajo_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 267
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 276
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 277
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 284
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 294
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 295
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 302
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_aprobo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 324
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_aprobo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 325
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_observaciones /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 332
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 342
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 343
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 350
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: asiste_programas_complementarios /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 358
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: asiste_programas_complementarios /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 359
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: asiste_programas_complementarios_cuales /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 366
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: medio_de_transporte /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 374
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: distancia_institucion_hogar /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 381
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: acciones_familia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 453
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: estrategias_familia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 454
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: acciones_docentes /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 458
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: estrategias_docentes /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 459
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: acciones_directivos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 463
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: estrategias_directivos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 464
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: acciones_administrativos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 468
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: estrategias_administrativos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 469
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: acciones_companeros /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 473
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: estrategias_companeros /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 474
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined index: id_piar /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 42
ERROR - 2025-02-19 18:16:33 --> Severity: Notice --> Undefined variable: activities /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:16:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 45
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: centro_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 90
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: tipo_afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 128
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: tipo_afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 129
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: lugar_atencion_emergencia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 136
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: es_atendido_sector_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 145
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: es_atendido_sector_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 146
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: es_atendido_frecuencia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 153
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: recibe_tratamiento_enfermedad_particular /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 163
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: recibe_tratamiento_enfermedad_particular /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 164
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: recibe_tratamiento_enfermedad_particular_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 171
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: nombre_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 206
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: telefono_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 240
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: correo_electronico_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 246
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: lugar_que_ocupa_hermanos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 252
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: quienes_apoyan_crianza /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 258
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: esta_bajo_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 266
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: esta_bajo_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 267
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 276
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 277
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 284
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 294
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 295
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 302
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_aprobo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 324
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_aprobo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 325
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_observaciones /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 332
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 342
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 343
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 350
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: asiste_programas_complementarios /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 358
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: asiste_programas_complementarios /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 359
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: asiste_programas_complementarios_cuales /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 366
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: medio_de_transporte /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 374
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: distancia_institucion_hogar /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 381
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: acciones_familia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 453
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: estrategias_familia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 454
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: acciones_docentes /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 458
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: estrategias_docentes /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 459
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: acciones_directivos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 463
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: estrategias_directivos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 464
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: acciones_administrativos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 468
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: estrategias_administrativos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 469
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: acciones_companeros /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 473
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: estrategias_companeros /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 474
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined index: id_piar /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 42
ERROR - 2025-02-19 18:16:35 --> Severity: Notice --> Undefined variable: activities /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:16:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 45
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: tipo_afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 128
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: tipo_afiliacion_sistema_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 129
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: lugar_atencion_emergencia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 136
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: es_atendido_sector_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 145
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: es_atendido_sector_salud /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 146
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: es_atendido_frecuencia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 153
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: recibe_tratamiento_enfermedad_particular /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 163
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: recibe_tratamiento_enfermedad_particular /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 164
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: recibe_tratamiento_enfermedad_particular_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 171
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: nombre_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 206
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: telefono_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 240
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: correo_electronico_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 246
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: lugar_que_ocupa_hermanos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 252
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: quienes_apoyan_crianza /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 258
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: esta_bajo_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 266
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: esta_bajo_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 267
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 276
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 277
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 284
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 294
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 295
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 302
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_aprobo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 324
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_aprobo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 325
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_observaciones /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 332
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 342
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 343
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 350
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: asiste_programas_complementarios /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 358
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: asiste_programas_complementarios /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 359
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: asiste_programas_complementarios_cuales /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 366
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: medio_de_transporte /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 374
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: distancia_institucion_hogar /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 381
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: acciones_familia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 453
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: estrategias_familia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 454
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: acciones_docentes /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 458
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: estrategias_docentes /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 459
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: acciones_directivos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 463
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: estrategias_directivos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 464
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: acciones_administrativos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 468
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: estrategias_administrativos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 469
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: acciones_companeros /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 473
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: estrategias_companeros /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 474
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined index: id_piar /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 42
ERROR - 2025-02-19 18:16:48 --> Severity: Notice --> Undefined variable: activities /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:16:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 45
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: nombre_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 206
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: telefono_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 240
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: correo_electronico_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 246
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: lugar_que_ocupa_hermanos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 252
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: quienes_apoyan_crianza /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 258
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: esta_bajo_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 266
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: esta_bajo_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 267
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 276
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 277
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 284
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 294
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 295
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 302
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_aprobo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 324
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_aprobo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 325
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_observaciones /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 332
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 342
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 343
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 350
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: asiste_programas_complementarios /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 358
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: asiste_programas_complementarios /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 359
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: asiste_programas_complementarios_cuales /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 366
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: medio_de_transporte /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 374
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: distancia_institucion_hogar /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 381
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: acciones_familia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 453
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: estrategias_familia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 454
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: acciones_docentes /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 458
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: estrategias_docentes /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 459
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: acciones_directivos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 463
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: estrategias_directivos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 464
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: acciones_administrativos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 468
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: estrategias_administrativos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 469
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: acciones_companeros /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 473
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: estrategias_companeros /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 474
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined index: id_piar /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 42
ERROR - 2025-02-19 18:18:19 --> Severity: Notice --> Undefined variable: activities /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:18:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 45
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: lugar_que_ocupa_hermanos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 252
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: quienes_apoyan_crianza /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 258
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: esta_bajo_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 266
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: esta_bajo_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 267
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 276
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 277
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: recibe_subsidio_entidad_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 284
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 294
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 295
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 302
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_aprobo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 324
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_aprobo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 325
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_observaciones /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 332
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 342
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 343
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 350
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: asiste_programas_complementarios /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 358
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: asiste_programas_complementarios /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 359
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: asiste_programas_complementarios_cuales /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 366
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: medio_de_transporte /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 374
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: distancia_institucion_hogar /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 381
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: acciones_familia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 453
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: estrategias_familia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 454
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: acciones_docentes /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 458
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: estrategias_docentes /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 459
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: acciones_directivos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 463
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: estrategias_directivos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 464
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: acciones_administrativos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 468
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: estrategias_administrativos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 469
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: acciones_companeros /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 473
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: estrategias_companeros /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 474
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined index: id_piar /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 42
ERROR - 2025-02-19 18:18:54 --> Severity: Notice --> Undefined variable: activities /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:18:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 45
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 294
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 295
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion_cual /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 302
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_aprobo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 324
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_aprobo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 325
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_observaciones /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 332
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 342
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 343
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: recibe_informe_pedagogico_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 350
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: asiste_programas_complementarios /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 358
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: asiste_programas_complementarios /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 359
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: asiste_programas_complementarios_cuales /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 366
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: medio_de_transporte /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 374
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: distancia_institucion_hogar /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 381
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: acciones_familia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 453
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: estrategias_familia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 454
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: acciones_docentes /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 458
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: estrategias_docentes /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 459
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: acciones_directivos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 463
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: estrategias_directivos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 464
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: acciones_administrativos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 468
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: estrategias_administrativos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 469
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: acciones_companeros /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 473
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: estrategias_companeros /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 474
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined index: id_piar /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 42
ERROR - 2025-02-19 18:23:22 --> Severity: Notice --> Undefined variable: activities /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:23:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 45
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: distancia_institucion_hogar /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 381
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: acciones_familia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 453
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: estrategias_familia /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 454
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: acciones_docentes /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 458
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: estrategias_docentes /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 459
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: acciones_directivos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 463
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: estrategias_directivos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 464
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: acciones_administrativos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 468
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: estrategias_administrativos /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 469
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: acciones_companeros /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 473
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: estrategias_companeros /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 474
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined index: id_piar /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 42
ERROR - 2025-02-19 18:26:51 --> Severity: Notice --> Undefined variable: activities /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:26:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 45
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined index: id_piar /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 42
ERROR - 2025-02-19 18:28:52 --> Severity: Notice --> Undefined variable: activities /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:28:52 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 45
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:29:31 --> Severity: Notice --> Undefined variable: activities /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:29:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 45
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:29:46 --> Severity: Notice --> Undefined variable: activities /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 57
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 45
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:30:01 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:36:27 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 18:36:28 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-19 18:36:28 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-19 18:36:28 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-19 18:36:28 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-19 18:36:28 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-19 18:36:28 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-19 18:36:28 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-19 18:36:28 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-19 18:36:29 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-02-19 18:36:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 18:36:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 18:36:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 18:36:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 18:36:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 18:36:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 18:36:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 18:36:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 18:36:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 18:36:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 18:36:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 18:36:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 18:36:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 18:36:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 18:36:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 18:36:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 18:36:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 18:36:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 18:36:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 18:36:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 18:36:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 18:36:30 --> 404 Page Not Found: Images/small
ERROR - 2025-02-19 18:36:32 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 18:36:32 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 18:36:32 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 18:36:32 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 18:36:32 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 18:36:32 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 18:37:04 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 18:37:04 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 18:37:04 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 18:37:18 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 18:37:18 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 18:37:18 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 45
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:38:54 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 45
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 18:40:02 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-19 19:23:27 --> Severity: Warning --> strtolower() expects exactly 1 parameter, 0 given /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 51
ERROR - 2025-02-19 19:23:27 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 51
ERROR - 2025-02-19 19:23:27 --> Severity: Warning --> strtolower() expects exactly 1 parameter, 0 given /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 51
ERROR - 2025-02-19 19:23:27 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 51
ERROR - 2025-02-19 19:28:19 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 19:28:19 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 19:28:50 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 19:28:50 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 19:29:08 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 19:29:08 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 19:31:42 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 19:31:42 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 19:31:43 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-19 19:31:43 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-19 19:31:43 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-19 19:31:43 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-19 19:32:34 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 19:32:34 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 19:32:34 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-19 19:32:34 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-19 19:32:34 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-19 19:32:34 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-19 19:32:34 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-02-19 19:32:34 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 19:32:34 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 19:32:34 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 19:32:34 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 19:32:34 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 19:32:34 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 19:32:34 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 19:32:34 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 19:32:34 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 19:32:34 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 19:32:34 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 19:32:34 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 19:32:34 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 19:32:34 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 19:32:34 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 19:32:34 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 19:32:34 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 19:32:34 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 19:32:34 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 19:32:34 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 19:32:34 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-19 19:32:36 --> 404 Page Not Found: Images/small
ERROR - 2025-02-19 19:32:37 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 19:32:37 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 19:32:37 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 19:32:37 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 19:32:37 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 19:32:37 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 19:32:37 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 19:32:37 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 19:32:41 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 19:32:41 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 19:33:01 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 19:33:01 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 19:34:36 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 19:34:36 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 19:36:44 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 19:36:44 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 19:36:51 --> Query error: Unknown column 'observaciones' in 'field list' - Invalid query: UPDATE `piar` SET `id_piar` = '1', `observaciones` = ''
WHERE `id_piar` = '1'
ERROR - 2025-02-19 19:37:11 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 19:37:11 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 19:37:26 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 19:37:26 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 19:38:07 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 19:38:07 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 19:38:13 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 19:38:13 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 19:41:09 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 19:41:09 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 19:41:09 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 19:41:09 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 19:41:09 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-19 19:41:14 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 19:41:14 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 19:41:24 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 19:41:24 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-19 19:41:52 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-19 19:41:52 --> 404 Page Not Found: Js/chart.umd.js.map
