<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-11-20 09:55:25 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-20 09:55:25 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-20 09:55:25 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-20 09:55:25 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-20 09:55:25 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-11-20 09:55:25 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 09:55:25 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 09:55:25 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 09:55:25 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 09:55:25 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 09:55:25 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 09:55:25 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 09:55:25 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 09:55:25 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 09:55:25 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 09:55:25 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 09:55:25 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 09:55:25 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 09:55:25 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 09:55:25 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 09:55:25 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 09:55:26 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 09:55:26 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 09:55:26 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 09:55:26 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 09:55:26 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 09:55:27 --> 404 Page Not Found: Images/small
ERROR - 2024-11-20 09:55:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 09:55:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 09:55:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 09:55:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 09:55:49 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.u.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `u`.*, `e`.*, `e`.`email` as `email`, `cer`.`id_pregunta`
FROM `estudiante` `e`
LEFT JOIN `usuarios` `u` ON `e`.`documento` = `u`.`id`
LEFT OUTER JOIN `caracterizacion_estudiantes_respuestas` `cer` ON `cer`.`id_estudiante` = `u`.`id`
GROUP BY `e`.`documento`
ORDER BY `e`.`grado` ASC, `e`.`nombre` ASC
ERROR - 2024-11-20 10:03:26 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2024-11-20 10:41:34 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2024-11-20 10:42:56 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2024-11-20 10:43:44 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2024-11-20 10:43:49 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2024-11-20 10:44:29 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2024-11-20 10:44:31 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2024-11-20 10:44:56 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2024-11-20 10:56:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 10:56:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 10:56:53 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2024-11-20 10:57:05 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2024-11-20 10:57:20 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2024-11-20 10:57:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 10:57:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 10:57:47 --> Severity: Warning --> mkdir(): File exists /Applications/MAMP/htdocs/integratic/application/controllers/Asignacion.php 52
ERROR - 2024-11-20 10:57:53 --> Severity: Warning --> mkdir(): File exists /Applications/MAMP/htdocs/integratic/application/controllers/Asignacion.php 52
ERROR - 2024-11-20 10:58:02 --> Severity: Warning --> mkdir(): File exists /Applications/MAMP/htdocs/integratic/application/controllers/Asignacion.php 52
ERROR - 2024-11-20 10:58:07 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-20 10:58:07 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-20 10:58:07 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-20 10:58:07 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-20 10:58:07 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-20 10:58:07 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-20 10:58:07 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-20 10:58:07 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-20 10:58:07 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-11-20 10:58:07 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 10:58:07 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 10:58:07 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 10:58:07 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 10:58:07 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 10:58:07 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 10:58:07 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 10:58:07 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 10:58:07 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 10:58:07 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 10:58:07 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 10:58:07 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 10:58:07 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 10:58:07 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 10:58:07 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 10:58:07 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 10:58:07 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 10:58:07 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 10:58:07 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 10:58:07 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 10:58:07 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 10:58:09 --> 404 Page Not Found: Images/small
ERROR - 2024-11-20 10:58:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 10:58:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 10:58:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 10:58:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:07:34 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-20 11:07:34 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-20 11:07:34 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-20 11:07:34 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-20 11:07:34 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-20 11:07:34 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-20 11:07:34 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-20 11:07:34 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-20 11:07:34 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-11-20 11:07:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:07:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:07:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:07:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:07:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:07:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:07:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:07:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:07:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:07:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:07:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:07:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:07:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:07:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:07:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:07:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:07:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:07:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:07:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:07:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:07:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:07:35 --> 404 Page Not Found: Images/small
ERROR - 2024-11-20 11:07:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:07:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:07:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:07:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:07:38 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2024-11-20 11:45:09 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-20 11:45:09 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-20 11:45:09 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-20 11:45:09 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-20 11:45:09 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-11-20 11:45:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:45:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:45:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:45:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:45:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:45:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:45:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:45:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:45:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:45:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:45:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:45:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:45:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:45:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:45:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:45:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:45:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:45:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:45:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:45:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:45:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-20 11:45:10 --> 404 Page Not Found: Images/small
ERROR - 2024-11-20 11:45:15 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:45:15 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:45:15 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:45:15 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:45:17 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:45:17 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:45:19 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:45:19 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:45:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:45:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:45:29 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:45:29 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:46:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:46:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:46:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:46:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:47:38 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:47:38 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:50:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:50:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:50:24 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:50:24 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:50:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:50:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:50:30 --> Severity: error --> Exception: Call to undefined method Estudiante_Model::getStudentsByDocuemnt() /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 197
ERROR - 2024-11-20 11:50:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:50:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:51:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:51:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:55:10 --> Query error: Table 'integratic.users' doesn't exist - Invalid query: SELECT *
FROM `recuperaciones`
JOIN `periodos` ON `periodos`.`id_periodo` = `recuperaciones`.`id_periodo`
JOIN `cfg_materias` ON `cfg_materias`.`codmateria` = `recuperaciones`.`materia`
JOIN `users` ON `users`.`id` = `recuperaciones`.`created_by`
WHERE `id_recuperacion` = '2'
ERROR - 2024-11-20 11:55:23 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:55:23 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:55:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:55:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:56:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:56:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:56:31 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-11-20 11:56:31 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-11-20 11:56:38 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:56:38 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:56:39 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-11-20 11:56:39 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-11-20 11:56:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:56:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:56:49 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-11-20 11:56:49 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-11-20 11:58:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:58:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:58:17 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-11-20 11:58:17 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-11-20 11:58:34 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:58:34 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:58:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:58:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:59:37 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:59:37 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:59:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-20 11:59:40 --> 404 Page Not Found: Img/iconos
