<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-03-28 09:08:30 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 09:08:30 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 09:08:30 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 09:08:30 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 09:08:30 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 09:08:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:08:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:08:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:08:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:08:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:08:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:08:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:08:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:08:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:08:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:08:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:08:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:08:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:08:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:08:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:08:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:08:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:08:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:08:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:08:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:08:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:10:57 --> 404 Page Not Found: Images/small
ERROR - 2025-03-28 09:10:58 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 09:10:58 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 09:10:58 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.m.codmateria' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: Select * from cfg_areas a left join cfg_materias m on a.codarea = m.area join asg_materias am on am.materia = m.codmateria where m.grado = '11' and am.grupo = 'A' group by a.codarea
ERROR - 2025-03-28 09:11:11 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 09:11:11 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 09:11:11 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 09:11:11 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 09:11:11 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 09:11:11 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 09:11:11 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 09:11:11 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 09:11:11 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 09:11:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:12 --> 404 Page Not Found: Images/small
ERROR - 2025-03-28 09:11:19 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:19 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:19 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:19 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:42 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 09:11:42 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 09:11:42 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 09:11:42 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 09:11:42 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 09:11:42 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 09:11:42 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 09:11:42 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 09:11:42 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 09:11:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:11:44 --> 404 Page Not Found: Images/small
ERROR - 2025-03-28 09:11:49 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 09:11:49 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 09:12:03 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 09:12:03 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 09:12:03 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 09:12:03 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 09:12:03 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 09:12:03 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 09:12:03 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 09:12:03 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 09:12:04 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 09:12:04 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:12:04 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:12:04 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:12:04 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:12:04 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:12:04 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:12:04 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:12:04 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:12:04 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:12:04 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:12:04 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:12:04 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:12:04 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:12:04 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:12:04 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:12:04 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:12:04 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:12:04 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:12:04 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:12:04 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:12:04 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:12:05 --> 404 Page Not Found: Images/small
ERROR - 2025-03-28 09:12:06 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:12:06 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:12:06 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:12:06 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:13:52 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 09:13:52 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 09:13:52 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 09:13:52 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 09:13:52 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 09:13:52 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 09:13:52 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 09:13:52 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 09:13:52 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 09:13:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:13:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:13:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:13:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:13:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:13:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:13:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:13:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:13:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:13:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:13:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:13:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:13:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:13:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:13:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:13:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:13:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:13:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:13:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:13:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:13:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:13:53 --> 404 Page Not Found: Images/small
ERROR - 2025-03-28 09:13:59 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 09:14:00 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 09:14:03 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 09:19:34 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 09:19:39 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 09:19:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:43 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 09:19:43 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 09:19:43 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 09:19:43 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 09:19:43 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 09:19:43 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 09:19:43 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 09:19:43 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 09:19:43 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 09:19:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:44 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:44 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:44 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:45 --> 404 Page Not Found: Images/small
ERROR - 2025-03-28 09:19:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 09:19:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 10:43:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 10:43:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 10:43:54 --> Severity: Notice --> Undefined property: Ingresos::$Ingresos_Model /Applications/MAMP/htdocs/integratic/application/controllers/Ingresos.php 19
ERROR - 2025-03-28 10:43:54 --> Severity: error --> Exception: Call to a member function getIngresos() on null /Applications/MAMP/htdocs/integratic/application/controllers/Ingresos.php 19
ERROR - 2025-03-28 10:44:14 --> Severity: Notice --> Undefined property: Ingresos::$Ingresos_Model /Applications/MAMP/htdocs/integratic/application/controllers/Ingresos.php 19
ERROR - 2025-03-28 10:44:14 --> Severity: error --> Exception: Call to a member function getIngresos() on null /Applications/MAMP/htdocs/integratic/application/controllers/Ingresos.php 19
ERROR - 2025-03-28 10:46:00 --> Query error: Table 'integratic.estudiantes' doesn't exist - Invalid query: SELECT *
FROM `ingresos` `i`
JOIN `usuarios` `u` ON `i`.`documento` = `u`.`id`
JOIN `estudiantes` `e` ON `u`.`id` = `e`.`documento`
ERROR - 2025-03-28 10:51:51 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 10:51:51 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 10:52:04 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 10:52:04 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 10:54:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 10:54:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 10:54:37 --> 404 Page Not Found: Principal/manuales
ERROR - 2025-03-28 15:09:28 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 15:09:28 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 15:09:28 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 15:09:28 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 15:09:28 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 15:09:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:09:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:09:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:09:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:09:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:09:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:09:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:09:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:09:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:09:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:09:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:09:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:09:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:09:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:09:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:09:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:09:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:09:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:09:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:09:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:09:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:09:29 --> 404 Page Not Found: Images/small
ERROR - 2025-03-28 15:09:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:09:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:09:31 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:09:31 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:17:52 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 15:17:52 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 15:18:23 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 15:18:23 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 15:18:25 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 15:18:25 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 15:18:34 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 15:18:35 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 15:18:45 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 15:18:46 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 15:18:49 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 15:18:49 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 15:18:56 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 15:18:56 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 15:19:02 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 15:19:02 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 15:19:10 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 15:19:10 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 15:19:21 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 15:19:21 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 15:19:25 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 15:19:25 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 15:19:30 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 15:19:30 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 15:19:39 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 15:19:39 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 15:19:45 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 15:19:45 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 15:19:52 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 15:19:52 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 15:20:04 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 15:20:04 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 15:20:21 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 15:20:21 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 15:20:27 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 15:20:27 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 15:21:53 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 15:21:53 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 15:22:03 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 15:22:03 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 15:22:16 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 15:22:16 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 15:22:52 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 15:22:53 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 15:24:38 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 15:24:38 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 15:34:39 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:34:46 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:34:47 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:34:55 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:35:09 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/ingresos/index.php 61
ERROR - 2025-03-28 15:35:09 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:35:30 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/ingresos/index.php 61
ERROR - 2025-03-28 15:35:30 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:35:43 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:36:02 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:36:48 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:37:09 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:37:25 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:38:03 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:38:37 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:39:07 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:40:06 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:40:09 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:40:11 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:40:13 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:40:16 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:40:36 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:41:04 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:41:06 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:41:26 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:41:40 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:41:43 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:41:56 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:41:58 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:42:05 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 15:42:05 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 15:42:49 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/integratic/application/views/ingresos/index.php 34
ERROR - 2025-03-28 15:42:49 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/integratic/application/views/ingresos/index.php 34
ERROR - 2025-03-28 15:42:49 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/integratic/application/views/ingresos/index.php 34
ERROR - 2025-03-28 15:42:49 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/integratic/application/views/ingresos/index.php 34
ERROR - 2025-03-28 15:42:49 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/integratic/application/views/ingresos/index.php 34
ERROR - 2025-03-28 15:42:49 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:42:51 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 15:42:51 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 15:43:16 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:43:17 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 15:43:17 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 15:44:19 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:44:21 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:44:27 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:44:32 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:44:37 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:47:32 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 15:47:32 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 15:49:00 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:49:05 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:52:06 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:52:14 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:52:30 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:52:39 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:53:33 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-03-28 15:53:43 --> 404 Page Not Found: Ingresos/usuario
ERROR - 2025-03-28 15:53:53 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:53:53 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:54:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:54:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 15:54:45 --> 404 Page Not Found: Ingresos/usuario
ERROR - 2025-03-28 16:09:59 --> Severity: Notice --> Undefined variable: ingresos /Applications/MAMP/htdocs/integratic/application/views/ingresos/usuario.php 88
ERROR - 2025-03-28 16:09:59 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/ingresos/usuario.php 88
ERROR - 2025-03-28 16:09:59 --> Severity: Notice --> Undefined variable: ingresos /Applications/MAMP/htdocs/integratic/application/views/ingresos/usuario.php 88
ERROR - 2025-03-28 16:09:59 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/ingresos/usuario.php 88
ERROR - 2025-03-28 16:10:24 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/ingresos/usuario.php 88
ERROR - 2025-03-28 16:10:24 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/ingresos/usuario.php 88
ERROR - 2025-03-28 16:10:44 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/ingresos/usuario.php 88
ERROR - 2025-03-28 16:14:44 --> Severity: Compile Error --> Cannot redeclare Ingresos_Model::getIngresosUsuario() /Applications/MAMP/htdocs/integratic/application/models/Ingresos_Model.php 57
ERROR - 2025-03-28 16:14:56 --> Severity: Compile Error --> Cannot redeclare Ingresos_Model::getIngresosUsuario() /Applications/MAMP/htdocs/integratic/application/models/Ingresos_Model.php 57
ERROR - 2025-03-28 16:15:45 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/ingresos/usuario.php 88
ERROR - 2025-03-28 16:42:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/ingresos/usuario.php 15
ERROR - 2025-03-28 16:42:47 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/ingresos/usuario.php 15
ERROR - 2025-03-28 16:42:47 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/ingresos/usuario.php 15
ERROR - 2025-03-28 16:42:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/ingresos/usuario.php 15
ERROR - 2025-03-28 16:42:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/ingresos/usuario.php 15
ERROR - 2025-03-28 17:31:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/ingresos/usuario.php 15
ERROR - 2025-03-28 17:31:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/ingresos/usuario.php 15
ERROR - 2025-03-28 17:31:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/ingresos/usuario.php 15
ERROR - 2025-03-28 17:31:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/ingresos/usuario.php 15
ERROR - 2025-03-28 17:32:02 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/ingresos/usuario.php 15
ERROR - 2025-03-28 17:32:02 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/ingresos/usuario.php 15
ERROR - 2025-03-28 17:32:06 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:32:06 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:37:11 --> 404 Page Not Found: Principal/manuales
ERROR - 2025-03-28 17:37:24 --> 404 Page Not Found: Principal/manuales
ERROR - 2025-03-28 17:37:26 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:37:26 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:37:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:37:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:38:45 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:38:45 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:38:46 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:38:46 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:39:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:39:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:39:20 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:39:20 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:39:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:39:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:39:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:39:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:39:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:39:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:39:23 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:39:23 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:39:24 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:39:24 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:39:24 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:39:24 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:39:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:39:30 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:39:32 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:39:32 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:39:32 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:39:32 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:40:58 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:40:58 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:41:07 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 17:41:07 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 17:41:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:41:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:41:41 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 17:41:41 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 17:42:00 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:00 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:00 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 17:42:00 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 17:42:02 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:02 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:03 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 17:42:03 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 17:42:03 --> 404 Page Not Found: Principal/manuales
ERROR - 2025-03-28 17:42:06 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 17:42:07 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 17:42:07 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 17:42:07 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 17:42:07 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 17:42:07 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 17:42:07 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 17:42:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:10 --> 404 Page Not Found: Images/small
ERROR - 2025-03-28 17:42:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:42:17 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 17:42:19 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.u.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `u`.*, `e`.*, `e`.`email` as `email`, `cer`.`id_pregunta`
FROM `estudiante` `e`
LEFT JOIN `usuarios` `u` ON `e`.`documento` = `u`.`id`
LEFT OUTER JOIN `caracterizacion_estudiantes_respuestas` `cer` ON `cer`.`id_estudiante` = `u`.`id`
GROUP BY `e`.`documento`
ORDER BY `e`.`grado` ASC, `e`.`nombre` ASC
ERROR - 2025-03-28 17:43:08 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 17:43:08 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 17:43:08 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 17:43:08 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 17:43:08 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 17:43:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:43:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:43:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:43:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:43:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:43:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:43:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:43:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:43:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:43:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:43:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:43:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:43:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:43:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:43:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:43:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:43:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:43:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:43:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:43:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:43:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:12 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 17:44:12 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 17:44:12 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 17:44:12 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 17:44:12 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 17:44:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:16 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 17:44:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:17 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 17:44:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:40 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 17:44:40 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 17:44:40 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 17:44:40 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 17:44:40 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 17:44:40 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:40 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:40 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:40 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:40 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:40 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:40 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:40 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:40 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:40 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:40 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:40 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:40 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:40 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:40 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:40 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:40 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:40 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:40 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:40 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:40 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:44:43 --> 404 Page Not Found: Images/small
ERROR - 2025-03-28 17:44:50 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:44:50 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:46:31 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:47:19 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:48:10 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:48:12 --> 404 Page Not Found: Images/small
ERROR - 2025-03-28 17:48:12 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:49:20 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:49:23 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.u.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `u`.*, `e`.*, `e`.`email` as `email`, `cer_responses`.`caracterizacion_respuestas`
FROM `estudiante` `e`
LEFT JOIN `usuarios` `u` ON `e`.`documento` = `u`.`id`
LEFT OUTER JOIN (SELECT `cer`.`id_estudiante`, JSON_ARRAYAGG(JSON_OBJECT("id_pregunta", `cer`.`id_pregunta`, "respuesta", cer.respuesta)) as caracterizacion_respuestas
FROM `caracterizacion_estudiantes_respuestas` `cer`
GROUP BY `cer`.`id_estudiante`) as cer_responses ON `cer_responses`.`id_estudiante` = `u`.`id`
WHERE `e`.`grado` = '11A'
GROUP BY `e`.`documento`
ORDER BY `e`.`grado` ASC, `e`.`nombre` ASC
ERROR - 2025-03-28 17:49:28 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.u.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `u`.*, `e`.*, `e`.`email` as `email`, `cer_responses`.`caracterizacion_respuestas`
FROM `estudiante` `e`
LEFT JOIN `usuarios` `u` ON `e`.`documento` = `u`.`id`
LEFT OUTER JOIN (SELECT `cer`.`id_estudiante`, JSON_ARRAYAGG(JSON_OBJECT("id_pregunta", `cer`.`id_pregunta`, "respuesta", cer.respuesta)) as caracterizacion_respuestas
FROM `caracterizacion_estudiantes_respuestas` `cer`
GROUP BY `cer`.`id_estudiante`) as cer_responses ON `cer_responses`.`id_estudiante` = `u`.`id`
WHERE `e`.`grado` = '11A'
GROUP BY `e`.`documento`
ORDER BY `e`.`grado` ASC, `e`.`nombre` ASC
ERROR - 2025-03-28 17:49:38 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:50:53 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:50:58 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.u.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `u`.*, `e`.*, `e`.`email` as `email`, `cer_responses`.`caracterizacion_respuestas`
FROM `estudiante` `e`
LEFT JOIN `usuarios` `u` ON `e`.`documento` = `u`.`id`
LEFT OUTER JOIN (SELECT `cer`.`id_estudiante`, JSON_ARRAYAGG(JSON_OBJECT("id_pregunta", `cer`.`id_pregunta`, "respuesta", cer.respuesta)) as caracterizacion_respuestas
FROM `caracterizacion_estudiantes_respuestas` `cer`
GROUP BY `cer`.`id_estudiante`) as cer_responses ON `cer_responses`.`id_estudiante` = `u`.`id`
WHERE `e`.`grado` = '11A'
GROUP BY `e`.`documento`
ORDER BY `e`.`grado` ASC, `e`.`nombre` ASC
ERROR - 2025-03-28 17:51:05 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:51:05 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:51:05 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:51:05 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:51:05 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:51:08 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.u.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `u`.*, `e`.*, `e`.`email` as `email`, `cer_responses`.`caracterizacion_respuestas`
FROM `estudiante` `e`
LEFT JOIN `usuarios` `u` ON `e`.`documento` = `u`.`id`
LEFT OUTER JOIN (SELECT `cer`.`id_estudiante`, JSON_ARRAYAGG(JSON_OBJECT("id_pregunta", `cer`.`id_pregunta`, "respuesta", cer.respuesta)) as caracterizacion_respuestas
FROM `caracterizacion_estudiantes_respuestas` `cer`
GROUP BY `cer`.`id_estudiante`) as cer_responses ON `cer_responses`.`id_estudiante` = `u`.`id`
WHERE `e`.`grado` = '11A'
GROUP BY `e`.`documento`
ORDER BY `e`.`grado` ASC, `e`.`nombre` ASC
ERROR - 2025-03-28 17:52:08 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:52:40 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:52:46 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:52:54 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:52:59 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:53:01 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:53:02 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:53:02 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:53:02 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:53:02 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:53:02 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 17:53:03 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:53:03 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:53:55 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:54:08 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:54:58 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:55:07 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:55:46 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:55:46 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:56:20 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:56:32 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:56:37 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:56:51 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:56:58 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:57:02 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:57:04 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:58:08 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:58:28 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 17:58:47 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:00:00 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:00:19 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:00:49 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:00:51 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:01:20 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:01:26 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:01:42 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:02:15 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:03:07 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:03:16 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:03:18 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:03:19 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:03:59 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:04:01 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:04:01 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:04:14 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:04:26 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:04:31 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:04:59 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:04:59 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:06:42 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 18:06:42 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 18:11:07 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 18:11:07 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 18:14:33 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 18:14:33 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 18:15:08 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 18:15:08 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 18:15:41 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 18:15:41 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 18:17:04 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 18:17:04 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 18:17:06 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.cm.codmateria' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT *
FROM `cfg_areas` `ca`
JOIN `cfg_materias` `cm` ON `ca`.`codarea` = `cm`.`area`
JOIN `asg_materias` `am` ON `am`.`materia` = `cm`.`codmateria`
WHERE `am`.`docente` = '12345'
GROUP BY `ca`.`codarea`
ERROR - 2025-03-28 18:17:08 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 18:17:08 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 18:18:07 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 18:18:07 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 18:18:08 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 18:18:08 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 18:19:03 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 18:19:03 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 18:20:26 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-28 18:20:26 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-28 18:25:00 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:25:00 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:26:01 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:26:01 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:26:07 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:26:07 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:26:47 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:27:23 --> 404 Page Not Found: PlanAula/index.php
ERROR - 2025-03-28 18:27:34 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:27:34 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:28:16 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:28:48 --> 404 Page Not Found: Cursos/index.php
ERROR - 2025-03-28 18:28:57 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:28:57 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:30:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:30:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:30:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:30:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:30:52 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2025-03-28 18:31:11 --> 404 Page Not Found: Images/small
ERROR - 2025-03-28 18:32:07 --> 404 Page Not Found: EstadisticasPruebas/index.php
ERROR - 2025-03-28 18:32:10 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-28 18:34:24 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 18:34:24 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 18:34:24 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 18:34:24 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 18:34:24 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 18:34:24 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:24 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:24 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:24 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:24 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:24 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:24 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:24 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:24 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:24 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:24 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:24 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:24 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:24 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:24 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:24 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:24 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:24 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:24 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:24 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:24 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:26 --> 404 Page Not Found: Images/small
ERROR - 2025-03-28 18:34:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:28 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:29 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 18:34:29 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 18:34:29 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 18:34:29 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 18:34:29 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 18:34:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:34:30 --> 404 Page Not Found: Images/small
ERROR - 2025-03-28 18:34:38 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:34:38 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:37:27 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:38:13 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:38:23 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:39:06 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:39:10 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:39:13 --> 404 Page Not Found: Images/small
ERROR - 2025-03-28 18:39:13 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:39:36 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:39:38 --> 404 Page Not Found: Images/small
ERROR - 2025-03-28 18:39:38 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:43:48 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 18:53:11 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 18:53:11 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 18:53:11 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 18:53:11 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 18:53:11 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 18:53:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:53:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:53:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:53:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:53:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:53:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:53:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:53:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:53:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:53:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:53:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:53:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:53:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:53:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:53:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:53:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:53:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:53:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:53:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:53:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:53:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:53:12 --> 404 Page Not Found: Images/small
ERROR - 2025-03-28 18:53:56 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:53:56 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:53:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:53:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:00 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-03-28 18:54:15 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 18:54:15 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 18:54:15 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 18:54:15 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 18:54:15 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 18:54:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:16 --> 404 Page Not Found: Images/small
ERROR - 2025-03-28 18:54:22 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 18:54:22 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 18:54:22 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 18:54:22 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 18:54:22 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 18:54:22 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 18:54:22 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 18:54:22 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 18:54:22 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 18:54:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 18:54:24 --> 404 Page Not Found: Images/small
ERROR - 2025-03-28 18:59:05 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2025-03-28 18:59:50 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2025-03-28 19:00:08 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2025-03-28 19:03:37 --> 404 Page Not Found: Calendario/index.php
ERROR - 2025-03-28 19:04:06 --> 404 Page Not Found: Calendario/index.php
ERROR - 2025-03-28 19:04:13 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2025-03-28 19:04:15 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 19:04:15 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 19:04:15 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 19:04:15 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 19:04:15 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 19:04:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:15 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:17 --> 404 Page Not Found: Images/small
ERROR - 2025-03-28 19:04:38 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 19:04:38 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 19:04:38 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 19:04:38 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 19:04:38 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 19:04:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:04:39 --> 404 Page Not Found: Images/small
ERROR - 2025-03-28 19:04:52 --> 404 Page Not Found: Calendario/index.php
ERROR - 2025-03-28 19:05:03 --> 404 Page Not Found: Calendario/index.php
ERROR - 2025-03-28 19:05:08 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 19:05:08 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 19:05:08 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 19:05:08 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 19:05:08 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 19:05:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:05:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:05:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:05:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:05:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:05:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:05:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:05:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:05:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:05:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:05:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:05:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:05:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:05:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:05:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:05:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:05:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:05:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:05:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:05:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:05:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:05:10 --> 404 Page Not Found: Images/small
ERROR - 2025-03-28 19:05:13 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 19:05:14 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 19:05:25 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 19:05:29 --> 404 Page Not Found: Cursos/index.php
ERROR - 2025-03-28 19:05:40 --> 404 Page Not Found: Cursos/index.php
ERROR - 2025-03-28 19:05:44 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 19:05:52 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 19:06:02 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 19:06:04 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 19:06:06 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 19:06:06 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 19:06:07 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 19:06:08 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 19:06:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:06:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:06:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:06:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:06:09 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2025-03-28 19:06:12 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 19:08:50 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 19:08:51 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 19:08:52 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 19:08:52 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 19:08:55 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 19:08:55 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 19:08:56 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 19:09:33 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-28 19:12:07 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 85
ERROR - 2025-03-28 19:12:49 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 19:12:49 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 19:12:49 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 19:12:49 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 19:12:49 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 19:12:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:12:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:12:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:12:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:12:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:12:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:12:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:12:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:12:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:12:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:12:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:12:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:12:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:12:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:12:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:12:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:12:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:12:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:12:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:12:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:12:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:12:50 --> 404 Page Not Found: Images/small
ERROR - 2025-03-28 19:13:06 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:06 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:06 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:06 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:06 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2025-03-28 19:13:11 --> 404 Page Not Found: Images/small
ERROR - 2025-03-28 19:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 19:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 19:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 19:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 19:13:18 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 19:13:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:18 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:19 --> 404 Page Not Found: Images/small
ERROR - 2025-03-28 19:13:47 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-28 19:13:47 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-28 19:13:47 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-28 19:13:47 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-28 19:13:47 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 19:13:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:49 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/controllers/Principal.php 81
ERROR - 2025-03-28 19:13:49 --> Severity: Notice --> Undefined variable: result /Applications/MAMP/htdocs/integratic/application/models/Consultas_Model.php 27
ERROR - 2025-03-28 19:13:53 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-28 19:13:53 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:53 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:53 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:53 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:53 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:53 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:53 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:53 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:53 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:53 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:53 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:53 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:53 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:53 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:53 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:53 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:53 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:53 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:53 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:53 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:53 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-28 19:13:53 --> 404 Page Not Found: Images/small
