<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-12-05 09:36:21 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-12-05 09:36:21 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-12-05 09:36:21 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-12-05 09:36:21 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-12-05 09:36:21 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-12-05 09:36:21 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-05 09:36:21 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-05 09:36:21 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-05 09:36:21 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-05 09:36:21 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-05 09:36:21 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-05 09:36:21 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-05 09:36:21 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-05 09:36:21 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-05 09:36:21 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-05 09:36:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-05 09:36:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-05 09:36:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-05 09:36:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-05 09:36:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-05 09:36:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-05 09:36:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-05 09:36:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-05 09:36:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-05 09:36:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-05 09:36:22 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-05 09:36:23 --> 404 Page Not Found: Images/small
ERROR - 2024-12-05 09:36:37 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-05 09:36:37 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-05 09:36:37 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-05 09:36:37 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-05 09:55:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-05 09:55:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-05 09:56:07 --> Severity: Notice --> Undefined index: id_actividad /Applications/MAMP/htdocs/integratic/application/controllers/Actividades.php 99
ERROR - 2024-12-05 09:56:07 --> Query error: Column 'id_actividad' cannot be null - Invalid query: INSERT INTO `repositorio_actividades` (`titulo`, `descripcion`, `archivo`, `nombre_archivo`, `materia`, `id_actividad`) VALUES ('Prueba repo', '<p>Esto es una prueba del repo</p>', '70efdf2ec9b086079795c442636b55fb.jpeg', 'abbi.jpeg', '503', NULL)
ERROR - 2024-12-05 09:56:14 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-05 09:56:14 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-05 09:56:23 --> Severity: Notice --> Undefined index: id_actividad /Applications/MAMP/htdocs/integratic/application/controllers/Actividades.php 99
ERROR - 2024-12-05 09:56:23 --> Query error: Column 'id_actividad' cannot be null - Invalid query: INSERT INTO `repositorio_actividades` (`titulo`, `descripcion`, `archivo`, `nombre_archivo`, `materia`, `id_actividad`) VALUES ('Prueba repo', '<p>Esto es una prueba del repo</p>', '6f4922f45568161a8cdf4ad2299f6d23.jpeg', 'abbi.jpeg', '503', NULL)
ERROR - 2024-12-05 09:58:19 --> Severity: Warning --> mkdir(): File exists /Applications/MAMP/htdocs/integratic/application/controllers/Actividades.php 55
ERROR - 2024-12-05 09:58:25 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-05 09:58:25 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-05 09:58:30 --> Severity: Warning --> mkdir(): File exists /Applications/MAMP/htdocs/integratic/application/controllers/Actividades.php 55
ERROR - 2024-12-05 09:58:30 --> Severity: Warning --> mkdir(): File exists /Applications/MAMP/htdocs/integratic/application/controllers/Actividades.php 56
ERROR - 2024-12-05 10:00:12 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-05 10:00:12 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-05 10:03:02 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-05 10:03:02 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-05 10:05:26 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-05 10:05:26 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-05 10:13:09 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-05 10:13:09 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-05 10:28:37 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-05 10:28:37 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-05 10:36:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-05 10:36:05 --> 404 Page Not Found: Img/iconos
