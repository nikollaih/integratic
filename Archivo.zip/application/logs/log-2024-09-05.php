<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-09-05 09:52:58 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-09-05 09:52:58 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-09-05 09:52:58 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-09-05 09:52:58 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-09-05 09:52:58 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-09-05 09:52:58 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:52:58 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:52:58 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:52:58 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:52:58 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:52:58 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:52:58 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:52:58 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:52:58 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:52:58 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:52:58 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:52:58 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:52:58 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:52:58 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:52:58 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:52:58 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:52:58 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:52:58 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:52:58 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:52:58 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:52:58 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:53:00 --> 404 Page Not Found: Images/small
ERROR - 2024-09-05 09:53:01 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 09:53:01 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 09:53:01 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-09-05 09:53:01 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-09-05 09:53:01 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-09-05 09:53:01 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-09-05 09:53:01 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-09-05 09:53:01 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-09-05 09:53:01 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-09-05 09:53:01 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-09-05 09:53:01 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-09-05 09:53:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:53:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:53:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:53:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:53:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:53:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:53:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:53:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:53:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:53:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:53:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:53:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:53:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:53:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:53:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:53:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:53:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:53:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:53:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:53:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:53:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 09:53:02 --> 404 Page Not Found: Images/small
ERROR - 2024-09-05 09:53:04 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 09:53:04 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 09:53:04 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 09:53:04 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 09:53:06 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 70
ERROR - 2024-09-05 09:54:54 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 85
ERROR - 2024-09-05 09:57:46 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 27
ERROR - 2024-09-05 09:57:46 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 85
ERROR - 2024-09-05 09:59:19 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 27
ERROR - 2024-09-05 09:59:19 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 85
ERROR - 2024-09-05 10:00:13 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 27
ERROR - 2024-09-05 10:00:13 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 85
ERROR - 2024-09-05 10:00:16 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 27
ERROR - 2024-09-05 10:00:16 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 85
ERROR - 2024-09-05 10:03:54 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 85
ERROR - 2024-09-05 10:04:01 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 85
ERROR - 2024-09-05 10:04:27 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 85
ERROR - 2024-09-05 10:04:30 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-09-05 10:04:30 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-09-05 10:04:43 --> Severity: error --> Exception: Cannot use object of type stdClass as array /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 28
ERROR - 2024-09-05 10:04:44 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-09-05 10:06:19 --> Query error: Unknown column 'role' in 'where clause' - Invalid query: SELECT *
FROM `usuarios`
WHERE `role` = 'docente'
AND `estado` = 'ac'
ERROR - 2024-09-05 10:06:34 --> Severity: Notice --> Undefined index: nombre /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 28
ERROR - 2024-09-05 10:06:34 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 85
ERROR - 2024-09-05 10:06:35 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-09-05 10:06:35 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-09-05 10:06:47 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 85
ERROR - 2024-09-05 10:06:48 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-09-05 10:06:48 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-09-05 10:07:03 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 85
ERROR - 2024-09-05 10:07:25 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 85
ERROR - 2024-09-05 10:07:34 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 85
ERROR - 2024-09-05 10:23:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 10:23:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 10:23:32 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-09-05 10:23:32 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-09-05 10:23:32 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-09-05 10:23:32 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-09-05 10:23:32 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-09-05 10:23:32 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-09-05 10:23:32 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-09-05 10:23:32 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-09-05 10:23:32 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-09-05 10:23:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 10:23:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 10:23:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 10:23:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 10:23:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 10:23:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 10:23:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 10:23:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 10:23:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 10:23:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 10:23:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 10:23:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 10:23:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 10:23:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 10:23:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 10:23:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 10:23:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 10:23:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 10:23:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 10:23:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 10:23:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-05 10:23:33 --> 404 Page Not Found: Images/small
ERROR - 2024-09-05 10:23:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 10:23:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 10:23:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 10:23:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 10:26:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 10:26:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 10:27:08 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-09-05 10:27:08 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-09-05 10:30:07 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-09-05 10:30:07 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-09-05 10:30:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 10:30:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 10:30:18 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-09-05 10:30:18 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-09-05 10:31:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 10:31:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 10:31:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 10:31:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 10:56:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 10:56:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 10:56:17 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.cm.codmateria' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT *
FROM `cfg_areas` `ca`
JOIN `cfg_materias` `cm` ON `ca`.`codarea` = `cm`.`area`
JOIN `asg_materias` `am` ON `am`.`materia` = `cm`.`codmateria`
WHERE `am`.`docente` = '12345'
GROUP BY `ca`.`codarea`
ERROR - 2024-09-05 10:56:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 10:56:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 11:18:33 --> Severity: User Error --> Composer detected issues in your platform: Your Composer dependencies require a PHP version ">= 8.0.0". You are running 7.4.33. /Applications/MAMP/htdocs/integratic/vendor/composer/platform_check.php 24
ERROR - 2024-09-05 11:18:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 11:18:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 11:20:07 --> Severity: User Error --> Composer detected issues in your platform: Your Composer dependencies require a PHP version ">= 8.0.0". You are running 7.4.33. /Applications/MAMP/htdocs/integratic/vendor/composer/platform_check.php 24
ERROR - 2024-09-05 11:23:23 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 11:23:23 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 11:23:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 11:23:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 11:23:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-05 11:23:46 --> 404 Page Not Found: Img/iconos
