<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-01-22 14:16:09 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-01-22 14:16:09 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-01-22 14:16:09 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-01-22 14:16:09 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-01-22 14:16:10 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-01-22 14:16:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:16:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:16:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:16:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:16:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:16:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:16:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:16:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:16:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:16:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:16:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:16:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:16:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:16:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:16:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:16:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:16:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:16:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:16:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:16:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:16:10 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:16:11 --> 404 Page Not Found: Images/small
ERROR - 2025-01-22 14:17:36 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:17:36 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:17:36 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:17:36 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:17:40 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.u.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `u`.*, `e`.*, `e`.`email` as `email`, `cer`.`id_pregunta`
FROM `estudiante` `e`
LEFT JOIN `usuarios` `u` ON `e`.`documento` = `u`.`id`
LEFT OUTER JOIN `caracterizacion_estudiantes_respuestas` `cer` ON `cer`.`id_estudiante` = `u`.`id`
GROUP BY `e`.`documento`
ORDER BY `e`.`grado` ASC, `e`.`nombre` ASC
ERROR - 2025-01-22 14:18:00 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:19:36 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:19:54 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:20:10 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:20:23 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:21:12 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:21:18 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:21:25 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-22 14:21:25 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-22 14:22:02 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:22:02 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-22 14:22:02 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-22 14:22:28 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:22:39 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:22:59 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:25:20 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:26:09 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:26:11 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:27:01 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:27:11 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:27:20 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:27:25 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:28:06 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:28:14 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:29:11 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:29:34 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:30:04 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:30:58 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:31:02 --> Severity: Warning --> ZipArchive::getFromName(): Invalid or uninitialized Zip object /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 302
ERROR - 2025-01-22 14:31:02 --> Severity: Warning --> ZipArchive::getFromName(): Invalid or uninitialized Zip object /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 304
ERROR - 2025-01-22 14:31:02 --> Severity: Warning --> ZipArchive::getFromName(): Invalid or uninitialized Zip object /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 302
ERROR - 2025-01-22 14:31:02 --> Severity: Warning --> ZipArchive::getFromName(): Invalid or uninitialized Zip object /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 304
ERROR - 2025-01-22 14:31:02 --> Severity: Notice --> Trying to get property 'Relationship' of non-object /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 341
ERROR - 2025-01-22 14:31:02 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 341
ERROR - 2025-01-22 14:31:02 --> Severity: Warning --> ZipArchive::getFromName(): Invalid or uninitialized Zip object /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 302
ERROR - 2025-01-22 14:31:02 --> Severity: Warning --> ZipArchive::getFromName(): Invalid or uninitialized Zip object /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 304
ERROR - 2025-01-22 14:31:02 --> Severity: Notice --> Trying to get property 'Relationship' of non-object /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 390
ERROR - 2025-01-22 14:31:02 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 390
ERROR - 2025-01-22 14:31:02 --> Severity: Warning --> ZipArchive::getFromName(): Invalid or uninitialized Zip object /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 302
ERROR - 2025-01-22 14:31:02 --> Severity: Warning --> ZipArchive::getFromName(): Invalid or uninitialized Zip object /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 304
ERROR - 2025-01-22 14:31:02 --> Severity: Notice --> Trying to get property 'Default' of non-object /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 1515
ERROR - 2025-01-22 14:31:02 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 1515
ERROR - 2025-01-22 14:31:02 --> Severity: Notice --> Trying to get property 'Override' of non-object /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 1525
ERROR - 2025-01-22 14:31:02 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 1525
ERROR - 2025-01-22 14:31:02 --> Severity: Warning --> ZipArchive::close(): Invalid or uninitialized Zip object /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 1566
ERROR - 2025-01-22 14:31:02 --> Severity: error --> Exception: Your requested sheet index: -1 is out of bounds. The actual number of sheets is 0. /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Spreadsheet.php 686
ERROR - 2025-01-22 14:32:44 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:32:48 --> Severity: Warning --> ZipArchive::getFromName(): Invalid or uninitialized Zip object /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 302
ERROR - 2025-01-22 14:32:48 --> Severity: Warning --> ZipArchive::getFromName(): Invalid or uninitialized Zip object /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 304
ERROR - 2025-01-22 14:32:48 --> Severity: Warning --> ZipArchive::getFromName(): Invalid or uninitialized Zip object /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 302
ERROR - 2025-01-22 14:32:48 --> Severity: Warning --> ZipArchive::getFromName(): Invalid or uninitialized Zip object /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 304
ERROR - 2025-01-22 14:32:48 --> Severity: Notice --> Trying to get property 'Relationship' of non-object /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 341
ERROR - 2025-01-22 14:32:48 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 341
ERROR - 2025-01-22 14:32:48 --> Severity: Warning --> ZipArchive::getFromName(): Invalid or uninitialized Zip object /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 302
ERROR - 2025-01-22 14:32:48 --> Severity: Warning --> ZipArchive::getFromName(): Invalid or uninitialized Zip object /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 304
ERROR - 2025-01-22 14:32:48 --> Severity: Notice --> Trying to get property 'Relationship' of non-object /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 390
ERROR - 2025-01-22 14:32:48 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 390
ERROR - 2025-01-22 14:32:48 --> Severity: Warning --> ZipArchive::getFromName(): Invalid or uninitialized Zip object /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 302
ERROR - 2025-01-22 14:32:48 --> Severity: Warning --> ZipArchive::getFromName(): Invalid or uninitialized Zip object /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 304
ERROR - 2025-01-22 14:32:48 --> Severity: Notice --> Trying to get property 'Default' of non-object /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 1515
ERROR - 2025-01-22 14:32:48 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 1515
ERROR - 2025-01-22 14:32:48 --> Severity: Notice --> Trying to get property 'Override' of non-object /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 1525
ERROR - 2025-01-22 14:32:48 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 1525
ERROR - 2025-01-22 14:32:48 --> Severity: Warning --> ZipArchive::close(): Invalid or uninitialized Zip object /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Reader/Xlsx.php 1566
ERROR - 2025-01-22 14:32:48 --> Severity: error --> Exception: Your requested sheet index: -1 is out of bounds. The actual number of sheets is 0. /Applications/MAMP/htdocs/integratic/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Spreadsheet.php 686
ERROR - 2025-01-22 14:32:51 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:32:52 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:32:56 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:32:58 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:33:16 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:33:38 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:33:40 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-01-22 14:34:17 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-01-22 14:34:17 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-01-22 14:34:17 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-01-22 14:34:17 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-01-22 14:34:17 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-01-22 14:34:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:34:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:34:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:34:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:34:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:34:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:34:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:34:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:34:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:34:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:34:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:34:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:34:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:34:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:34:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:34:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:34:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:34:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:34:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:34:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:34:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:34:18 --> 404 Page Not Found: Images/small
ERROR - 2025-01-22 14:34:32 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-22 14:34:32 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-22 14:34:32 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-22 14:34:32 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-22 14:34:47 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-22 14:34:47 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-22 14:35:06 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-22 14:35:06 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-22 14:36:00 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-22 14:36:00 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-22 14:37:49 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-01-22 14:37:49 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-01-22 14:37:49 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-01-22 14:37:49 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-01-22 14:37:49 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-01-22 14:37:49 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-01-22 14:37:49 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-01-22 14:37:49 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-01-22 14:37:49 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-01-22 14:37:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:37:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:37:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:37:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:37:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:37:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:37:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:37:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:37:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:37:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:37:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:37:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:37:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:37:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:37:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:37:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:37:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:37:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:37:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:37:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:37:49 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:37:50 --> 404 Page Not Found: Images/small
ERROR - 2025-01-22 14:37:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:37:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:37:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:37:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:38:29 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-22 14:38:29 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-22 14:40:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:40:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:40:33 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-22 14:40:33 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-22 14:41:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:41:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-22 14:49:27 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-22 14:49:27 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-22 14:49:50 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-22 14:49:50 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-22 14:51:55 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-22 14:51:55 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-22 14:51:55 --> 404 Page Not Found: Caracterizacion/index.php
ERROR - 2025-01-22 14:52:06 --> 404 Page Not Found: Caracterizacion/index.php
ERROR - 2025-01-22 14:52:24 --> 404 Page Not Found: Caracterizacion/index.php
