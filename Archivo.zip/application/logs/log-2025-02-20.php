<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-02-20 14:15:54 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-20 14:15:54 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-20 14:15:54 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-20 14:15:54 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-20 14:15:54 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-02-20 14:15:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:15:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:15:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:15:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:15:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:15:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:15:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:15:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:15:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:15:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:15:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:15:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:15:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:15:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:15:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:15:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:15:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:15:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:15:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:15:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:15:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:15:57 --> 404 Page Not Found: Images/small
ERROR - 2025-02-20 14:16:07 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-20 14:16:08 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 27
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 45
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: nivel_educativo_madre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 181
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: nivel_educativo_padre /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 196
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: parentesco_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 216
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: nivel_educativo_cuidador /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 230
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-20 14:16:34 --> Severity: Notice --> Undefined index: ultimo_grado_cursado /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 312
ERROR - 2025-02-20 14:19:45 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-20 14:19:47 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-20 14:19:47 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-20 14:19:47 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-20 14:19:47 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-20 14:19:47 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-20 14:19:47 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-20 14:19:47 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-20 14:19:47 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-20 14:19:47 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-02-20 14:19:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:19:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:19:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:19:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:19:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:19:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:19:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:19:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:19:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:19:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:19:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:19:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:19:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:19:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:19:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:19:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:19:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:19:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:19:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:19:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:19:47 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-20 14:19:48 --> 404 Page Not Found: Images/small
ERROR - 2025-02-20 14:19:55 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-20 14:19:55 --> 404 Page Not Found: Img/iconos
