<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-01-31 11:50:10 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-01-31 11:50:10 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-01-31 11:50:10 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-01-31 11:50:10 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-01-31 11:50:10 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-01-31 11:50:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 11:50:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 11:50:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 11:50:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 11:50:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 11:50:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 11:50:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 11:50:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 11:50:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 11:50:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 11:50:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 11:50:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 11:50:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 11:50:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 11:50:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 11:50:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 11:50:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 11:50:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 11:50:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 11:50:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 11:50:11 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 11:50:26 --> 404 Page Not Found: Images/small
ERROR - 2025-01-31 11:50:32 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-31 11:50:32 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-31 11:55:41 --> Severity: Notice --> Undefined index: objetivos /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 173
ERROR - 2025-01-31 11:56:14 --> Severity: Notice --> Undefined index: objetivos /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 176
ERROR - 2025-01-31 12:10:19 --> Severity: Notice --> Undefined index: message /Applications/MAMP/htdocs/integratic/application/controllers/PIAR.php 118
ERROR - 2025-01-31 12:10:32 --> Query error: Duplicate entry '4' for key 'PRIMARY' - Invalid query: INSERT INTO `piar_item` (`id_piar`, `id_piar_item`, `id_materia`, `objetivos`, `barreras`, `ajustes_razonables`, `evaluacion`, `id_docente`) VALUES ('1', '4', '503', '<p>EBC: Analizo las relaciones y propiedades entre las expresiones algebraicas y las gráficas de funciones polinómicas y racionales y de sus derivadas.</p><p>DBA: Encuentra derivadas de funciones, reconoce sus propiedades y las utiliza para resolver problemas. test</p>', '<p><!--[if !supportLists]--><span style=\"mso-fareast-font-family:Arial\"><span style=\"mso-list:Ignore\">❖<span style=\"font:7.0pt \">     </span></span></span><!--[endif]-->Presenta dificultad para participar de forma oral o escrita.</p><p><!--[if !supportLists]--><span style=\"mso-fareast-font-family:Arial\"><span style=\"mso-list:Ignore\">❖<span style=\"font:7.0pt \">     </span></span></span><!--[endif]-->Se le dificulta socializar con sus compañeros de grupo</p><p><span style=\"font-size:10.0pt;font-family:\">* Con gran dificultad relaciona los contenidos del área con su contexto cotidiano.</span></p>', '<p><!--[if !supportLists]--><span style=\"mso-fareast-font-family: Arial\"><span style=\"mso-list:Ignore\">❖<span style=\"font:7.0pt \">     </span></span></span><!--[endif]-->Se le permitirá que resuelva las actividades en el transcurso de la clase.</p><p><!--[if !supportLists]--><span style=\"mso-fareast-font-family: Arial\"><span style=\"mso-list:Ignore\">❖<span style=\"font:7.0pt \">     </span></span></span><!--[endif]-->Su participación y resolución de dudas serán de forma personal con el docente.</p><p><!--[if !supportLists]--><span style=\"mso-fareast-font-family: Arial\"><span style=\"mso-list:Ignore\">❖<span style=\"font:7.0pt \">     </span></span></span><!--[endif]-->Se le flexibiliza las evaluaciones en cantidad y dificultad de ejercicios.</p><p><!--[if !supportLists]--><span style=\"mso-fareast-font-family:Arial\"><span style=\"mso-list:Ignore\">❖<span style=\"font:7.0pt \">     </span></span></span><!--[endif]-->Orientación de dudas durante la resolución de evaluaciones.<span style=\"mso-spacerun:yes\">   </span><span style=\"font-size:8.0pt\"><span style=\"mso-spacerun:yes\">                  </span></span></p>', '<p>​<span style=\"font-size:10.0pt;font-family:\">Cumplió de acuerdo a sus capacidades y ajustes aplicados<span style=\"mso-spacerun:yes\">  </span>con los dba trabajados durante el periodo, logrando tener un avance significativo<span style=\"mso-spacerun:yes\">  </span>de acuerdo a su diagnóstico médico</span>​<br></p>', '12345')
ERROR - 2025-01-31 12:11:14 --> Query error: Duplicate entry '4' for key 'PRIMARY' - Invalid query: INSERT INTO `piar_item` (`id_piar`, `id_piar_item`, `id_materia`, `objetivos`, `barreras`, `ajustes_razonables`, `evaluacion`, `id_docente`) VALUES ('1', '4', '503', '<p>EBC: Analizo las relaciones y propiedades entre las expresiones algebraicas y las gráficas de funciones polinómicas y racionales y de sus derivadas.</p><p>DBA: Encuentra derivadas de funciones, reconoce sus propiedades y las utiliza para resolver problemas. test</p>', '<p><!--[if !supportLists]--><span style=\"mso-fareast-font-family:Arial\"><span style=\"mso-list:Ignore\">❖<span style=\"font:7.0pt \">     </span></span></span><!--[endif]-->Presenta dificultad para participar de forma oral o escrita.</p><p><!--[if !supportLists]--><span style=\"mso-fareast-font-family:Arial\"><span style=\"mso-list:Ignore\">❖<span style=\"font:7.0pt \">     </span></span></span><!--[endif]-->Se le dificulta socializar con sus compañeros de grupo</p><p><span style=\"font-size:10.0pt;font-family:\">* Con gran dificultad relaciona los contenidos del área con su contexto cotidiano.</span></p>', '<p><!--[if !supportLists]--><span style=\"mso-fareast-font-family: Arial\"><span style=\"mso-list:Ignore\">❖<span style=\"font:7.0pt \">     </span></span></span><!--[endif]-->Se le permitirá que resuelva las actividades en el transcurso de la clase.</p><p><!--[if !supportLists]--><span style=\"mso-fareast-font-family: Arial\"><span style=\"mso-list:Ignore\">❖<span style=\"font:7.0pt \">     </span></span></span><!--[endif]-->Su participación y resolución de dudas serán de forma personal con el docente.</p><p><!--[if !supportLists]--><span style=\"mso-fareast-font-family: Arial\"><span style=\"mso-list:Ignore\">❖<span style=\"font:7.0pt \">     </span></span></span><!--[endif]-->Se le flexibiliza las evaluaciones en cantidad y dificultad de ejercicios.</p><p><!--[if !supportLists]--><span style=\"mso-fareast-font-family:Arial\"><span style=\"mso-list:Ignore\">❖<span style=\"font:7.0pt \">     </span></span></span><!--[endif]-->Orientación de dudas durante la resolución de evaluaciones.<span style=\"mso-spacerun:yes\">   </span><span style=\"font-size:8.0pt\"><span style=\"mso-spacerun:yes\">                  </span></span></p>', '<p>​<span style=\"font-size:10.0pt;font-family:\">Cumplió de acuerdo a sus capacidades y ajustes aplicados<span style=\"mso-spacerun:yes\">  </span>con los dba trabajados durante el periodo, logrando tener un avance significativo<span style=\"mso-spacerun:yes\">  </span>de acuerdo a su diagnóstico médico</span>​<br></p>', '12345')
ERROR - 2025-01-31 12:11:28 --> Query error: Duplicate entry '4' for key 'PRIMARY' - Invalid query: INSERT INTO `piar_item` (`id_piar`, `id_piar_item`, `id_materia`, `objetivos`, `barreras`, `ajustes_razonables`, `evaluacion`, `id_docente`) VALUES ('1', '4', '503', '<p>EBC: Analizo las relaciones y propiedades entre las expresiones algebraicas y las gráficas de funciones polinómicas y racionales y de sus derivadas.</p><p>DBA: Encuentra derivadas de funciones, reconoce sus propiedades y las utiliza para resolver problemas. test</p>', '<p><!--[if !supportLists]--><span style=\"mso-fareast-font-family:Arial\"><span style=\"mso-list:Ignore\">❖<span style=\"font:7.0pt \">     </span></span></span><!--[endif]-->Presenta dificultad para participar de forma oral o escrita.</p><p><!--[if !supportLists]--><span style=\"mso-fareast-font-family:Arial\"><span style=\"mso-list:Ignore\">❖<span style=\"font:7.0pt \">     </span></span></span><!--[endif]-->Se le dificulta socializar con sus compañeros de grupo</p><p><span style=\"font-size:10.0pt;font-family:\">* Con gran dificultad relaciona los contenidos del área con su contexto cotidiano.</span></p>', '<p><!--[if !supportLists]--><span style=\"mso-fareast-font-family: Arial\"><span style=\"mso-list:Ignore\">❖<span style=\"font:7.0pt \">     </span></span></span><!--[endif]-->Se le permitirá que resuelva las actividades en el transcurso de la clase.</p><p><!--[if !supportLists]--><span style=\"mso-fareast-font-family: Arial\"><span style=\"mso-list:Ignore\">❖<span style=\"font:7.0pt \">     </span></span></span><!--[endif]-->Su participación y resolución de dudas serán de forma personal con el docente.</p><p><!--[if !supportLists]--><span style=\"mso-fareast-font-family: Arial\"><span style=\"mso-list:Ignore\">❖<span style=\"font:7.0pt \">     </span></span></span><!--[endif]-->Se le flexibiliza las evaluaciones en cantidad y dificultad de ejercicios.</p><p><!--[if !supportLists]--><span style=\"mso-fareast-font-family:Arial\"><span style=\"mso-list:Ignore\">❖<span style=\"font:7.0pt \">     </span></span></span><!--[endif]-->Orientación de dudas durante la resolución de evaluaciones.<span style=\"mso-spacerun:yes\">   </span><span style=\"font-size:8.0pt\"><span style=\"mso-spacerun:yes\">                  </span></span></p>', '<p>​<span style=\"font-size:10.0pt;font-family:\">Cumplió de acuerdo a sus capacidades y ajustes aplicados<span style=\"mso-spacerun:yes\">  </span>con los dba trabajados durante el periodo, logrando tener un avance significativo<span style=\"mso-spacerun:yes\">  </span>de acuerdo a su diagnóstico médico</span>​<br></p>', '12345')
ERROR - 2025-01-31 12:13:20 --> Query error: Unknown column 'id_piar_item' in 'field list' - Invalid query: UPDATE `piar` SET `id_piar` = '1', `id_piar_item` = '4', `id_materia` = '503', `objetivos` = '<p>EBC: Analizo las relaciones y propiedades entre las expresiones algebraicas y las gráficas de funciones polinómicas y racionales y de sus derivadas.</p><p>DBA: Encuentra derivadas de funciones, reconoce sus propiedades y las utiliza para resolver problemas. test</p>', `barreras` = '<p><!--[if !supportLists]--><span style=\"mso-fareast-font-family:Arial\"><span style=\"mso-list:Ignore\">❖<span style=\"font:7.0pt \">     </span></span></span><!--[endif]-->Presenta dificultad para participar de forma oral o escrita.</p><p><!--[if !supportLists]--><span style=\"mso-fareast-font-family:Arial\"><span style=\"mso-list:Ignore\">❖<span style=\"font:7.0pt \">     </span></span></span><!--[endif]-->Se le dificulta socializar con sus compañeros de grupo</p><p><span style=\"font-size:10.0pt;font-family:\">* Con gran dificultad relaciona los contenidos del área con su contexto cotidiano.</span></p>', `ajustes_razonables` = '<p><!--[if !supportLists]--><span style=\"mso-fareast-font-family: Arial\"><span style=\"mso-list:Ignore\">❖<span style=\"font:7.0pt \">     </span></span></span><!--[endif]-->Se le permitirá que resuelva las actividades en el transcurso de la clase.</p><p><!--[if !supportLists]--><span style=\"mso-fareast-font-family: Arial\"><span style=\"mso-list:Ignore\">❖<span style=\"font:7.0pt \">     </span></span></span><!--[endif]-->Su participación y resolución de dudas serán de forma personal con el docente.</p><p><!--[if !supportLists]--><span style=\"mso-fareast-font-family: Arial\"><span style=\"mso-list:Ignore\">❖<span style=\"font:7.0pt \">     </span></span></span><!--[endif]-->Se le flexibiliza las evaluaciones en cantidad y dificultad de ejercicios.</p><p><!--[if !supportLists]--><span style=\"mso-fareast-font-family:Arial\"><span style=\"mso-list:Ignore\">❖<span style=\"font:7.0pt \">     </span></span></span><!--[endif]-->Orientación de dudas durante la resolución de evaluaciones.<span style=\"mso-spacerun:yes\">   </span><span style=\"font-size:8.0pt\"><span style=\"mso-spacerun:yes\">                  </span></span></p>', `evaluacion` = '<p>​<span style=\"font-size:10.0pt;font-family:\">Cumplió de acuerdo a sus capacidades y ajustes aplicados<span style=\"mso-spacerun:yes\">  </span>con los dba trabajados durante el periodo, logrando tener un avance significativo<span style=\"mso-spacerun:yes\">  </span>de acuerdo a su diagnóstico médico</span>​<br></p>', `id_docente` = '12345'
WHERE `id_piar` = '4'
ERROR - 2025-01-31 13:16:23 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 222
ERROR - 2025-01-31 13:16:23 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 222
ERROR - 2025-01-31 13:16:23 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 222
ERROR - 2025-01-31 14:15:51 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-01-31 14:15:51 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-01-31 14:15:56 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-01-31 14:15:56 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-01-31 14:15:56 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-01-31 14:15:56 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-01-31 14:15:57 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-01-31 14:15:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 14:15:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 14:15:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 14:15:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 14:15:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 14:15:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 14:15:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 14:15:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 14:15:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 14:15:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 14:15:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 14:15:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 14:15:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 14:15:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 14:15:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 14:15:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 14:15:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 14:15:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 14:15:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 14:15:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 14:15:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 14:16:02 --> 404 Page Not Found: Images/small
ERROR - 2025-01-31 14:16:15 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-31 14:16:15 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-31 14:27:54 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-31 14:27:54 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-31 14:28:42 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-31 14:28:42 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-31 14:31:07 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-31 14:31:07 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-31 14:33:48 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-31 14:33:48 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-31 14:35:23 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-31 14:35:23 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-31 14:35:43 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-31 14:35:43 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-31 14:36:22 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-31 15:10:30 --> Severity: Compile Error --> Cannot redeclare PIAR::view() /Applications/MAMP/htdocs/integratic/application/controllers/Piar.php 155
ERROR - 2025-01-31 15:10:35 --> Severity: Compile Error --> Cannot redeclare PIAR::view() /Applications/MAMP/htdocs/integratic/application/controllers/Piar.php 155
ERROR - 2025-01-31 15:10:58 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/piar/view.php 19
ERROR - 2025-01-31 15:10:58 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/piar/view.php 20
ERROR - 2025-01-31 15:10:58 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/piar/view.php 21
ERROR - 2025-01-31 15:10:58 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/piar/view.php 22
ERROR - 2025-01-31 15:10:58 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/piar/view.php 23
ERROR - 2025-01-31 15:10:58 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/piar/view.php 26
ERROR - 2025-01-31 15:13:44 --> Severity: Notice --> Undefined property: PIAR::$mpdf /Applications/MAMP/htdocs/integratic/application/controllers/Piar.php 106
ERROR - 2025-01-31 15:13:44 --> Severity: error --> Exception: Call to a member function WriteHTML() on null /Applications/MAMP/htdocs/integratic/application/controllers/Piar.php 106
ERROR - 2025-01-31 16:20:33 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-31 16:20:33 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-31 16:20:33 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-01-31 16:20:33 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-01-31 16:20:33 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-01-31 16:20:33 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-01-31 16:20:33 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-01-31 16:20:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 16:20:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 16:20:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 16:20:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 16:20:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 16:20:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 16:20:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 16:20:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 16:20:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 16:20:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 16:20:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 16:20:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 16:20:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 16:20:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 16:20:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 16:20:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 16:20:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 16:20:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 16:20:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 16:20:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 16:20:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-31 16:20:34 --> 404 Page Not Found: Images/small
ERROR - 2025-01-31 16:20:41 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-31 16:20:42 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-31 16:20:42 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-31 16:20:42 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-31 16:20:48 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-31 16:20:48 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 16
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 16
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index:  /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 16
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: nr /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 16
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 31
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 34
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 37
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 40
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 43
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 32
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: nc /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 32
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 33
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 36
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: va /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 93
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: txta /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 97
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/CssManager.php 1762
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: direction /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 242
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: cellLineHeight /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 258
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: cellLineStackingStrategy /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 263
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: cellLineStackingShift /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 268
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: borders_separate /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 340
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 413
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 414
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 32
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 33
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 36
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: va /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 93
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: txta /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 97
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/CssManager.php 1762
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: direction /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 242
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: cellLineHeight /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 258
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: cellLineStackingStrategy /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 263
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: cellLineStackingShift /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 268
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: borders_separate /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 340
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 413
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 414
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 16
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 31
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 34
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 37
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 40
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 43
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 32
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 36
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: va /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 93
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: txta /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 97
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/CssManager.php 1762
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: direction /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 242
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: cellLineHeight /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 258
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: cellLineStackingStrategy /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 263
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: cellLineStackingShift /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 268
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: borders_separate /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 340
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 413
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 32
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 36
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: va /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 93
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: txta /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 97
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/CssManager.php 1762
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: direction /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 242
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: cellLineHeight /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 258
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: cellLineStackingStrategy /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 263
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: cellLineStackingShift /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 268
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined index: borders_separate /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 340
ERROR - 2025-01-31 16:34:15 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 413
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 16
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 16
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index:  /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 16
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: nr /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 16
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 31
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 34
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 37
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 40
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 43
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 32
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: nc /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 32
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 33
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 36
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: va /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 93
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: txta /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 97
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/CssManager.php 1762
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: direction /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 242
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: cellLineHeight /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 258
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: cellLineStackingStrategy /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 263
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: cellLineStackingShift /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 268
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: borders_separate /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 340
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 413
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 414
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 32
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 33
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 36
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: va /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 93
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: txta /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 97
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/CssManager.php 1762
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: direction /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 242
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: cellLineHeight /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 258
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: cellLineStackingStrategy /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 263
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: cellLineStackingShift /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 268
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: borders_separate /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 340
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 413
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 414
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 16
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 31
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 34
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 37
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 40
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Tr.php 43
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 32
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 36
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: va /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 93
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: txta /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 97
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/CssManager.php 1762
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: direction /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 242
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: cellLineHeight /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 258
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: cellLineStackingStrategy /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 263
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: cellLineStackingShift /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 268
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: borders_separate /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 340
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 413
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 32
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 36
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: va /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 93
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: txta /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 97
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/CssManager.php 1762
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: direction /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 242
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: cellLineHeight /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 258
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: cellLineStackingStrategy /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 263
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: cellLineStackingShift /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 268
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined index: borders_separate /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 340
ERROR - 2025-01-31 16:34:18 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/integratic/vendor/mpdf/mpdf/src/Tag/Td.php 413
