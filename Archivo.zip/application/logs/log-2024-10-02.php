<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-10-02 09:40:37 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-10-02 09:40:37 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-10-02 09:40:37 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-10-02 09:40:37 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-10-02 09:40:37 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-10-02 09:40:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:38 --> 404 Page Not Found: Images/small
ERROR - 2024-10-02 09:40:46 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-10-02 09:40:46 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-10-02 09:40:46 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-10-02 09:40:46 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-10-02 09:40:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 09:40:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 09:40:46 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-10-02 09:40:46 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-10-02 09:40:46 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-10-02 09:40:46 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-10-02 09:40:46 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-10-02 09:40:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:46 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-02 09:40:48 --> 404 Page Not Found: Images/small
ERROR - 2024-10-02 09:40:56 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 09:40:56 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 09:40:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 09:40:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 09:40:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 09:40:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 09:41:01 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 09:41:01 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 09:43:13 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 09:43:13 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 09:43:18 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.am.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT *
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE `am`.`docente` = '12345'
GROUP BY `am`.`materia`
ERROR - 2024-10-02 09:44:55 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2024-10-02 09:47:23 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2024-10-02 09:47:37 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2024-10-02 09:48:29 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2024-10-02 09:48:44 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2024-10-02 09:49:07 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2024-10-02 09:50:00 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2024-10-02 09:50:10 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-02 09:50:10 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-02 09:50:47 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-02 09:50:47 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-02 09:50:47 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2024-10-02 09:52:53 --> Severity: Notice --> Undefined index: id_prueba /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 80
ERROR - 2024-10-02 09:52:53 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2024-10-02 09:53:00 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-02 09:53:00 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-02 09:53:36 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2024-10-02 09:55:02 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 09:55:02 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 09:55:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 09:55:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 09:55:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 09:55:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 09:58:10 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`integratic`.`recuperaciones_actividades`, CONSTRAINT `recuperacion_actividad` FOREIGN KEY (`id_actividad`) REFERENCES `actividades` (`id_actividad`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: INSERT INTO `recuperaciones_actividades` (`id_recuperacion`, `id_actividad`) VALUES ('2', '')
ERROR - 2024-10-02 09:58:16 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`integratic`.`recuperaciones_actividades`, CONSTRAINT `recuperacion_actividad` FOREIGN KEY (`id_actividad`) REFERENCES `actividades` (`id_actividad`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: INSERT INTO `recuperaciones_actividades` (`id_recuperacion`, `id_actividad`) VALUES ('2', '')
ERROR - 2024-10-02 09:58:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 09:58:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 09:58:51 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 09:58:51 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 09:58:57 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`integratic`.`recuperaciones_actividades`, CONSTRAINT `recuperacion_actividad` FOREIGN KEY (`id_actividad`) REFERENCES `actividades` (`id_actividad`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: INSERT INTO `recuperaciones_actividades` (`id_recuperacion`, `id_actividad`) VALUES ('2', '- Seleccionar')
ERROR - 2024-10-02 09:59:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 09:59:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 09:59:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 09:59:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:00:54 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:00:54 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:01:10 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:01:10 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:06:29 --> Query error: Unknown column 'p.materia' in 'where clause' - Invalid query: SELECT `p`.*
FROM `pruebas` `p`
WHERE `p`.`estado` != 2
AND  `p`.`materia` LIKE '%502%' ESCAPE '!'
ORDER BY `p`.`created_at` DESC
ERROR - 2024-10-02 10:06:43 --> Severity: Notice --> Undefined index: id_actividad /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 23
ERROR - 2024-10-02 10:06:43 --> Severity: Notice --> Undefined index: titulo_actividad /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 23
ERROR - 2024-10-02 10:06:43 --> Severity: Notice --> Undefined index: id_actividad /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 23
ERROR - 2024-10-02 10:06:43 --> Severity: Notice --> Undefined index: titulo_actividad /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 23
ERROR - 2024-10-02 10:06:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:06:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:07:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:07:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:14:12 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:14:12 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:14:19 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:14:19 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:16:10 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:16:10 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:19:43 --> Query error: Unknown table 'pruebas' - Invalid query: SELECT `recuperaciones`.*, `pruebas`.*
FROM `recuperaciones`
JOIN `recuperaciones_pruebas` ON `recuperaciones`.`id_recuperacion` = `recuperaciones_pruebas`.`id_recuperacion`
JOIN `actividades` ON `recuperaciones_pruebas`.`id_prueba` = `actividades`.`id_prueba`
WHERE `recuperaciones`.`id_recuperacion` = '2'
ERROR - 2024-10-02 10:22:33 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:22:33 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:22:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:22:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:22:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:22:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:23:07 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-02 10:23:07 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-02 10:24:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:24:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:24:27 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-02 10:24:27 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-02 10:24:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:24:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:25:06 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:25:06 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:36:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:36:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:36:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:36:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:36:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:36:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:36:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:36:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:37:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:37:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:37:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:37:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:37:17 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:37:17 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:37:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:37:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:37:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:37:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:38:08 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:38:08 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:38:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:38:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:38:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:38:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:39:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:39:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:47:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:47:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:47:28 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:47:28 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:47:54 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-02 10:47:54 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-02 10:47:56 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:47:56 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:47:56 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-02 10:47:56 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-02 10:48:09 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:48:09 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:48:09 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-02 10:48:10 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-02 10:48:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:48:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:48:27 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-02 10:48:27 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-02 10:49:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:49:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:49:43 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-02 10:49:43 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-02 10:50:12 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:50:12 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:50:12 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-02 10:50:12 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-02 10:57:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:57:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:57:47 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-02 10:57:47 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-02 10:58:24 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:58:24 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-02 10:58:24 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:58:24 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-02 10:58:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:58:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:58:31 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-02 10:58:32 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-02 10:59:13 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:59:13 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:59:13 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-02 10:59:13 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-02 10:59:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:59:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 10:59:45 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-02 10:59:46 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-02 10:59:50 --> Severity: Warning --> Use of undefined constant RecuperacionPruebas_Model - assumed 'RecuperacionPruebas_Model' (this will throw an Error in a future version of PHP) /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 143
ERROR - 2024-10-02 10:59:50 --> Severity: error --> Exception: Call to a member function delete() on string /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 147
ERROR - 2024-10-02 11:00:38 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 11:00:38 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 11:00:38 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-02 11:00:38 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-02 11:00:44 --> Severity: Notice --> Undefined index: id_recuperacion /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 147
ERROR - 2024-10-02 11:00:44 --> Severity: Notice --> Undefined index: id_fk /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 147
ERROR - 2024-10-02 11:01:12 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 11:01:12 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 11:01:12 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-02 11:01:13 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-02 11:01:16 --> Severity: Notice --> Undefined index: id_recuperacion /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 148
ERROR - 2024-10-02 11:01:16 --> Severity: Notice --> Undefined index: id_fk /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 148
ERROR - 2024-10-02 11:02:28 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 11:02:28 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 11:02:28 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-02 11:02:28 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-02 11:02:31 --> Severity: Notice --> Undefined index: id_recuperacion /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 149
ERROR - 2024-10-02 11:02:31 --> Severity: Notice --> Undefined index: id_fk /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 149
ERROR - 2024-10-02 11:25:10 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 11:25:10 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 11:25:10 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-02 11:25:10 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-02 11:25:14 --> Severity: Notice --> Undefined index: id_recuperacion /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 149
ERROR - 2024-10-02 11:25:14 --> Severity: Notice --> Undefined index: id_fk /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 149
ERROR - 2024-10-02 11:26:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 11:26:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 11:26:07 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-02 11:26:07 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-02 11:26:32 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 11:26:32 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 11:26:35 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 11:26:35 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 11:26:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 11:26:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 11:26:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 11:26:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 11:26:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 11:26:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 11:27:01 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 11:27:01 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 11:27:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-02 11:27:07 --> 404 Page Not Found: Img/iconos
