<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-08-05 11:37:21 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `plan_areas` (`id_plan_area`, `area`, `materia`, `periodo`, `fecha_inicio`, `fecha_fin`, `intensidad_horaria`, `diagnostico`, `estado_actual`, `situacion_deseada`, `observaciones`, `pactos_clase`, `dbas`, `estandares_basicos`, `created_by`) VALUES ('null', '196', '502', '1', '2024-08-05', '2024-08-31', '2', '<p><br></p>', '<p><br></p>', '<p><br></p>', '<p><br></p>', '<p><br></p>', 'a:0:{}', 'a:0:{}', '12345')
ERROR - 2024-08-05 11:39:02 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `plan_areas` (`id_plan_area`, `area`, `materia`, `periodo`, `fecha_inicio`, `fecha_fin`, `intensidad_horaria`, `diagnostico`, `estado_actual`, `situacion_deseada`, `observaciones`, `pactos_clase`, `dbas`, `estandares_basicos`, `created_by`) VALUES ('null', '196', '502', '1', '2024-08-05', '2024-08-31', '2', '<p><br></p>', '<p><br></p>', '<p><br></p>', '<p><br></p>', '<p><br></p>', 'a:0:{}', 'a:0:{}', '12345')
ERROR - 2024-08-05 11:39:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-05 11:39:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-05 11:39:53 --> 404 Page Not Found: PlanAula/index.php
ERROR - 2024-08-05 11:40:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-05 11:40:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-05 11:40:47 --> 404 Page Not Found: PlanAula/index.php
ERROR - 2024-08-05 11:41:01 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `plan_areas` (`id_plan_area`, `area`, `materia`, `periodo`, `fecha_inicio`, `fecha_fin`, `intensidad_horaria`, `diagnostico`, `estado_actual`, `situacion_deseada`, `observaciones`, `pactos_clase`, `estandares_basicos`, `dbas`, `created_by`) VALUES ('null', '196', '502', '1', '2024-08-05', '2024-08-31', '2', '<p>​<span style=\"color: rgb(0, 0, 0); font-family: \"Open Sans\", Arial, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; white-space: normal; background-color: rgb(255, 255, 255); text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi aliquam volutpat leo, sed hendrerit quam accumsan vel. In varius, erat vitae accumsan gravida, libero leo consequat diam, at aliquet orci mauris at urna. Vivamus facilisis orci sem, at blandit mauris maximus eu. Praesent lacinia ultricies purus, in lobortis velit dapibus non. Pellentesque ac mauris quis quam faucibus suscipit nec ut massa. Maecenas tincidunt lacus in neque sagittis, a mollis orci maximus. Cras scelerisque, metus et facilisis semper, elit ex ultricies dui, et rutrum eros lorem sit amet magna. Donec fringilla, ligula et commodo posuere, massa dui condimentum erat, ut accumsan neque nibh non purus. Pellentesque in tellus sodales, condimentum quam imperdiet, feugiat odio. Ut ultricies consectetur nunc, in rhoncus enim sodales nec.</span>​<br></p>', '<p>​<span style=\"color: rgb(0, 0, 0); font-family: \"Open Sans\", Arial, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; white-space: normal; background-color: rgb(255, 255, 255); text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi aliquam volutpat leo, sed hendrerit quam accumsan vel. In varius, erat vitae accumsan gravida, libero leo consequat diam, at aliquet orci mauris at urna. Vivamus facilisis orci sem, at blandit mauris maximus eu. Praesent lacinia ultricies purus, in lobortis velit dapibus non. Pellentesque ac mauris quis quam faucibus suscipit nec ut massa. Maecenas tincidunt lacus in neque sagittis, a mollis orci maximus. Cras scelerisque, metus et facilisis semper, elit ex ultricies dui, et rutrum eros lorem sit amet magna. Donec fringilla, ligula et commodo posuere, massa dui condimentum erat, ut accumsan neque nibh non purus. Pellentesque in tellus sodales, condimentum quam imperdiet, feugiat odio. Ut ultricies consectetur nunc, in rhoncus enim sodales nec.</span>​<br></p>', '<p>​<span style=\"color: rgb(0, 0, 0); font-family: \"Open Sans\", Arial, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; white-space: normal; background-color: rgb(255, 255, 255); text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi aliquam volutpat leo, sed hendrerit quam accumsan vel. In varius, erat vitae accumsan gravida, libero leo consequat diam, at aliquet orci mauris at urna. Vivamus facilisis orci sem, at blandit mauris maximus eu. Praesent lacinia ultricies purus, in lobortis velit dapibus non. Pellentesque ac mauris quis quam faucibus suscipit nec ut massa. Maecenas tincidunt lacus in neque sagittis, a mollis orci maximus. Cras scelerisque, metus et facilisis semper, elit ex ultricies dui, et rutrum eros lorem sit amet magna. Donec fringilla, ligula et commodo posuere, massa dui condimentum erat, ut accumsan neque nibh non purus. Pellentesque in tellus sodales, condimentum quam imperdiet, feugiat odio. Ut ultricies consectetur nunc, in rhoncus enim sodales nec.</span>​<br></p>', '<p>​<span style=\"color: rgb(0, 0, 0); font-family: \"Open Sans\", Arial, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; white-space: normal; background-color: rgb(255, 255, 255); text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi aliquam volutpat leo, sed hendrerit quam accumsan vel. In varius, erat vitae accumsan gravida, libero leo consequat diam, at aliquet orci mauris at urna. Vivamus facilisis orci sem, at blandit mauris maximus eu. Praesent lacinia ultricies purus, in lobortis velit dapibus non. Pellentesque ac mauris quis quam faucibus suscipit nec ut massa. Maecenas tincidunt lacus in neque sagittis, a mollis orci maximus. Cras scelerisque, metus et facilisis semper, elit ex ultricies dui, et rutrum eros lorem sit amet magna. Donec fringilla, ligula et commodo posuere, massa dui condimentum erat, ut accumsan neque nibh non purus. Pellentesque in tellus sodales, condimentum quam imperdiet, feugiat odio. Ut ultricies consectetur nunc, in rhoncus enim sodales nec.</span>​<br></p>', '<p>​<span style=\"color: rgb(0, 0, 0); font-family: \"Open Sans\", Arial, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; white-space: normal; background-color: rgb(255, 255, 255); text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi aliquam volutpat leo, sed hendrerit quam accumsan vel. In varius, erat vitae accumsan gravida, libero leo consequat diam, at aliquet orci mauris at urna. Vivamus facilisis orci sem, at blandit mauris maximus eu. Praesent lacinia ultricies purus, in lobortis velit dapibus non. Pellentesque ac mauris quis quam faucibus suscipit nec ut massa. Maecenas tincidunt lacus in neque sagittis, a mollis orci maximus. Cras scelerisque, metus et facilisis semper, elit ex ultricies dui, et rutrum eros lorem sit amet magna. Donec fringilla, ligula et commodo posuere, massa dui condimentum erat, ut accumsan neque nibh non purus. Pellentesque in tellus sodales, condimentum quam imperdiet, feugiat odio. Ut ultricies consectetur nunc, in rhoncus enim sodales nec.</span>​<br></p>', 'a:3:{i:0;s:3:\"777\";i:1;s:3:\"757\";i:2;s:3:\"758\";}', 'a:2:{i:0;s:2:\"56\";i:1;s:2:\"58\";}', '12345')
ERROR - 2024-08-05 11:41:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-05 11:41:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-05 11:41:21 --> 404 Page Not Found: PlanAula/index.php
ERROR - 2024-08-05 11:41:24 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-05 11:41:24 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-05 11:41:36 --> Severity: Notice --> Undefined index: id_periodo /Applications/MAMP/htdocs/integratic/application/controllers/PlanAula.php 77
ERROR - 2024-08-05 11:41:36 --> Severity: Notice --> Undefined index: id_periodo /Applications/MAMP/htdocs/integratic/application/views/plan_aula/create.php 89
ERROR - 2024-08-05 11:41:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-05 11:41:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-05 11:42:43 --> Severity: Notice --> Undefined index: id_periodo /Applications/MAMP/htdocs/integratic/application/views/plan_aula/create.php 89
ERROR - 2024-08-05 11:42:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-05 11:42:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-05 11:43:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-05 11:43:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-05 11:44:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-05 11:44:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-05 11:44:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-05 11:44:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-05 11:44:28 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-05 11:44:28 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-05 11:44:28 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-05 11:44:28 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-05 11:44:28 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-05 11:44:28 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-05 11:44:28 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-05 11:44:28 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-05 11:44:28 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-08-05 11:44:28 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-05 11:44:28 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-05 11:44:28 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-05 11:44:28 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-05 11:44:28 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-05 11:44:28 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-05 11:44:28 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-05 11:44:28 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-05 11:44:28 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-05 11:44:28 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-05 11:44:28 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-05 11:44:28 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-05 11:44:28 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-05 11:44:28 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-05 11:44:28 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-05 11:44:28 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-05 11:44:28 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-05 11:44:28 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-05 11:44:28 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-05 11:44:28 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-05 11:44:28 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-05 11:44:29 --> 404 Page Not Found: Images/small
ERROR - 2024-08-05 11:44:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-05 11:44:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-05 11:44:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-05 11:44:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-05 11:44:32 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 70
ERROR - 2024-08-05 11:49:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-05 11:49:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-05 12:15:21 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-05 12:15:21 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-05 12:24:43 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-05 12:24:43 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-05 12:25:52 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 70
ERROR - 2024-08-05 12:25:57 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-05 12:25:57 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-05 12:26:33 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-05 12:26:33 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-05 12:26:49 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-05 12:26:50 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-05 12:33:55 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-05 12:33:55 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-05 12:34:14 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-05 12:34:14 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-05 12:35:06 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-05 12:35:06 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-05 12:35:39 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-05 12:35:39 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-05 12:36:17 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-05 12:36:17 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-05 12:36:27 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-05 12:36:27 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-05 12:37:44 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-05 12:37:44 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-05 13:09:52 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-05 13:09:52 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-05 13:09:58 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-05 13:09:58 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-05 13:10:57 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-05 13:10:57 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-08-05 13:12:20 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-08-05 13:12:20 --> 404 Page Not Found: Js/chart.umd.js.map
