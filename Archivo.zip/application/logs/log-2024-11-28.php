<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-11-28 08:59:46 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-28 08:59:46 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-28 08:59:46 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-28 08:59:46 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-28 08:59:47 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-11-28 08:59:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 08:59:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 08:59:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 08:59:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 08:59:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 08:59:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 08:59:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 08:59:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 08:59:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 08:59:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 08:59:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 08:59:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 08:59:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 08:59:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 08:59:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 08:59:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 08:59:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 08:59:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 08:59:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 08:59:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 08:59:47 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:01:06 --> 404 Page Not Found: Images/small
ERROR - 2024-11-28 09:01:19 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:01:19 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:01:19 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:01:19 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:01:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:01:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:01:22 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:01:22 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:01:25 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:01:25 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:01:25 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:01:25 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:01:25 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:01:25 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:01:25 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:01:25 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:01:25 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:01:25 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:01:25 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:01:25 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:01:25 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:01:25 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:01:25 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:01:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:01:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:01:25 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:01:25 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:01:25 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:01:25 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:01:25 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:01:25 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:01:25 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:01:25 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:01:25 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:01:25 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:01:25 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:01:25 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:01:25 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:01:25 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:01:25 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:06:49 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:06:49 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:06:49 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:06:49 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:06:49 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:06:50 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:06:50 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:06:50 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:06:50 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:06:50 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:06:50 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:06:50 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:06:50 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:06:50 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:06:50 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:06:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:06:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:06:50 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:06:50 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:06:50 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:06:50 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:06:50 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:06:50 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:06:50 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:06:50 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:06:50 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:06:50 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:06:50 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:06:50 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:06:50 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:06:50 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:06:50 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:16:05 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:16:05 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:16:05 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:16:05 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:16:05 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:16:05 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:16:05 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:16:05 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:16:05 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:16:05 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:16:05 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:16:05 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:16:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:16:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:16:06 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:16:06 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:16:06 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:16:06 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:16:06 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:16:06 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:16:06 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:16:06 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:16:06 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:16:06 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:16:06 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:16:06 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:16:33 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:16:33 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:16:33 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:16:33 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:16:33 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:16:33 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:16:33 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:16:33 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:16:33 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:16:33 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:16:33 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:16:33 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:16:33 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:16:33 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:16:33 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:16:33 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:16:33 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:16:33 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:16:33 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:16:33 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:16:33 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:16:33 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:16:33 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:16:33 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:16:33 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:16:33 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:16:33 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:16:33 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:16:33 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:16:33 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:16:33 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:16:33 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:16:57 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:16:57 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:16:57 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:16:57 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:16:57 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:16:57 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:16:57 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:16:57 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:16:57 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:16:57 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:16:57 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:16:57 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:16:57 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:16:57 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:16:57 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:16:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:16:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:16:57 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:16:57 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:16:57 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:16:57 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:16:57 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:16:57 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:16:57 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:16:57 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:16:57 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:16:57 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:16:57 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:16:57 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:16:57 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:16:57 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:16:57 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:17:11 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-11-28 09:17:11 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-11-28 09:17:22 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:17:22 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:17:22 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:17:22 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:17:22 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:17:22 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:17:22 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:17:22 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:17:22 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:17:22 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:17:22 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:17:22 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:17:22 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:17:22 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:17:22 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:17:22 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:17:22 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:17:23 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:17:23 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:17:23 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:17:23 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:17:23 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:17:23 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:17:23 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:17:23 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:17:23 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:17:23 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:17:23 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:17:23 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:17:23 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:17:23 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:17:23 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:17:23 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-11-28 09:17:23 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-11-28 09:17:56 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:17:56 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:17:56 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:17:56 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:17:56 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:17:56 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:17:56 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:17:56 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:17:56 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:17:56 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:17:56 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:17:56 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:17:56 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:17:56 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:17:56 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:17:56 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:17:56 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:17:56 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:17:56 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:17:56 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:17:56 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:17:56 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:17:56 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:17:56 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:17:56 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:17:56 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:17:56 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:17:56 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:17:56 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:17:56 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:17:56 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:17:56 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:18:03 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:18:03 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:18:03 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:18:03 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:18:03 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:18:03 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:18:03 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:18:03 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:18:03 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:18:03 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:18:03 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:18:03 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:18:03 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:18:03 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:18:03 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:18:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:18:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:18:03 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:18:03 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:18:03 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:18:03 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:18:03 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:18:03 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:18:03 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:18:03 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:18:03 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:18:03 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:18:03 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:18:03 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:18:03 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:18:03 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:18:03 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:18:16 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:18:16 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:18:16 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:18:16 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:18:16 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:18:16 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:18:16 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:18:16 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:18:16 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:18:16 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:18:16 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:18:16 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:18:16 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:18:16 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:18:16 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:18:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:18:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:18:17 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:18:17 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:18:17 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:18:17 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:18:17 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:18:17 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:18:17 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:18:17 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:18:17 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:18:17 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:18:17 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:18:17 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:18:17 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:18:17 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:18:17 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:28:18 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:28:18 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:28:18 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:28:18 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:28:18 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:28:18 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:28:18 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:28:18 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:28:18 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:28:18 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:28:18 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:28:18 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:28:18 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:28:18 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:28:18 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:28:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:28:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:28:18 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:28:18 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:28:18 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:28:18 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:28:18 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:28:18 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:28:18 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:28:18 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:28:18 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:28:18 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:28:18 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:28:18 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:28:18 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:28:18 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:28:18 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:29:46 --> Severity: Notice --> Undefined index: observaciones /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 120
ERROR - 2024-11-28 09:29:46 --> Severity: Notice --> Undefined index: id_recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:29:46 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:29:46 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:29:46 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:29:46 --> Severity: Notice --> Undefined index: id_recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:29:46 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:29:46 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:29:46 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:29:46 --> Severity: Notice --> Undefined index: id_recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:29:46 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:29:46 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:29:46 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:29:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:29:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:29:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 120
ERROR - 2024-11-28 09:29:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:29:46 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:29:46 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:29:46 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:29:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:29:46 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:29:46 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:29:46 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:29:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:29:46 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:29:46 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:29:46 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:30:09 --> Severity: Notice --> Undefined index: observaciones /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 121
ERROR - 2024-11-28 09:30:09 --> Severity: Notice --> Undefined index: id_recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:30:09 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:30:09 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:30:09 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:30:09 --> Severity: Notice --> Undefined index: id_recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:30:09 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:30:09 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:30:09 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:30:09 --> Severity: Notice --> Undefined index: id_recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:30:09 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:30:09 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:30:09 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:30:09 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:30:09 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:30:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 121
ERROR - 2024-11-28 09:30:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:30:09 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:30:09 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:30:09 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:30:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:30:09 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:30:09 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:30:09 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:30:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:30:09 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:30:09 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:30:09 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:32:19 --> Severity: Notice --> Undefined index: observaciones /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 121
ERROR - 2024-11-28 09:32:19 --> Severity: Notice --> Undefined index: id_recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:32:19 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:32:19 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:32:19 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:32:19 --> Severity: Notice --> Undefined index: id_recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:32:19 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:32:19 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:32:19 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:32:19 --> Severity: Notice --> Undefined index: id_recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:32:19 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:32:19 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:32:19 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:32:19 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:32:19 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:32:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 121
ERROR - 2024-11-28 09:32:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:32:19 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:32:19 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:32:19 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:32:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:32:19 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:32:19 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:32:19 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:32:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:32:19 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:32:19 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:32:19 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:32:53 --> Severity: Notice --> Undefined index: nombres /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:32:53 --> Severity: Notice --> Undefined index: apellidos /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:32:53 --> Severity: Notice --> Undefined index: grado /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:32:53 --> Severity: Notice --> Undefined index: observaciones /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 121
ERROR - 2024-11-28 09:32:53 --> Severity: Notice --> Undefined index: id_recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:32:53 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:32:53 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:32:53 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:32:53 --> Severity: Notice --> Undefined index: id_recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:32:53 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:32:53 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:32:53 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:32:53 --> Severity: Notice --> Undefined index: id_recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:32:53 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:32:53 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:32:53 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:32:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:32:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:32:53 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:32:53 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:32:53 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:32:53 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 121
ERROR - 2024-11-28 09:32:53 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:32:53 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:32:53 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:32:53 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:32:53 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:32:53 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:32:53 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:32:53 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:32:53 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:32:53 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:32:53 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:32:53 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:33:13 --> Severity: Notice --> Undefined index: nombre /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:33:13 --> Severity: Notice --> Undefined index: grado /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:33:13 --> Severity: Notice --> Undefined index: observaciones /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 121
ERROR - 2024-11-28 09:33:13 --> Severity: Notice --> Undefined index: id_recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:33:13 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:33:13 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:33:13 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:33:13 --> Severity: Notice --> Undefined index: id_recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:33:13 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:33:13 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:33:13 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:33:13 --> Severity: Notice --> Undefined index: id_recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:33:13 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:33:13 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:33:13 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:33:13 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:33:13 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:33:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:33:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:33:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 121
ERROR - 2024-11-28 09:33:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:33:13 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:33:13 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:33:13 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:33:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:33:13 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:33:13 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:33:13 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:33:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:33:13 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:33:13 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:33:13 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:33:30 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:33:30 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:33:30 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:33:30 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:33:30 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:33:30 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:33:30 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:33:30 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:33:30 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:33:30 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:33:30 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:33:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:33:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:33:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 121
ERROR - 2024-11-28 09:33:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:33:30 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:33:30 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:33:30 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:33:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:33:30 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:33:30 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:33:30 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:33:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:33:30 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:33:30 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:33:30 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:33:38 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:33:38 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:33:38 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:33:38 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:33:38 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:33:38 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:33:38 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:33:38 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:33:38 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:33:38 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:33:38 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:33:38 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:33:38 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:33:38 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 121
ERROR - 2024-11-28 09:33:38 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:33:38 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:33:38 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:33:38 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:33:38 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:33:38 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:33:38 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:33:38 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:33:38 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:33:38 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:33:38 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:33:38 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:33:45 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:33:45 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:33:45 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:33:45 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:33:45 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:33:45 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:33:45 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:33:45 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:33:45 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:33:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:33:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:33:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:33:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:33:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 121
ERROR - 2024-11-28 09:33:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:33:45 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:33:45 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:33:45 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:33:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:33:45 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:33:45 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:33:45 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:33:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:33:45 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:33:45 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:33:45 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:34:01 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:34:01 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:34:01 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:34:01 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:34:01 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:34:01 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:34:01 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:34:01 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:34:01 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:34:01 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:34:01 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:34:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:34:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:34:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 120
ERROR - 2024-11-28 09:34:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:34:01 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:34:01 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:34:01 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:34:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:34:01 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:34:01 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:34:01 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:34:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:34:01 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:34:01 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:34:01 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:34:06 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:34:06 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:34:06 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:34:06 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:34:06 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:34:06 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:34:06 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:34:06 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:34:06 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:34:06 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:34:06 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:34:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:34:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:34:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 120
ERROR - 2024-11-28 09:34:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:34:06 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:34:06 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:34:06 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:34:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:34:06 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:34:06 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:34:06 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:34:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:34:06 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:34:06 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:34:06 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:34:20 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:34:20 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:34:20 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:34:20 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:34:20 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:34:20 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:34:20 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:34:20 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:34:20 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:34:20 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:34:20 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:34:20 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 120
ERROR - 2024-11-28 09:34:20 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:34:20 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:34:20 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:34:20 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:34:20 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:34:20 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:34:20 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:34:20 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:34:20 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:34:20 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:34:20 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:34:20 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:34:22 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:34:22 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:34:22 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:34:22 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:34:22 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:34:22 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:34:22 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:34:22 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:34:22 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:34:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:34:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:34:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 120
ERROR - 2024-11-28 09:34:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:34:22 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:34:22 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:34:22 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:34:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:34:22 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:34:22 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:34:22 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:34:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:34:22 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:34:22 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:34:22 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:34:23 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:34:23 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:34:23 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:34:23 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:34:23 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:34:23 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:34:23 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:34:23 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:34:23 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:34:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:34:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:34:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 120
ERROR - 2024-11-28 09:34:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:34:23 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:34:23 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:34:23 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:34:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:34:23 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:34:23 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:34:23 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:34:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:34:23 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:34:23 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:34:23 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:34:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:34:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:34:32 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:34:32 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:36:03 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:36:03 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:36:03 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:36:03 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:36:03 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:36:03 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:36:03 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:36:03 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:36:03 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:36:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:36:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:36:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:36:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:36:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 120
ERROR - 2024-11-28 09:36:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:36:03 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:36:03 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:36:03 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:36:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:36:03 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:36:03 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:36:03 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:36:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:36:03 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:36:03 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:36:03 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:36:05 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:36:05 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:36:05 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:36:05 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:36:05 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:36:05 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:36:05 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:36:05 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:36:05 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:36:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:36:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:36:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:36:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:36:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 120
ERROR - 2024-11-28 09:36:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:36:06 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:36:06 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:36:06 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:36:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:36:06 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:36:06 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:36:06 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:36:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:36:06 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:36:06 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:36:06 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:36:24 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:36:24 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:36:24 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:36:24 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:36:24 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:36:24 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:36:24 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:36:24 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:36:24 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:36:24 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:36:24 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:36:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:36:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:36:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 133
ERROR - 2024-11-28 09:36:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:36:25 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:36:25 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:36:25 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:36:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:36:25 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:36:25 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:36:25 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:36:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:36:25 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:36:25 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:36:25 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:36:35 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:36:35 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:36:35 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:36:35 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:36:35 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:36:35 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:36:35 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:36:35 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:36:35 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:36:35 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:36:35 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:36:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:36:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:36:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 133
ERROR - 2024-11-28 09:36:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:36:36 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:36:36 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:36:36 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:36:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:36:36 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:36:36 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:36:36 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:36:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:36:36 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:36:36 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:36:36 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:38:32 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:38:32 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:38:35 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:38:35 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:38:37 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:38:37 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:38:37 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:38:37 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:38:37 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:38:37 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:38:37 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:38:37 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:38:37 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:38:37 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:38:37 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:38:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:38:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:38:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 150
ERROR - 2024-11-28 09:38:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:38:37 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:38:37 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:38:37 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:38:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:38:37 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:38:37 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:38:37 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:38:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:38:37 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:38:37 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:38:37 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:38:43 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:38:43 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:38:43 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:38:43 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:38:43 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:38:43 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:38:43 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:38:43 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:38:43 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:38:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:38:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:38:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:38:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:38:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 150
ERROR - 2024-11-28 09:38:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:38:43 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:38:43 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:38:43 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:38:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:38:43 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:38:43 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:38:43 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:38:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:38:43 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:38:43 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:38:43 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:38:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:38:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:38:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:38:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:38:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:38:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:38:52 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:38:52 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:38:52 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:38:52 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:38:52 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:38:52 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:38:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:38:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:38:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:38:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:38:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 150
ERROR - 2024-11-28 09:38:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:38:52 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:38:52 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:38:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:38:52 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:38:52 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:38:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:38:52 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:38:52 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:39:17 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:39:17 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:39:17 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:39:17 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:39:17 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:39:17 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:39:17 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:39:17 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:39:17 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:39:17 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:39:17 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:39:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:39:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:39:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 150
ERROR - 2024-11-28 09:39:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:39:17 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:39:17 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:39:17 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:39:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:39:17 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:39:17 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:39:17 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:39:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:39:17 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:39:17 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:39:17 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:39:22 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:39:22 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:39:25 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-28 09:39:25 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-28 09:39:25 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-28 09:39:25 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-28 09:39:25 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-28 09:39:25 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-28 09:39:25 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-28 09:39:25 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-28 09:39:26 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-11-28 09:39:26 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:39:26 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:39:26 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:39:26 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:39:26 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:39:26 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:39:26 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:39:26 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:39:26 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:39:26 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:39:26 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:39:26 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:39:26 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:39:26 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:39:26 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:39:26 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:39:26 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:39:26 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:39:26 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:39:26 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:39:26 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:40:01 --> 404 Page Not Found: Images/small
ERROR - 2024-11-28 09:40:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:40:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:40:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:40:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:40:14 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:40:14 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:40:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:40:14 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:40:14 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:40:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:40:14 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:40:14 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:40:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:40:15 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:40:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:40:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:40:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 112
ERROR - 2024-11-28 09:40:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:40:15 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:40:15 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:40:15 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:40:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:40:15 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:40:15 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:40:15 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:40:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:40:15 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:40:15 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:40:15 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:40:23 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:40:28 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:40:31 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:40:31 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:40:31 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:40:31 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:40:31 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:40:31 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:40:31 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:40:31 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:40:31 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:40:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:40:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:40:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 09:40:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 112
ERROR - 2024-11-28 09:40:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 09:40:32 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 09:40:32 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:40:32 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 09:40:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 09:40:32 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 09:40:32 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:40:32 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 09:40:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 09:40:32 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 09:40:32 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:40:32 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 09:46:34 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:46:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:46:41 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-28 09:46:41 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-28 09:46:41 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-28 09:46:41 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-28 09:46:41 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-28 09:46:41 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-28 09:46:41 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-28 09:46:41 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-28 09:46:42 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-11-28 09:46:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:46:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:46:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:46:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:46:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:46:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:46:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:46:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:46:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:46:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:46:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:46:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:46:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:46:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:46:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:46:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:46:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:46:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:46:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:46:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:46:42 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 09:47:38 --> 404 Page Not Found: Images/small
ERROR - 2024-11-28 09:47:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:47:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:47:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:47:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:47:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:47:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:47:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 09:47:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:01:28 --> Severity: Notice --> Undefined index: id_estudiante /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/view.php 148
ERROR - 2024-11-28 10:01:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/helpers/recuperaciones_helper.php 21
ERROR - 2024-11-28 10:01:28 --> Severity: Notice --> Undefined index: id_estudiante /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/view.php 148
ERROR - 2024-11-28 10:01:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/helpers/recuperaciones_helper.php 21
ERROR - 2024-11-28 10:01:28 --> Severity: Notice --> Undefined index: id_estudiante /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/view.php 148
ERROR - 2024-11-28 10:01:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/helpers/recuperaciones_helper.php 21
ERROR - 2024-11-28 10:01:28 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:01:28 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:01:34 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:01:34 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:03:11 --> Severity: error --> Exception: syntax error, unexpected '$notas' (T_VARIABLE) /Applications/MAMP/htdocs/integratic/application/helpers/recuperaciones_helper.php 22
ERROR - 2024-11-28 10:04:21 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF) /Applications/MAMP/htdocs/integratic/application/helpers/recuperaciones_helper.php 22
ERROR - 2024-11-28 10:04:29 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:04:29 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:05:24 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:05:24 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:06:10 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:06:10 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:06:15 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:06:15 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:08:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:08:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:10:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:10:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:10:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:10:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:11:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:11:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:12:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:12:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:13:00 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:13:00 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:13:00 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:13:00 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:13:00 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:13:00 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:13:00 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:13:00 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:13:00 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:13:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:13:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:13:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 10:13:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 10:13:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 150
ERROR - 2024-11-28 10:13:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 10:13:00 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:13:00 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:13:00 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:13:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 10:13:00 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:13:00 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:13:00 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:13:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 10:13:00 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:13:00 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:13:00 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:13:09 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:13:09 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:13:09 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:13:09 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:13:09 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:13:09 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:13:09 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:13:09 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:13:09 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:13:09 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:13:09 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:13:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 10:13:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 10:13:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 150
ERROR - 2024-11-28 10:13:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 10:13:09 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:13:09 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:13:09 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:13:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 10:13:09 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:13:09 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:13:09 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:13:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 10:13:09 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:13:09 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:13:09 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:14:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:14:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:16:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:16:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:17:08 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:17:08 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:17:13 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:17:13 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:17:13 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:17:13 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:17:13 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:17:13 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:17:13 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:17:13 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:17:13 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:17:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:17:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:17:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 10:17:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 10:17:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 150
ERROR - 2024-11-28 10:17:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 10:17:14 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:17:14 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:17:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:17:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 10:17:14 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:17:14 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:17:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:17:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 10:17:14 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:17:14 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:17:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:17:18 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:17:18 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:17:18 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:17:18 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:17:18 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:17:18 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:17:18 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:17:18 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:17:18 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:17:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:17:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:17:18 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 10:17:18 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 10:17:18 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 150
ERROR - 2024-11-28 10:17:18 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 10:17:18 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:17:18 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:17:18 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:17:18 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 10:17:18 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:17:18 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:17:18 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:17:18 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 10:17:18 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:17:18 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:17:18 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:17:32 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:17:32 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:17:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:17:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:17:54 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:17:54 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:20:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:20:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:20:38 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:20:38 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:25:14 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:25:14 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:25:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:25:14 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:25:14 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:25:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:25:14 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:25:14 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:25:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:25:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:25:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:25:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 10:25:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 10
ERROR - 2024-11-28 10:25:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 150
ERROR - 2024-11-28 10:25:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 10:25:14 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:25:14 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:25:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:25:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 10:25:14 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:25:14 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:25:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:25:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 10:25:14 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:25:14 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:25:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:26:05 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:26:05 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:26:05 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:26:05 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:26:05 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:26:05 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:26:05 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:26:05 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:26:05 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:26:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:26:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:26:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 5
ERROR - 2024-11-28 10:26:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 5
ERROR - 2024-11-28 10:26:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/helpers/recuperaciones_helper.php 22
ERROR - 2024-11-28 10:26:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-11-28 10:26:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-11-28 10:26:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 151
ERROR - 2024-11-28 10:26:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 10:26:06 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:26:06 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:26:06 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:26:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 10:26:06 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:26:06 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:26:06 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:26:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 10:26:06 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:26:06 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:26:06 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:26:22 --> Severity: Notice --> Trying to access array offset on value of type float /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 20
ERROR - 2024-11-28 10:26:22 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:26:22 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:26:22 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:26:22 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:26:22 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:26:22 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:26:22 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:26:22 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:26:22 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:26:22 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:26:22 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:26:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 5
ERROR - 2024-11-28 10:26:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 5
ERROR - 2024-11-28 10:26:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/helpers/recuperaciones_helper.php 22
ERROR - 2024-11-28 10:26:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-11-28 10:26:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-11-28 10:26:22 --> Severity: Notice --> Trying to access array offset on value of type int /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 20
ERROR - 2024-11-28 10:26:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 151
ERROR - 2024-11-28 10:26:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 10:26:22 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:26:22 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:26:22 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:26:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 10:26:22 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:26:22 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:26:22 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:26:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 10:26:22 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:26:22 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:26:22 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:26:35 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:26:35 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:26:35 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:26:35 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:26:35 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:26:35 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:26:35 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:26:35 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:26:35 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:26:35 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:26:35 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:26:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 5
ERROR - 2024-11-28 10:26:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 5
ERROR - 2024-11-28 10:26:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/helpers/recuperaciones_helper.php 22
ERROR - 2024-11-28 10:26:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-11-28 10:26:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-11-28 10:26:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 151
ERROR - 2024-11-28 10:26:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 10:26:35 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:26:35 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:26:35 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:26:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 10:26:35 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:26:35 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:26:35 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:26:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 10:26:35 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:26:35 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:26:35 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:26:43 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:26:43 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:26:43 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:26:43 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:26:43 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:26:43 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:26:43 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:26:43 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:26:43 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:26:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:26:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:26:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 5
ERROR - 2024-11-28 10:26:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 5
ERROR - 2024-11-28 10:26:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/helpers/recuperaciones_helper.php 22
ERROR - 2024-11-28 10:26:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-11-28 10:26:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-11-28 10:26:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 151
ERROR - 2024-11-28 10:26:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 10:26:43 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:26:43 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:26:43 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:26:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 10:26:43 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:26:43 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:26:43 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:26:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 10:26:43 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:26:43 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:26:43 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:27:05 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:27:05 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:27:05 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:27:05 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:27:05 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:27:05 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:27:05 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:27:05 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:27:05 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:27:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:27:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:27:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 5
ERROR - 2024-11-28 10:27:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 5
ERROR - 2024-11-28 10:27:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/helpers/recuperaciones_helper.php 22
ERROR - 2024-11-28 10:27:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-11-28 10:27:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-11-28 10:27:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 151
ERROR - 2024-11-28 10:27:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 10:27:05 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:27:05 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:27:05 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:27:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 10:27:05 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:27:05 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:27:05 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:27:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 10:27:05 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:27:05 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:27:05 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:27:14 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:27:14 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:27:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:27:14 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:27:14 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:27:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:27:14 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:27:14 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:27:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:27:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:27:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:27:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 5
ERROR - 2024-11-28 10:27:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 5
ERROR - 2024-11-28 10:27:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/helpers/recuperaciones_helper.php 22
ERROR - 2024-11-28 10:27:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-11-28 10:27:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-11-28 10:27:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 151
ERROR - 2024-11-28 10:27:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 10:27:15 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:27:15 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:27:15 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:27:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 10:27:15 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:27:15 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:27:15 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:27:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 10:27:15 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:27:15 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:27:15 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:27:33 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:27:33 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:27:33 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:27:33 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:27:33 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:27:33 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:27:33 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:27:33 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:27:33 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:27:33 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:27:33 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:27:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 5
ERROR - 2024-11-28 10:27:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 5
ERROR - 2024-11-28 10:27:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/helpers/recuperaciones_helper.php 22
ERROR - 2024-11-28 10:27:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-11-28 10:27:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-11-28 10:27:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 151
ERROR - 2024-11-28 10:27:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 10:27:33 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:27:33 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:27:33 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:27:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 10:27:33 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:27:33 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:27:33 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:27:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 10:27:33 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:27:33 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:27:33 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:27:38 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:27:38 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:27:38 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:27:38 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:27:38 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:27:38 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:27:38 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:27:38 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:27:38 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:27:38 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:27:38 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:27:38 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 5
ERROR - 2024-11-28 10:27:38 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 5
ERROR - 2024-11-28 10:27:38 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/helpers/recuperaciones_helper.php 22
ERROR - 2024-11-28 10:27:38 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-11-28 10:27:38 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-11-28 10:27:38 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 151
ERROR - 2024-11-28 10:27:38 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 10:27:38 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:27:38 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:27:38 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:27:38 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 10:27:38 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:27:38 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:27:38 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:27:38 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 10:27:38 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:27:38 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:27:38 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:28:03 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:28:03 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:28:03 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:28:03 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:28:03 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:28:03 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:28:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:28:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:28:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 5
ERROR - 2024-11-28 10:28:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 5
ERROR - 2024-11-28 10:28:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/helpers/recuperaciones_helper.php 22
ERROR - 2024-11-28 10:28:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-11-28 10:28:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-11-28 10:28:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 152
ERROR - 2024-11-28 10:28:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 10:28:03 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:28:03 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:28:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 10:28:03 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:28:03 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:28:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 10:28:03 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:28:03 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:28:14 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:28:14 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:28:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:28:14 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:28:14 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:28:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:28:14 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:28:14 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:28:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:28:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:28:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:28:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 5
ERROR - 2024-11-28 10:28:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 5
ERROR - 2024-11-28 10:28:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/helpers/recuperaciones_helper.php 22
ERROR - 2024-11-28 10:28:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-11-28 10:28:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-11-28 10:28:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 152
ERROR - 2024-11-28 10:28:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-28 10:28:14 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-28 10:28:14 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:28:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-28 10:28:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-28 10:28:14 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-28 10:28:14 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:28:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-28 10:28:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-28 10:28:14 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-28 10:28:14 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:28:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-28 10:30:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:30:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:30:41 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:30:41 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:35:48 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:35:48 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:35:51 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:35:51 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:36:04 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:36:04 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:36:12 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-28 10:36:12 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-28 10:36:12 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-28 10:36:12 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-28 10:36:12 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-28 10:36:12 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-28 10:36:12 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-28 10:36:12 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-28 10:36:12 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-11-28 10:36:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:36:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:36:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:36:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:36:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:36:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:36:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:36:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:36:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:36:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:36:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:36:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:36:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:36:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:36:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:36:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:36:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:36:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:36:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:36:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:36:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:36:13 --> 404 Page Not Found: Images/small
ERROR - 2024-11-28 10:36:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:36:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:36:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:36:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:36:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:36:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:36:29 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 85
ERROR - 2024-11-28 10:36:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:36:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:36:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:36:46 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 85
ERROR - 2024-11-28 10:36:58 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:36:58 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:36:58 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:36:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:37:02 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:37:06 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:37:10 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:37:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:37:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:37:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:37:23 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-28 10:37:23 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-28 10:37:23 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-28 10:37:23 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-28 10:37:23 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-28 10:37:23 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-28 10:37:23 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-28 10:37:23 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-28 10:37:23 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-11-28 10:37:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:37:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:37:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:37:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:37:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:37:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:37:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:37:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:37:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:37:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:37:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:37:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:37:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:37:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:37:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:37:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:37:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:37:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:37:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:37:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:37:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:37:25 --> 404 Page Not Found: Images/small
ERROR - 2024-11-28 10:37:35 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:37:35 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:37:35 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:37:35 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:37:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:37:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:38:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:38:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:39:09 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:39:09 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:41:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:41:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:43:02 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:43:02 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:43:06 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:43:06 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:43:09 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-28 10:43:09 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-28 10:43:09 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-28 10:43:09 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-28 10:43:09 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-28 10:43:09 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-28 10:43:09 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-28 10:43:09 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-28 10:43:09 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-11-28 10:43:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:43:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:43:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:43:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:43:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:43:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:43:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:43:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:43:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:43:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:43:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:43:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:43:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:43:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:43:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:43:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:43:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:43:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:43:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:43:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:43:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:43:10 --> 404 Page Not Found: Images/small
ERROR - 2024-11-28 10:43:18 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:43:18 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:43:18 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:43:18 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:44:39 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:44:39 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:02 --> Severity: Warning --> mkdir(): No such file or directory /Applications/MAMP/htdocs/integratic/application/controllers/Asignacion.php 52
ERROR - 2024-11-28 10:45:06 --> Severity: Warning --> mkdir(): No such file or directory /Applications/MAMP/htdocs/integratic/application/controllers/Asignacion.php 52
ERROR - 2024-11-28 10:45:09 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-28 10:45:09 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-28 10:45:09 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-28 10:45:09 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-28 10:45:09 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-28 10:45:09 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-28 10:45:09 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-28 10:45:09 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-28 10:45:09 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-11-28 10:45:09 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:10 --> 404 Page Not Found: Images/small
ERROR - 2024-11-28 10:45:17 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:45:17 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:45:17 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:45:17 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:45:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:45:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:45:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:45:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:45:31 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-28 10:45:31 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-28 10:45:31 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-28 10:45:31 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-28 10:45:31 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-28 10:45:31 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-28 10:45:31 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-28 10:45:31 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-28 10:45:31 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-11-28 10:45:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:31 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:32 --> 404 Page Not Found: Images/small
ERROR - 2024-11-28 10:45:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:34 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:40 --> Severity: Warning --> mkdir(): No such file or directory /Applications/MAMP/htdocs/integratic/application/controllers/Asignacion.php 52
ERROR - 2024-11-28 10:45:46 --> Severity: Warning --> mkdir(): No such file or directory /Applications/MAMP/htdocs/integratic/application/controllers/Asignacion.php 52
ERROR - 2024-11-28 10:45:48 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-28 10:45:48 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-28 10:45:48 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-28 10:45:48 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-28 10:45:48 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-28 10:45:48 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-28 10:45:48 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-28 10:45:48 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-28 10:45:48 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-11-28 10:45:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:48 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-28 10:45:49 --> 404 Page Not Found: Images/small
ERROR - 2024-11-28 10:45:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:45:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:45:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:45:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:46:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:46:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:46:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:46:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:47:02 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:47:02 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:48:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:48:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:49:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:49:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:49:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:49:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:50:02 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:50:02 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:50:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:50:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:51:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:51:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:51:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:51:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:51:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-28 10:51:59 --> 404 Page Not Found: Img/iconos
