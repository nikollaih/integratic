<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-03-15 08:55:27 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-15 08:55:27 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-15 08:55:27 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-15 08:55:27 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-15 08:55:27 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-15 08:55:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:55:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:55:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:55:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:55:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:55:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:55:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:55:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:55:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:55:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:55:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:55:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:55:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:55:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:55:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:55:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:55:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:55:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:55:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:55:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:55:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:55:29 --> 404 Page Not Found: Images/small
ERROR - 2025-03-15 08:55:31 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-15 08:55:31 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-15 08:55:31 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.m.codmateria' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: Select * from cfg_areas a left join cfg_materias m on a.codarea = m.area join asg_materias am on am.materia = m.codmateria where m.grado = '11' and am.grupo = 'A' group by a.codarea
ERROR - 2025-03-15 08:55:38 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.m.codmateria' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: Select * from cfg_areas a left join cfg_materias m on a.codarea = m.area join asg_materias am on am.materia = m.codmateria where m.grado = '11' and am.grupo = 'A' group by a.codarea
ERROR - 2025-03-15 08:55:41 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.m.codmateria' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: Select * from cfg_areas a left join cfg_materias m on a.codarea = m.area join asg_materias am on am.materia = m.codmateria where m.grado = '11' and am.grupo = 'A' group by a.codarea
ERROR - 2025-03-15 08:55:47 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 08:55:47 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 08:55:52 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.m.codmateria' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: Select * from cfg_areas a left join cfg_materias m on a.codarea = m.area join asg_materias am on am.materia = m.codmateria where m.grado = '11' and am.grupo = 'A' group by a.codarea
ERROR - 2025-03-15 08:56:41 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-15 08:56:42 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 08:56:42 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 08:56:44 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 08:56:44 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 08:56:53 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-15 08:56:53 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-15 08:56:53 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-15 08:56:53 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-15 08:56:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:56:54 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-15 08:56:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:56:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:56:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:56:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:56:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:56:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:56:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:56:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:56:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:56:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:56:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:56:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:56:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:56:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:56:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:56:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:56:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:56:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:56:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:56:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 08:56:55 --> 404 Page Not Found: Images/small
ERROR - 2025-03-15 08:57:05 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-15 08:57:05 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-15 08:57:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 98
ERROR - 2025-03-15 08:57:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 256
ERROR - 2025-03-15 08:57:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 257
ERROR - 2025-03-15 08:57:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-15 08:57:29 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2025-03-15 08:57:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2025-03-15 08:57:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2025-03-15 08:57:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-03-15 08:57:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-03-15 08:57:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-03-15 08:57:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-03-15 08:57:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-03-15 08:57:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-03-15 08:57:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-03-15 08:57:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-03-15 08:57:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-03-15 08:57:30 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 08:57:30 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 08:57:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 08:57:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 08:57:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 08:57:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 08:57:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 08:57:33 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 08:57:33 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 08:58:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 08:58:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 08:58:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 08:58:52 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 08:58:52 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 08:58:55 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2025-03-15 08:58:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2025-03-15 08:58:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2025-03-15 08:58:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-03-15 08:58:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-03-15 08:58:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-03-15 08:58:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-03-15 08:58:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-03-15 08:58:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-03-15 08:58:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-03-15 08:58:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-03-15 08:58:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-03-15 08:58:55 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 08:58:55 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 08:59:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 08:59:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 08:59:00 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 08:59:00 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 08:59:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 08:59:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 08:59:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-03-15 08:59:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-03-15 08:59:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-03-15 08:59:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 08:59:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 08:59:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-03-15 08:59:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 08:59:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 08:59:04 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 08:59:04 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 08:59:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 08:59:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 08:59:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-03-15 08:59:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-03-15 08:59:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-03-15 08:59:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 08:59:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 08:59:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-03-15 08:59:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 08:59:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 08:59:05 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 08:59:05 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 08:59:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 08:59:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 08:59:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-03-15 08:59:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-03-15 08:59:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-03-15 08:59:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 08:59:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 08:59:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-03-15 08:59:08 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 08:59:08 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 08:59:08 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 08:59:08 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 08:59:08 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 08:59:08 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 08:59:08 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-03-15 08:59:08 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-03-15 08:59:08 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-03-15 08:59:08 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 08:59:08 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 08:59:08 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-03-15 08:59:09 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 08:59:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 08:59:09 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 08:59:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 08:59:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 08:59:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 08:59:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-03-15 08:59:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-03-15 08:59:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-03-15 08:59:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 08:59:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 08:59:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-03-15 08:59:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 08:59:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 08:59:17 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 08:59:17 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 08:59:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 08:59:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 08:59:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-03-15 08:59:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-03-15 08:59:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-03-15 08:59:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 08:59:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 08:59:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-03-15 08:59:20 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 08:59:20 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 08:59:20 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 08:59:20 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 08:59:20 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 08:59:20 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 08:59:20 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-03-15 08:59:20 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-03-15 08:59:20 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-03-15 08:59:20 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 08:59:20 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 08:59:20 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-03-15 08:59:22 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 08:59:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 08:59:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 08:59:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 08:59:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 08:59:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 08:59:22 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 08:59:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 08:59:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 08:59:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 08:59:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 08:59:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 08:59:23 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 08:59:23 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 08:59:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 08:59:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 08:59:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 08:59:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 08:59:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 08:59:24 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 08:59:24 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 08:59:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 08:59:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 08:59:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 08:59:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 08:59:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 08:59:25 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 08:59:25 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 08:59:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 08:59:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 08:59:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 08:59:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 08:59:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 08:59:26 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 08:59:26 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:00:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:00:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:00:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:00:20 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:00:20 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:00:22 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2025-03-15 09:00:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2025-03-15 09:00:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2025-03-15 09:00:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-03-15 09:00:22 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:00:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-03-15 09:00:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-03-15 09:00:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-03-15 09:00:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-03-15 09:00:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-03-15 09:00:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-03-15 09:00:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-03-15 09:00:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-03-15 09:00:22 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:00:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:00:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:00:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:00:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:00:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-03-15 09:00:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-03-15 09:00:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-03-15 09:00:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 09:00:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 09:00:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-03-15 09:00:24 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:00:24 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:01:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:01:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:01:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:01:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:01:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-03-15 09:01:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-03-15 09:01:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-03-15 09:01:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 09:01:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 09:01:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-03-15 09:01:04 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:01:04 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:01:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:01:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:01:06 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:01:06 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:01:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:01:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:01:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-03-15 09:01:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-03-15 09:01:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-03-15 09:01:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 09:01:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 09:01:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-03-15 09:01:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:01:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:01:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:01:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:01:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-03-15 09:01:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-03-15 09:01:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-03-15 09:01:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 09:01:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 09:01:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-03-15 09:01:09 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:01:09 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:01:12 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:01:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:01:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:01:12 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:01:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:01:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:01:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-03-15 09:01:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-03-15 09:01:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-03-15 09:01:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 09:01:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 09:01:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-03-15 09:01:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:01:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:01:14 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:01:14 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:01:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:01:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:01:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-03-15 09:01:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-03-15 09:01:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-03-15 09:01:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 09:01:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 09:01:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-03-15 09:03:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:03:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:03:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:03:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:03:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:03:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:03:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:03:41 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:03:41 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:03:43 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:03:43 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:03:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:03:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:03:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:03:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:03:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:03:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:03:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:03:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2025-03-15 09:03:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2025-03-15 09:03:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-03-15 09:03:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-03-15 09:03:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-03-15 09:03:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-03-15 09:03:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-03-15 09:03:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-03-15 09:03:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-03-15 09:03:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-03-15 09:03:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-03-15 09:03:52 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:03:52 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:03:54 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2025-03-15 09:03:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2025-03-15 09:03:54 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:03:54 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:03:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2025-03-15 09:03:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-03-15 09:03:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-03-15 09:03:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-03-15 09:03:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-03-15 09:03:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-03-15 09:03:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-03-15 09:03:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-03-15 09:03:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-03-15 09:03:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-03-15 09:04:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 206
ERROR - 2025-03-15 09:04:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 206
ERROR - 2025-03-15 09:04:43 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:04:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:04:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:04:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-03-15 09:04:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-03-15 09:04:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-03-15 09:04:43 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:04:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 09:04:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-15 09:04:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-03-15 09:05:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2025-03-15 09:05:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2025-03-15 09:05:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-03-15 09:05:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-03-15 09:05:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-03-15 09:05:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-03-15 09:05:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-03-15 09:05:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-03-15 09:05:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-03-15 09:05:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-03-15 09:05:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-03-15 09:05:39 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:05:39 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:05:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:05:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:05:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:05:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:05:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:05:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:05:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:05:44 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:05:44 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:06:02 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:06:02 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:06:02 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:06:02 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:06:02 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:06:02 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:06:02 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:06:02 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:06:02 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:06:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:06:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:06:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:06:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:06:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:06:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:06:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:06:04 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:06:04 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:06:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:06:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:06:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:06:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:06:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:06:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:06:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:06:48 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:06:48 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:09:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:09:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:09:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:09:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:09:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:09:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:09:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:09:23 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:09:23 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:09:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:09:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:09:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:09:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:09:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:09:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:09:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:09:27 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:09:27 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:09:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:09:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:09:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:09:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:09:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:09:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:09:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:09:29 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:09:29 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:09:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:09:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:09:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:09:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:09:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:09:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:09:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:09:31 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:09:31 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:09:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:09:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:09:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:09:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:09:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:09:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:09:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:09:33 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:09:33 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:09:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:09:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:09:34 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:09:34 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:09:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:09:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:09:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:09:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:09:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:09:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:09:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:09:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:09:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:09:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:09:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:09:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:09:36 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:09:36 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:09:36 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:09:36 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:09:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:09:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:09:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:09:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:09:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:09:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:09:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:09:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:09:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-15 09:09:37 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:09:37 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:09:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:09:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:09:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:09:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:09:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:15:35 --> Severity: Warning --> array_merge(): Expected parameter 1 to be an array, bool given /Applications/MAMP/htdocs/integratic/application/helpers/preguntas_helper.php 70
ERROR - 2025-03-15 09:15:44 --> Severity: Warning --> array_merge(): Expected parameter 1 to be an array, bool given /Applications/MAMP/htdocs/integratic/application/helpers/preguntas_helper.php 70
ERROR - 2025-03-15 09:15:46 --> Severity: Warning --> array_merge(): Expected parameter 1 to be an array, bool given /Applications/MAMP/htdocs/integratic/application/helpers/preguntas_helper.php 70
ERROR - 2025-03-15 09:17:44 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:17:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 204
ERROR - 2025-03-15 09:17:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 204
ERROR - 2025-03-15 09:17:45 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:17:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:17:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:17:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:17:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:17:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:17:47 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 204
ERROR - 2025-03-15 09:17:47 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 204
ERROR - 2025-03-15 09:17:47 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:17:47 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:17:47 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:17:47 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:17:47 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:17:47 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:17:47 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:17:50 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 204
ERROR - 2025-03-15 09:17:50 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 204
ERROR - 2025-03-15 09:17:50 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:17:50 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:17:50 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:17:50 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:17:50 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:17:50 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:17:50 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:17:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 204
ERROR - 2025-03-15 09:17:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 204
ERROR - 2025-03-15 09:17:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:17:51 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:17:51 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:17:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:17:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:17:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:17:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:17:52 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:17:52 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:17:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 204
ERROR - 2025-03-15 09:17:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 204
ERROR - 2025-03-15 09:17:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:17:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:17:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:17:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:17:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:17:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 204
ERROR - 2025-03-15 09:17:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 204
ERROR - 2025-03-15 09:17:54 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:17:54 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:17:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:17:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:17:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:17:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:17:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:17:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 204
ERROR - 2025-03-15 09:17:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 204
ERROR - 2025-03-15 09:17:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:17:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:17:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:17:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:17:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:17:56 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:17:56 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:17:58 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:17:58 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:17:58 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 204
ERROR - 2025-03-15 09:17:58 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 204
ERROR - 2025-03-15 09:17:58 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:17:58 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:17:58 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:17:58 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:17:58 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:18:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 204
ERROR - 2025-03-15 09:18:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 204
ERROR - 2025-03-15 09:18:03 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:18:03 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:18:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:18:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:18:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:18:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:18:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:18:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 204
ERROR - 2025-03-15 09:18:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 204
ERROR - 2025-03-15 09:18:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:18:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:18:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:18:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:18:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:18:06 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:18:06 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:18:10 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:18:10 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:18:10 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:18:10 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:18:10 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:18:10 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:18:10 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:18:20 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:18:20 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:18:23 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2025-03-15 09:18:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2025-03-15 09:18:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2025-03-15 09:18:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-03-15 09:18:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-03-15 09:18:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-03-15 09:18:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-03-15 09:18:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-03-15 09:18:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-03-15 09:18:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-03-15 09:18:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-03-15 09:18:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-03-15 09:18:23 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:18:23 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:18:27 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-15 09:18:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:18:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:18:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:18:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:18:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:18:27 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-15 09:18:35 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2025-03-15 09:18:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2025-03-15 09:18:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2025-03-15 09:18:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-03-15 09:18:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-03-15 09:18:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-03-15 09:18:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-03-15 09:18:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-03-15 09:18:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-03-15 09:18:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-03-15 09:18:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-03-15 09:18:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-03-15 09:19:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 255
ERROR - 2025-03-15 09:19:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 256
ERROR - 2025-03-15 09:19:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-15 09:19:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:19:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:19:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:19:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:19:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:19:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:19:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:19:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:19:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:48:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:48:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:48:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:48:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:48:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:48:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 09:53:54 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2025-03-15 09:53:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2025-03-15 09:53:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2025-03-15 09:53:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-03-15 09:53:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-03-15 09:53:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-03-15 09:53:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-03-15 09:53:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-03-15 09:53:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-03-15 09:53:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-03-15 09:53:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-03-15 09:53:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-03-15 09:53:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-15 09:53:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-15 09:53:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-15 09:53:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-15 09:53:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-15 10:08:32 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-15 10:08:35 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-15 10:08:35 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-15 10:08:35 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-15 10:08:35 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-15 10:08:35 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-15 10:08:35 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-15 10:08:35 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-15 10:08:35 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-15 10:08:35 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-15 10:08:35 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 10:08:35 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 10:08:35 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 10:08:35 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 10:08:35 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 10:08:35 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 10:08:35 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 10:08:35 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 10:08:35 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 10:08:35 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 10:08:35 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 10:08:35 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 10:08:35 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 10:08:35 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 10:08:35 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 10:08:35 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 10:08:35 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 10:08:35 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 10:08:35 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 10:08:35 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 10:08:35 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-15 10:08:37 --> 404 Page Not Found: Images/small
ERROR - 2025-03-15 10:08:46 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-15 10:08:46 --> 404 Page Not Found: Img/iconos
