<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-01-03 14:17:21 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-01-03 14:17:21 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-01-03 14:17:21 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-01-03 14:17:21 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-01-03 14:17:21 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-01-03 14:17:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:17:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:17:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:17:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:17:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:17:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:17:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:17:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:17:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:17:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:17:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:17:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:17:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:17:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:17:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:17:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:17:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:17:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:17:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:17:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:17:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:17:22 --> 404 Page Not Found: Images/small
ERROR - 2025-01-03 14:17:29 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 14:17:29 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 14:17:29 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 14:17:29 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 14:17:35 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.am.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT *
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE `am`.`docente` = '12345'
GROUP BY `am`.`materia`
ERROR - 2025-01-03 14:18:00 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-01-03 14:31:15 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-01-03 14:34:50 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-01-03 14:36:26 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-01-03 14:37:29 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-01-03 14:38:23 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-01-03 14:43:14 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-01-03 14:43:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/ver_pregunta.php 18
ERROR - 2025-01-03 14:43:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/ver_pregunta.php 19
ERROR - 2025-01-03 14:43:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/ver_pregunta.php 21
ERROR - 2025-01-03 14:45:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/ver_pregunta.php 18
ERROR - 2025-01-03 14:45:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/ver_pregunta.php 18
ERROR - 2025-01-03 14:45:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/ver_pregunta.php 19
ERROR - 2025-01-03 14:45:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/ver_pregunta.php 21
ERROR - 2025-01-03 14:45:22 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-01-03 14:46:02 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-01-03 14:46:11 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 98
ERROR - 2025-01-03 14:46:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 237
ERROR - 2025-01-03 14:46:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 238
ERROR - 2025-01-03 14:46:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 4 - Invalid query: SELECT *
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE materia IN()
ERROR - 2025-01-03 14:46:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 237
ERROR - 2025-01-03 14:46:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 238
ERROR - 2025-01-03 14:46:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 4 - Invalid query: SELECT *
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE materia IN()
ERROR - 2025-01-03 14:46:47 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 14:46:47 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 14:46:50 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-01-03 14:46:50 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-01-03 14:46:50 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-01-03 14:46:50 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-01-03 14:46:50 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-01-03 14:46:50 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-01-03 14:46:50 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-01-03 14:46:50 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-01-03 14:46:50 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-01-03 14:46:50 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:46:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:46:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:46:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:46:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:46:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:46:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:46:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:46:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:46:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:46:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:46:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:46:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:46:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:46:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:46:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:46:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:46:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:46:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:46:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:46:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 14:46:52 --> 404 Page Not Found: Images/small
ERROR - 2025-01-03 14:46:53 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 14:46:54 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 14:46:59 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2025-01-03 14:46:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2025-01-03 14:46:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2025-01-03 14:46:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-01-03 14:46:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-01-03 14:46:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-01-03 14:46:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-01-03 14:46:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-01-03 14:46:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-01-03 14:46:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-01-03 14:46:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-01-03 14:46:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-01-03 14:47:01 --> Query error: Column 'institucion' cannot be null - Invalid query: INSERT INTO `realizar_prueba` (`id_prueba`, `id_participante`, `institucion`, `grado`, `created_at`) VALUES ('3', '3', NULL, '11A', '2025-01-03 14:47:01')
ERROR - 2025-01-03 14:48:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 186
ERROR - 2025-01-03 14:48:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 186
ERROR - 2025-01-03 14:48:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 14:48:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 14:48:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-01-03 14:48:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-01-03 14:48:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-01-03 14:48:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 14:48:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 14:48:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-01-03 14:50:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 186
ERROR - 2025-01-03 14:50:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 186
ERROR - 2025-01-03 14:50:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 14:50:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 14:50:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-01-03 14:50:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-01-03 14:50:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-01-03 14:50:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 14:50:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 14:50:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-01-03 14:50:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 186
ERROR - 2025-01-03 14:50:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 186
ERROR - 2025-01-03 14:50:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 14:50:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 14:50:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-01-03 14:50:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-01-03 14:50:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-01-03 14:50:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 14:50:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 14:50:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-01-03 14:51:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 186
ERROR - 2025-01-03 14:51:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 186
ERROR - 2025-01-03 14:51:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 14:51:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 14:51:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-01-03 14:51:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-01-03 14:51:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-01-03 14:51:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 14:51:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 14:51:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-01-03 14:52:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 186
ERROR - 2025-01-03 14:52:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 186
ERROR - 2025-01-03 14:52:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 14:52:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 14:52:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-01-03 14:52:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-01-03 14:52:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-01-03 14:52:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 14:52:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 14:52:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-01-03 14:55:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 187
ERROR - 2025-01-03 14:55:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 187
ERROR - 2025-01-03 14:55:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 14:55:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 14:55:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-01-03 14:55:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-01-03 14:55:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-01-03 14:55:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 14:55:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 14:55:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-01-03 14:55:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 187
ERROR - 2025-01-03 14:55:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 187
ERROR - 2025-01-03 14:55:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 14:55:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 14:55:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-01-03 14:55:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-01-03 14:55:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-01-03 14:55:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 14:55:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 14:55:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-01-03 14:55:50 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-03 14:55:50 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-03 15:02:29 --> Severity: error --> Exception: Unable to locate the model you have specified: Respuestas_Realizar_Prueba_Abierta_Model /Applications/MAMP/htdocs/integratic/system/core/Loader.php 344
ERROR - 2025-01-03 15:02:50 --> Severity: error --> Exception: Unable to locate the model you have specified: Respuestas_Realizar_Prueba_Abiertas_Model /Applications/MAMP/htdocs/integratic/system/core/Loader.php 344
ERROR - 2025-01-03 15:03:18 --> Severity: error --> Exception: Unable to locate the model you have specified: Respuestas_Realizar_Prueba_Abierta_Model /Applications/MAMP/htdocs/integratic/system/core/Loader.php 344
ERROR - 2025-01-03 15:04:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 193
ERROR - 2025-01-03 15:04:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 193
ERROR - 2025-01-03 15:04:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:04:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:04:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-01-03 15:04:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-01-03 15:04:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-01-03 15:04:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:04:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:04:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-01-03 15:05:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 193
ERROR - 2025-01-03 15:05:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 193
ERROR - 2025-01-03 15:05:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:05:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:05:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-01-03 15:05:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-01-03 15:05:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-01-03 15:05:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:05:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:05:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-01-03 15:06:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 195
ERROR - 2025-01-03 15:06:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 195
ERROR - 2025-01-03 15:06:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:06:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:06:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-01-03 15:06:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-01-03 15:06:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-01-03 15:06:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:06:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:06:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-01-03 15:06:57 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-03 15:06:57 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-03 15:07:30 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-03 15:07:30 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-03 15:07:37 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-03 15:07:37 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-03 15:08:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:08:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:08:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:08:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:08:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-01-03 15:08:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-01-03 15:08:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-01-03 15:08:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:08:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:08:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-01-03 15:08:23 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-03 15:08:23 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-03 15:09:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:09:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:09:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:09:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:09:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-01-03 15:09:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-01-03 15:09:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-01-03 15:09:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:09:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:09:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-01-03 15:09:22 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-03 15:09:22 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-03 15:09:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:09:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:09:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:09:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:09:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:09:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:09:54 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-03 15:09:54 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-03 15:11:58 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-03 15:11:58 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-03 15:19:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:19:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:19:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:19:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:20:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:20:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:20:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:20:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:20:16 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2025-01-03 15:20:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2025-01-03 15:20:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2025-01-03 15:20:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-01-03 15:20:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-01-03 15:20:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-01-03 15:20:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-01-03 15:20:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-01-03 15:20:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-01-03 15:20:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-01-03 15:20:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-01-03 15:20:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-01-03 15:20:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:20:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:20:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:20:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:20:29 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2025-01-03 15:20:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2025-01-03 15:20:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2025-01-03 15:20:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-01-03 15:20:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-01-03 15:20:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-01-03 15:20:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-01-03 15:20:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-01-03 15:20:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-01-03 15:20:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-01-03 15:20:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-01-03 15:20:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-01-03 15:20:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:20:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:20:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:20:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:21:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:21:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:21:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:21:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:21:29 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2025-01-03 15:21:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2025-01-03 15:21:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2025-01-03 15:21:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-01-03 15:21:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-01-03 15:21:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-01-03 15:21:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-01-03 15:21:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-01-03 15:21:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-01-03 15:21:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-01-03 15:21:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-01-03 15:21:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-01-03 15:21:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:21:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:21:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:21:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:21:39 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2025-01-03 15:21:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2025-01-03 15:21:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2025-01-03 15:21:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-01-03 15:21:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-01-03 15:21:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-01-03 15:21:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-01-03 15:21:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-01-03 15:21:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-01-03 15:21:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-01-03 15:21:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-01-03 15:21:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-01-03 15:22:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:22:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:22:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:22:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:22:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2025-01-03 15:22:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2025-01-03 15:22:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-01-03 15:22:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-01-03 15:22:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-01-03 15:22:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-01-03 15:22:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-01-03 15:22:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-01-03 15:22:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-01-03 15:22:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-01-03 15:22:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-01-03 15:22:20 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:22:20 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:22:20 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:22:20 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:24:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:24:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:24:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:24:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:25:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:25:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:25:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:25:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:25:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:25:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:25:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:25:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:25:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:25:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:25:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:25:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:26:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:26:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:26:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:26:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:27:10 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:27:10 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:27:10 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:27:10 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:28:41 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:28:41 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:28:41 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:28:41 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:28:41 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 15:30:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:30:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:30:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:30:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:30:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 15:30:50 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ';' or ',' /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 134
ERROR - 2025-01-03 15:30:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:30:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:30:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:30:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:30:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 15:31:47 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:31:47 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:31:47 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:31:47 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:31:47 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 15:32:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:32:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:32:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:32:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:32:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 15:32:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:32:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:32:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:32:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:32:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 15:32:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:32:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:32:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:32:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:32:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 15:34:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:34:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:34:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:34:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:34:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 15:34:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:34:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:34:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:34:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:34:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 15:34:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:34:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:34:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:34:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:34:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 15:34:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:34:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:34:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:34:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:34:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 15:34:58 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:34:58 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:34:58 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:34:58 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:34:58 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 15:35:07 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:35:07 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:35:07 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:35:07 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:35:07 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 15:39:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:39:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:39:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:39:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:39:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 15:39:24 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2025-01-03 15:39:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2025-01-03 15:39:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2025-01-03 15:39:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-01-03 15:39:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-01-03 15:39:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-01-03 15:39:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-01-03 15:39:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-01-03 15:39:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-01-03 15:39:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-01-03 15:39:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-01-03 15:39:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-01-03 15:39:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:39:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:39:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:39:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:39:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 15:39:30 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 15:39:32 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-01-03 15:39:32 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-01-03 15:39:32 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-01-03 15:39:32 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-01-03 15:39:32 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-01-03 15:39:32 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-01-03 15:39:32 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-01-03 15:39:32 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-01-03 15:39:32 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-01-03 15:39:32 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:39:32 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:39:32 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:39:32 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:39:32 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:39:32 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:39:32 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:39:32 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:39:32 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:39:32 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:39:32 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:39:32 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:39:32 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:39:32 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:39:32 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:39:32 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:39:32 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:39:32 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:39:32 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:39:32 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:39:32 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:39:34 --> 404 Page Not Found: Images/small
ERROR - 2025-01-03 15:39:41 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 15:39:41 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 15:39:41 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 15:39:41 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 15:39:45 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-01-03 15:40:00 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-01-03 15:40:33 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-01-03 15:40:58 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-01-03 15:41:01 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-01-03 15:41:34 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-01-03 15:41:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 98
ERROR - 2025-01-03 15:41:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 248
ERROR - 2025-01-03 15:41:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 249
ERROR - 2025-01-03 15:41:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 4 - Invalid query: SELECT *
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE materia IN()
ERROR - 2025-01-03 15:41:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 248
ERROR - 2025-01-03 15:41:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 249
ERROR - 2025-01-03 15:41:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 4 - Invalid query: SELECT *
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE materia IN()
ERROR - 2025-01-03 15:41:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 98
ERROR - 2025-01-03 15:41:59 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 15:41:59 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 15:42:02 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-01-03 15:42:02 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-01-03 15:42:02 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-01-03 15:42:02 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-01-03 15:42:02 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-01-03 15:42:02 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-01-03 15:42:02 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-01-03 15:42:02 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-01-03 15:42:02 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-01-03 15:42:02 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:42:02 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:42:02 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:42:02 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:42:02 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:42:02 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:42:02 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:42:02 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:42:02 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:42:02 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:42:02 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:42:02 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:42:02 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:42:02 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:42:02 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:42:02 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:42:02 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:42:02 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:42:02 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:42:02 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:42:02 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:42:04 --> 404 Page Not Found: Images/small
ERROR - 2025-01-03 15:42:05 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 15:42:05 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 15:42:09 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2025-01-03 15:42:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2025-01-03 15:42:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2025-01-03 15:42:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-01-03 15:42:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-01-03 15:42:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-01-03 15:42:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-01-03 15:42:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-01-03 15:42:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-01-03 15:42:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-01-03 15:42:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-01-03 15:42:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-01-03 15:42:11 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:42:11 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:42:11 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:42:11 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:42:11 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-01-03 15:42:11 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-01-03 15:42:11 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-01-03 15:42:11 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:42:11 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:42:11 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-01-03 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:42:50 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:42:50 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:42:50 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-01-03 15:42:50 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-01-03 15:42:50 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-01-03 15:42:50 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:42:50 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:42:50 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-01-03 15:42:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:42:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:42:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:42:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:42:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-01-03 15:42:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-01-03 15:42:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-01-03 15:42:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:42:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:42:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-01-03 15:42:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:42:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:42:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:42:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:42:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-01-03 15:42:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-01-03 15:42:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-01-03 15:42:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:42:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:42:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-01-03 15:42:57 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:42:57 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:42:57 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:42:57 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:42:57 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-01-03 15:42:57 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-01-03 15:42:57 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-01-03 15:42:57 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:42:57 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:42:57 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-01-03 15:42:58 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:42:58 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:42:58 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:42:58 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:42:58 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-01-03 15:42:58 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-01-03 15:42:58 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-01-03 15:42:58 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:42:58 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:42:58 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-01-03 15:42:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:42:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:42:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:42:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:42:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-01-03 15:42:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-01-03 15:42:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-01-03 15:42:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:42:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:42:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-01-03 15:43:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:43:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:43:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:43:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:43:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-01-03 15:43:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-01-03 15:43:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-01-03 15:43:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:43:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:43:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-01-03 15:43:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:43:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:43:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:43:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:43:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-01-03 15:43:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-01-03 15:43:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-01-03 15:43:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:43:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:43:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-01-03 15:45:05 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 15:45:23 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 15:45:27 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-01-03 15:45:27 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-01-03 15:45:27 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-01-03 15:45:27 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-01-03 15:45:27 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-01-03 15:45:27 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-01-03 15:45:27 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-01-03 15:45:27 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-01-03 15:45:27 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-01-03 15:45:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:45:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:45:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:45:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:45:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:45:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:45:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:45:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:45:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:45:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:45:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:45:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:45:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:45:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:45:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:45:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:45:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:45:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:45:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:45:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:45:27 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:45:28 --> 404 Page Not Found: Images/small
ERROR - 2025-01-03 15:45:34 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 15:45:34 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 15:45:34 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 15:45:34 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 15:45:37 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-01-03 15:46:01 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-01-03 15:46:59 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-01-03 15:47:14 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-01-03 15:47:20 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-01-03 15:47:47 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-01-03 15:47:53 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 98
ERROR - 2025-01-03 15:47:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 248
ERROR - 2025-01-03 15:47:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 249
ERROR - 2025-01-03 15:47:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 4 - Invalid query: SELECT *
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE materia IN()
ERROR - 2025-01-03 15:48:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 248
ERROR - 2025-01-03 15:48:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 249
ERROR - 2025-01-03 15:48:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 4 - Invalid query: SELECT *
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE materia IN()
ERROR - 2025-01-03 15:48:03 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 15:48:03 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 15:48:06 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-01-03 15:48:06 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-01-03 15:48:06 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-01-03 15:48:06 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-01-03 15:48:06 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-01-03 15:48:06 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-01-03 15:48:06 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-01-03 15:48:06 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-01-03 15:48:07 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-01-03 15:48:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:48:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:48:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:48:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:48:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:48:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:48:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:48:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:48:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:48:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:48:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:48:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:48:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:48:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:48:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:48:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:48:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:48:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:48:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:48:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:48:07 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 15:48:08 --> 404 Page Not Found: Images/small
ERROR - 2025-01-03 15:48:09 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 15:48:09 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 15:48:12 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2025-01-03 15:48:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2025-01-03 15:48:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2025-01-03 15:48:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-01-03 15:48:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-01-03 15:48:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-01-03 15:48:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-01-03 15:48:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-01-03 15:48:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-01-03 15:48:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-01-03 15:48:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-01-03 15:48:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-01-03 15:48:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:48:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:48:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:48:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:48:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-01-03 15:48:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-01-03 15:48:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-01-03 15:48:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:48:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:48:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-01-03 15:48:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:48:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:48:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:48:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:48:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-01-03 15:48:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-01-03 15:48:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-01-03 15:48:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:48:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:48:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-01-03 15:48:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:48:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:48:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:48:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:48:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-01-03 15:48:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-01-03 15:48:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-01-03 15:48:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:48:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:48:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-01-03 15:48:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:48:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:48:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:48:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:48:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-01-03 15:48:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-01-03 15:48:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-01-03 15:48:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:48:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:48:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-01-03 15:48:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:48:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 197
ERROR - 2025-01-03 15:48:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:48:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:48:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-01-03 15:48:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-01-03 15:48:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-01-03 15:48:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:48:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-01-03 15:48:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-01-03 15:48:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:48:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:48:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:48:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:48:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 15:51:38 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:51:38 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:51:38 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:51:38 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:51:38 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 15:51:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:51:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:51:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:51:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:51:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 15:52:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:52:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:52:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:52:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:52:06 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 15:52:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:52:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:52:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:52:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:52:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 15:52:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:52:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:52:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:52:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:52:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 15:58:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:58:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:58:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:58:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:58:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 15:58:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 15:58:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 15:58:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 15:58:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 15:58:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:04:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 16:04:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 16:04:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 16:04:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 16:04:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:04:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 16:04:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 16:04:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 16:04:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 16:04:40 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:04:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 16:04:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 16:04:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 16:04:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 16:04:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:06:04 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2025-01-03 16:06:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2025-01-03 16:06:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2025-01-03 16:06:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-01-03 16:06:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-01-03 16:06:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-01-03 16:06:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-01-03 16:06:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-01-03 16:06:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-01-03 16:06:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-01-03 16:06:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-01-03 16:06:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-01-03 16:06:08 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 16:06:08 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 16:06:08 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 16:06:08 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 16:06:08 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:06:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 16:06:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 16:06:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 16:06:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 16:06:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:21:59 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2025-01-03 16:21:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2025-01-03 16:21:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2025-01-03 16:21:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-01-03 16:21:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-01-03 16:21:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-01-03 16:21:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-01-03 16:21:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-01-03 16:21:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-01-03 16:21:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-01-03 16:21:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-01-03 16:21:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-01-03 16:22:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 16:22:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 16:22:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 16:22:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 16:22:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:22:05 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2025-01-03 16:22:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2025-01-03 16:22:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2025-01-03 16:22:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-01-03 16:22:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-01-03 16:22:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-01-03 16:22:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-01-03 16:22:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-01-03 16:22:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-01-03 16:22:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-01-03 16:22:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-01-03 16:22:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-01-03 16:22:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 16:22:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 145
ERROR - 2025-01-03 16:22:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 146
ERROR - 2025-01-03 16:22:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 16:22:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:22:18 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 16:22:21 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 16:22:23 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 16:22:25 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-01-03 16:22:25 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-01-03 16:22:25 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-01-03 16:22:25 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-01-03 16:22:25 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-01-03 16:22:25 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-01-03 16:22:25 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-01-03 16:22:25 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-01-03 16:22:25 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-01-03 16:22:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 16:22:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 16:22:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 16:22:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 16:22:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 16:22:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 16:22:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 16:22:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 16:22:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 16:22:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 16:22:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 16:22:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 16:22:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 16:22:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 16:22:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 16:22:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 16:22:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 16:22:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 16:22:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 16:22:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 16:22:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-03 16:22:26 --> 404 Page Not Found: Images/small
ERROR - 2025-01-03 16:22:34 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 16:22:34 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 16:22:35 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 16:22:35 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 16:22:57 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 16:22:57 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 16:22:59 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 16:22:59 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-03 16:30:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 98
ERROR - 2025-01-03 16:31:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 248
ERROR - 2025-01-03 16:31:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 249
ERROR - 2025-01-03 16:31:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 4 - Invalid query: SELECT *
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE materia IN()
ERROR - 2025-01-03 16:31:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 248
ERROR - 2025-01-03 16:31:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 249
ERROR - 2025-01-03 16:31:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 4 - Invalid query: SELECT *
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE materia IN()
ERROR - 2025-01-03 16:31:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 248
ERROR - 2025-01-03 16:31:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 249
ERROR - 2025-01-03 16:31:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 4 - Invalid query: SELECT *
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE materia IN()
ERROR - 2025-01-03 16:31:41 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 16:31:41 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 16:31:41 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:35:10 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 16:35:10 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 16:35:10 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:36:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 16:36:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 16:36:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:36:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 16:36:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 16:36:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:37:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 16:37:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 16:37:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:38:33 --> Severity: Notice --> Undefined index: es_correcta /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 154
ERROR - 2025-01-03 16:38:33 --> Severity: Notice --> Undefined index: es_correcta /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 154
ERROR - 2025-01-03 16:38:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 16:38:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 16:38:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:39:56 --> Severity: Notice --> Undefined offset: 2 /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 146
ERROR - 2025-01-03 16:39:56 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 146
ERROR - 2025-01-03 16:39:56 --> Severity: Notice --> Undefined offset: 2 /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 146
ERROR - 2025-01-03 16:39:56 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 146
ERROR - 2025-01-03 16:39:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 16:39:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 16:39:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:40:16 --> Severity: Notice --> Undefined offset: 2 /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 146
ERROR - 2025-01-03 16:40:16 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 146
ERROR - 2025-01-03 16:40:16 --> Severity: Notice --> Undefined offset: 2 /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 146
ERROR - 2025-01-03 16:40:16 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 146
ERROR - 2025-01-03 16:40:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 16:40:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 16:40:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:40:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 16:40:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 16:40:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:40:53 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 16:40:53 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 16:40:53 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:42:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 141
ERROR - 2025-01-03 16:42:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 148
ERROR - 2025-01-03 16:42:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:43:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 150
ERROR - 2025-01-03 16:43:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-01-03 16:43:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 158
ERROR - 2025-01-03 16:44:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 150
ERROR - 2025-01-03 16:44:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-01-03 16:44:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 158
ERROR - 2025-01-03 16:46:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:46:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-01-03 16:46:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-01-03 16:46:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:46:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-01-03 16:46:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-01-03 16:46:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:46:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-01-03 16:46:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-01-03 16:46:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:46:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-01-03 16:46:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-01-03 16:46:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:46:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-01-03 16:46:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-01-03 16:47:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:47:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-01-03 16:47:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-01-03 16:48:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:48:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-01-03 16:48:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-01-03 16:49:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:49:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-01-03 16:49:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-01-03 16:49:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:49:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-01-03 16:49:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-01-03 16:49:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:49:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-01-03 16:49:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-01-03 16:49:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:49:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-01-03 16:49:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-01-03 16:52:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:52:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-01-03 16:52:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-01-03 16:52:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:52:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-01-03 16:52:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-01-03 16:52:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-01-03 16:52:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-01-03 16:52:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-01-03 17:55:50 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 98
ERROR - 2025-01-03 17:55:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 256
ERROR - 2025-01-03 17:55:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 257
ERROR - 2025-01-03 17:55:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 4 - Invalid query: SELECT *
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE materia IN()
