<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-11-21 16:51:12 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-21 16:51:12 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-21 16:51:12 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-21 16:51:12 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-21 16:51:12 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-11-21 16:51:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 16:51:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 16:51:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 16:51:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 16:51:12 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 16:51:13 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 16:51:13 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 16:51:13 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 16:51:13 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 16:51:13 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 16:51:13 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 16:51:13 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 16:51:13 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 16:51:13 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 16:51:13 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 16:51:13 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 16:51:13 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 16:51:13 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 16:51:13 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 16:51:13 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 16:51:13 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 16:51:14 --> 404 Page Not Found: Images/small
ERROR - 2024-11-21 16:51:19 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-21 16:51:19 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-21 16:51:19 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-21 16:51:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-21 16:51:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-21 16:51:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-21 16:51:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-21 16:51:23 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-21 16:51:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-21 16:52:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 39
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 40
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 39
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 40
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-21 16:52:21 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-21 16:52:21 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-21 16:52:21 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-21 16:52:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-21 16:52:21 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-21 16:52:21 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-21 16:52:21 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-21 16:52:21 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-21 16:53:40 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-21 16:53:40 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-21 16:53:40 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-21 16:53:40 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-21 16:53:40 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-21 16:53:40 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-21 16:53:40 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-21 16:53:40 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-21 16:53:40 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-21 16:53:40 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-21 16:53:40 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-21 16:53:40 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-21 16:53:40 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-21 16:53:40 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-21 16:53:40 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-21 16:53:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-21 16:53:41 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-21 16:53:41 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-21 16:53:41 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-21 16:53:41 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-21 16:53:41 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-21 16:53:41 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-21 16:53:41 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-21 16:53:41 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-21 16:53:41 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-21 16:53:41 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-21 16:53:41 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-21 16:53:41 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-21 16:53:41 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-21 16:53:41 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-21 16:53:41 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-21 17:28:29 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-21 17:28:32 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-21 17:28:33 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-21 17:28:34 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-21 17:28:34 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-21 17:28:34 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-21 17:28:34 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-21 17:28:34 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-21 17:28:34 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-21 17:28:34 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-21 17:28:34 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-21 17:28:34 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-21 17:28:34 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-21 17:28:34 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-21 17:28:34 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-21 17:28:34 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-21 17:28:34 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-21 17:28:34 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-21 17:28:34 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-21 17:28:34 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-21 17:28:34 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-11-21 17:28:34 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-11-21 17:28:34 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-21 17:28:34 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-11-21 17:28:34 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-21 17:28:34 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-11-21 17:28:34 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-11-21 17:28:34 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-21 17:28:34 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-11-21 17:28:34 --> Severity: Notice --> Undefined variable: recuperacion /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-21 17:28:34 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-11-21 17:28:34 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-11-21 17:28:34 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-21 17:28:34 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-11-21 17:35:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-21 17:35:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-21 17:35:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-21 17:35:49 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-21 17:35:49 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-21 17:35:49 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-21 17:35:49 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-21 17:35:49 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-21 17:35:49 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-21 17:35:49 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-21 17:35:49 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-21 17:35:49 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-11-21 17:35:49 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:35:49 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:35:49 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:35:49 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:35:49 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:35:49 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:35:49 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:35:49 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:35:49 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:35:49 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:35:49 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:35:49 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:35:49 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:35:49 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:35:49 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:35:49 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:35:49 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:35:49 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:35:49 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:35:49 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:35:49 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:35:50 --> 404 Page Not Found: Images/small
ERROR - 2024-11-21 17:36:01 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-21 17:36:01 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-21 17:36:01 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.m.codmateria' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: Select * from cfg_areas a left join cfg_materias m on a.codarea = m.area join asg_materias am on am.materia = m.codmateria where m.grado = '11' and am.grupo = 'A' group by a.codarea
ERROR - 2024-11-21 17:36:04 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-21 17:36:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-21 17:37:10 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-21 17:37:10 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.m.codmateria' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: Select * from cfg_areas a left join cfg_materias m on a.codarea = m.area join asg_materias am on am.materia = m.codmateria where m.grado = '11' and am.grupo = 'A' group by a.codarea
ERROR - 2024-11-21 17:37:14 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-21 17:37:14 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-11-21 17:37:14 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-21 17:37:14 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-11-21 17:37:14 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-21 17:37:14 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-11-21 17:37:14 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-21 17:37:14 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-11-21 17:37:14 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-11-21 17:37:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:37:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:37:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:37:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:37:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:37:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:37:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:37:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:37:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:37:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:37:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:37:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:37:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:37:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:37:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:37:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:37:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:37:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:37:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:37:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:37:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-11-21 17:37:15 --> 404 Page Not Found: Images/small
ERROR - 2024-11-21 17:37:38 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-21 17:37:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-11-21 17:37:40 --> 404 Page Not Found: Img/iconos
