<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-02-04 18:10:16 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-04 18:10:16 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-04 18:10:16 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-04 18:10:16 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-04 18:10:16 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-02-04 18:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:10:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:10:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:10:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:10:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:10:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:10:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:10:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:10:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:10:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:10:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:10:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:10:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:10:18 --> 404 Page Not Found: Images/small
ERROR - 2025-02-04 18:10:25 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-04 18:10:26 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-04 18:16:17 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-04 18:17:07 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-04 18:17:07 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-04 18:17:07 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-04 18:17:07 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-04 18:17:07 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-04 18:17:07 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-04 18:17:07 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-04 18:17:07 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-04 18:17:08 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-02-04 18:17:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:17:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:17:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:17:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:17:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:17:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:17:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:17:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:17:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:17:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:17:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:17:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:17:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:17:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:17:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:17:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:17:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:17:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:17:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:17:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:17:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:17:10 --> 404 Page Not Found: Images/small
ERROR - 2025-02-04 18:17:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:17:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:17:14 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:17:14 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:17:19 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.u.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `u`.*, `e`.*, `e`.`email` as `email`, `cer`.`id_pregunta`
FROM `estudiante` `e`
LEFT JOIN `usuarios` `u` ON `e`.`documento` = `u`.`id`
LEFT OUTER JOIN `caracterizacion_estudiantes_respuestas` `cer` ON `cer`.`id_estudiante` = `u`.`id`
GROUP BY `e`.`documento`
ORDER BY `e`.`grado` ASC, `e`.`nombre` ASC
ERROR - 2025-02-04 18:17:56 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.u.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `u`.*, `e`.*, `e`.`email` as `email`, `cer`.`id_pregunta`
FROM `estudiante` `e`
LEFT JOIN `usuarios` `u` ON `e`.`documento` = `u`.`id`
LEFT OUTER JOIN `caracterizacion_estudiantes_respuestas` `cer` ON `cer`.`id_estudiante` = `u`.`id`
GROUP BY `e`.`documento`
ORDER BY `e`.`grado` ASC, `e`.`nombre` ASC
ERROR - 2025-02-04 18:17:59 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.u.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `u`.*, `e`.*, `e`.`email` as `email`, `cer`.`id_pregunta`
FROM `estudiante` `e`
LEFT JOIN `usuarios` `u` ON `e`.`documento` = `u`.`id`
LEFT OUTER JOIN `caracterizacion_estudiantes_respuestas` `cer` ON `cer`.`id_estudiante` = `u`.`id`
GROUP BY `e`.`documento`
ORDER BY `e`.`grado` ASC, `e`.`nombre` ASC
ERROR - 2025-02-04 18:18:08 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-02-04 18:18:35 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-02-04 18:18:38 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-02-04 18:18:46 --> 404 Page Not Found: Estudiante/index.php
ERROR - 2025-02-04 18:18:50 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-04 18:18:50 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-04 18:18:50 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-04 18:18:50 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-04 18:18:50 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-02-04 18:18:50 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-04 18:18:52 --> 404 Page Not Found: Images/small
ERROR - 2025-02-04 18:18:59 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-04 18:19:00 --> 404 Page Not Found: Img/iconos
