<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-09-26 11:23:14 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-09-26 11:23:14 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-09-26 11:23:14 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-09-26 11:23:14 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-09-26 11:23:14 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-09-26 11:23:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 11:23:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 11:23:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 11:23:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 11:23:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 11:23:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 11:23:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 11:23:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 11:23:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 11:23:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 11:23:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 11:23:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 11:23:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 11:23:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 11:23:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 11:23:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 11:23:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 11:23:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 11:23:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 11:23:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 11:23:14 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 11:23:16 --> 404 Page Not Found: Images/small
ERROR - 2024-09-26 11:23:28 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:23:28 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:23:28 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:23:29 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:23:30 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:23:30 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:23:36 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.am.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT *
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE `am`.`docente` = '12345'
GROUP BY `am`.`materia`
ERROR - 2024-09-26 11:29:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:29:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:29:36 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-26 11:29:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:29:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:29:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:29:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:44:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:44:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:49:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:49:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:50:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:50:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:50:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:50:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:51:06 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:51:06 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:51:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:51:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:51:37 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:51:37 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:51:58 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:51:58 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:52:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 11:52:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:06:43 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-09-26 14:06:43 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-09-26 14:06:43 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-09-26 14:06:43 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-09-26 14:06:43 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-09-26 14:06:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:06:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:06:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:06:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:06:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:06:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:06:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:06:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:06:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:06:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:06:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:06:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:06:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:06:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:06:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:06:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:06:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:06:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:06:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:06:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:06:43 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:06:44 --> 404 Page Not Found: Images/small
ERROR - 2024-09-26 14:06:51 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:06:51 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:06:51 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:06:51 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:10:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:10:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:11:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:11:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:11:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:11:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:11:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:11:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:12:22 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:12:22 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:13:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:13:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:13:20 --> Severity: Notice --> Undefined index: es_recuperacion /Applications/MAMP/htdocs/integratic/application/controllers/Actividades.php 32
ERROR - 2024-09-26 14:13:26 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-09-26 14:13:26 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-09-26 14:13:34 --> Severity: Notice --> Undefined index: es_recuperacion /Applications/MAMP/htdocs/integratic/application/controllers/Actividades.php 32
ERROR - 2024-09-26 14:13:52 --> Severity: Notice --> Undefined index: es_recuperacion /Applications/MAMP/htdocs/integratic/application/controllers/Actividades.php 32
ERROR - 2024-09-26 14:14:20 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-09-26 14:14:20 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-09-26 14:14:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:14:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:17:29 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-09-26 14:17:29 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-09-26 14:17:30 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-09-26 14:17:30 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-09-26 14:17:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:17:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:21:58 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-09-26 14:21:58 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-09-26 14:21:58 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-09-26 14:21:58 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-09-26 14:21:59 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-09-26 14:21:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:21:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:21:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:21:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:21:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:21:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:21:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:21:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:21:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:21:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:21:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:21:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:21:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:21:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:21:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:21:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:21:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:21:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:21:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:21:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:21:59 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 14:22:00 --> 404 Page Not Found: Images/small
ERROR - 2024-09-26 14:22:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:22:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:23:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:25:38 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:25:38 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:26:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:28:47 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-09-26 14:28:47 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-09-26 14:33:04 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:33:04 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:33:06 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:33:06 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:33:09 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:33:09 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:33:10 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:33:10 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:34:41 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:34:41 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:34:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:34:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:34:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:34:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:35:24 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:35:24 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:39:06 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:39:06 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:44:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:44:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:44:28 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:44:28 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:45:26 --> Severity: Notice --> Undefined index: titulo /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/view.php 36
ERROR - 2024-09-26 14:45:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:45:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:45:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:45:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:45:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:45:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:45:55 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:45:55 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:46:30 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:46:30 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:46:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:46:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:48:02 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:48:02 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:48:13 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:48:13 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:48:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:48:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:48:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:48:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:48:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:48:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:53:56 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:53:56 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:54:17 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:54:17 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:54:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:54:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:55:06 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:55:06 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:55:24 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 14:55:24 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 15:04:48 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 18
ERROR - 2024-09-26 15:04:48 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 19
ERROR - 2024-09-26 15:04:48 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 19
ERROR - 2024-09-26 15:04:48 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 15:04:48 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 15:04:52 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-09-26 15:04:52 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-09-26 15:06:33 --> Severity: Notice --> Undefined property: Recuperaciones::$Actividades_Model /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 60
ERROR - 2024-09-26 15:06:33 --> Severity: error --> Exception: Call to a member function getActivitiesRecuperaciones() on null /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 60
ERROR - 2024-09-26 15:06:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 15:06:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 15:06:44 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-09-26 15:06:44 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-09-26 15:08:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 15:08:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 15:54:01 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 15:54:01 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 15:54:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 15:54:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 15:54:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 15:54:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 15:54:09 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 15:54:09 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 15:57:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 15:57:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 15:57:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 15:57:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 15:57:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 15:57:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:01:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:01:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:01:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:01:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:01:51 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:01:51 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:02:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:02:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:02:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:02:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:03:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:03:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:03:16 --> 404 Page Not Found: Recuperaciones/asignar_actividad_recuperacion
ERROR - 2024-09-26 16:13:32 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-09-26 16:13:32 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-09-26 16:13:32 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-09-26 16:13:32 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-09-26 16:13:32 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-09-26 16:13:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 16:13:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 16:13:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 16:13:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 16:13:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 16:13:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 16:13:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 16:13:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 16:13:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 16:13:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 16:13:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 16:13:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 16:13:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 16:13:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 16:13:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 16:13:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 16:13:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 16:13:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 16:13:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 16:13:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 16:13:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-26 16:13:34 --> 404 Page Not Found: Images/small
ERROR - 2024-09-26 16:13:41 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:13:41 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:13:41 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:13:41 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:13:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:13:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:13:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:13:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:18:45 --> Severity: error --> Exception: syntax error, unexpected '}' /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 78
ERROR - 2024-09-26 16:18:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:18:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:21:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:21:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:21:53 --> 404 Page Not Found: Recuperaciones/ver
ERROR - 2024-09-26 16:22:04 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:22:04 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:22:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:22:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:22:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:22:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:25:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:25:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:25:55 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:25:55 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:26:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:26:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:26:12 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:26:12 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:31:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:31:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:31:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:31:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:31:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:31:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:31:24 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:31:24 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:31:24 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-26 16:31:29 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:31:29 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:31:30 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-26 16:31:30 --> 404 Page Not Found: Img/iconos
