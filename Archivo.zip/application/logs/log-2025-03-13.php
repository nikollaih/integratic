<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-03-13 09:24:04 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-13 09:24:04 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-13 09:24:04 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-13 09:24:04 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-13 09:24:04 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-13 09:24:04 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 09:24:04 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 09:24:04 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 09:24:05 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 09:24:05 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 09:24:05 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 09:24:05 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 09:24:05 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 09:24:05 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 09:24:05 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 09:24:05 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 09:24:05 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 09:24:05 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 09:24:05 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 09:24:05 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 09:24:05 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 09:24:05 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 09:24:05 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 09:24:05 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 09:24:05 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 09:24:05 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 09:24:06 --> 404 Page Not Found: Images/small
ERROR - 2025-03-13 09:24:33 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-13 09:24:34 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-13 09:24:41 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.am.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT *
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE `am`.`docente` = '12345'
GROUP BY `am`.`materia`
ERROR - 2025-03-13 09:25:11 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-03-13 09:25:24 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-13 09:25:26 --> 404 Page Not Found: EstadisticasPruebas/index.php
ERROR - 2025-03-13 09:25:47 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-13 09:28:28 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-13 09:31:52 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-13 09:32:03 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-13 09:32:03 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-13 09:33:18 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-13 09:33:18 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-13 09:33:18 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-13 09:33:34 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-13 09:33:34 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-13 09:33:34 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-13 09:34:00 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-13 09:34:00 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-13 09:34:00 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-13 09:38:05 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-13 09:38:10 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-13 09:38:10 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-13 09:39:21 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-13 09:39:21 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-13 09:39:21 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-13 09:40:30 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-13 09:40:30 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-13 09:40:30 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-13 09:41:12 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-13 09:41:20 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 98
ERROR - 2025-03-13 09:41:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 256
ERROR - 2025-03-13 09:41:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 257
ERROR - 2025-03-13 09:41:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 4 - Invalid query: SELECT *
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE materia IN()
ERROR - 2025-03-13 10:05:28 --> Severity: Notice --> Undefined index: nommateria /Applications/MAMP/htdocs/integratic/application/views/pruebas/participantes.php 146
ERROR - 2025-03-13 10:05:28 --> Severity: Notice --> Undefined index: nommateria /Applications/MAMP/htdocs/integratic/application/views/pruebas/participantes.php 146
ERROR - 2025-03-13 10:05:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 256
ERROR - 2025-03-13 10:05:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 257
ERROR - 2025-03-13 10:05:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-13 10:05:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 256
ERROR - 2025-03-13 10:05:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 257
ERROR - 2025-03-13 10:05:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-13 10:09:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 256
ERROR - 2025-03-13 10:09:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 257
ERROR - 2025-03-13 10:09:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-13 17:54:55 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-13 17:54:55 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-13 17:54:55 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-13 17:54:55 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-13 17:54:55 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-13 17:54:56 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:54:56 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:54:56 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:54:56 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:54:56 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:54:56 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:54:56 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:54:56 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:54:56 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:54:56 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:54:56 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:54:56 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:54:56 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:54:56 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:54:56 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:54:56 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:54:56 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:54:56 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:54:56 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:54:56 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:54:56 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:54:57 --> 404 Page Not Found: Images/small
ERROR - 2025-03-13 17:55:03 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-13 17:55:04 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-13 17:55:09 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-03-13 17:55:39 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-03-13 17:57:30 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-13 17:57:32 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-13 17:57:32 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-13 17:57:32 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-13 17:57:32 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-13 17:57:32 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-13 17:57:32 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-13 17:57:32 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-13 17:57:32 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-13 17:57:33 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-13 17:57:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:57:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:57:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:57:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:57:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:57:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:57:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:57:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:57:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:57:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:57:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:57:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:57:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:57:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:57:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:57:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:57:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:57:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:57:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:57:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:57:33 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 17:57:34 --> 404 Page Not Found: Images/small
ERROR - 2025-03-13 17:57:37 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-13 17:57:37 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-13 17:57:48 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2025-03-13 17:57:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2025-03-13 17:57:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2025-03-13 17:57:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-03-13 17:57:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-03-13 17:57:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-03-13 17:57:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-03-13 17:57:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-03-13 17:57:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-03-13 17:57:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-03-13 17:57:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-03-13 17:57:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-03-13 17:57:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-13 17:57:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-13 17:57:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-13 17:57:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-13 17:57:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-13 18:18:31 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2025-03-13 18:18:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2025-03-13 18:18:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2025-03-13 18:18:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-03-13 18:18:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-03-13 18:18:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-03-13 18:18:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-03-13 18:18:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-03-13 18:18:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-03-13 18:18:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-03-13 18:18:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-03-13 18:18:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-03-13 18:18:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-13 18:18:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-13 18:18:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-13 18:18:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-13 18:18:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-13 18:19:44 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2025-03-13 18:19:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 119
ERROR - 2025-03-13 18:19:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 120
ERROR - 2025-03-13 18:19:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-03-13 18:19:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-03-13 18:19:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-03-13 18:19:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-03-13 18:19:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-03-13 18:19:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-03-13 18:19:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-03-13 18:19:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-03-13 18:19:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-03-13 18:19:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-13 18:19:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-13 18:19:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-13 18:19:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-13 18:19:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-03-13 18:19:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-03-13 18:19:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-03-13 18:19:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-13 18:19:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-13 18:19:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-03-13 18:20:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-13 18:20:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-13 18:20:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-13 18:20:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-13 18:20:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-03-13 18:20:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-03-13 18:20:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-03-13 18:20:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-13 18:20:10 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-13 18:20:10 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-03-13 18:20:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-13 18:20:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 205
ERROR - 2025-03-13 18:20:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-13 18:20:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-13 18:20:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 38
ERROR - 2025-03-13 18:20:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 42
ERROR - 2025-03-13 18:20:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 50
ERROR - 2025-03-13 18:20:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-13 18:20:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 54
ERROR - 2025-03-13 18:20:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/resumen_prueba.php 58
ERROR - 2025-03-13 18:20:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 149
ERROR - 2025-03-13 18:20:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 153
ERROR - 2025-03-13 18:20:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-03-13 18:20:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 156
ERROR - 2025-03-13 18:20:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 157
ERROR - 2025-03-13 18:21:07 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-13 18:21:09 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-13 18:21:09 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-13 18:21:09 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-13 18:21:09 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-13 18:21:09 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-13 18:21:09 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-13 18:21:09 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-13 18:21:09 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-13 18:21:09 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-13 18:21:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 18:21:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 18:21:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 18:21:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 18:21:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 18:21:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 18:21:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 18:21:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 18:21:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 18:21:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 18:21:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 18:21:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 18:21:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 18:21:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 18:21:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 18:21:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 18:21:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 18:21:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 18:21:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 18:21:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 18:21:09 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-13 18:21:10 --> 404 Page Not Found: Images/small
ERROR - 2025-03-13 18:21:17 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-13 18:21:17 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-13 18:21:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 98
ERROR - 2025-03-13 18:21:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 256
ERROR - 2025-03-13 18:21:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 257
ERROR - 2025-03-13 18:21:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-13 18:21:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 98
ERROR - 2025-03-13 18:21:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 256
ERROR - 2025-03-13 18:21:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 257
ERROR - 2025-03-13 18:21:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-13 18:22:35 --> 404 Page Not Found: Pruebas/index.php
