<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-04-01 17:52:07 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-04-01 17:52:07 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-04-01 17:52:07 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-04-01 17:52:07 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-04-01 17:52:08 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-04-01 17:52:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:08 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:09 --> 404 Page Not Found: Images/small
ERROR - 2025-04-01 17:52:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:17 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/ingresos/usuario.php 15
ERROR - 2025-04-01 17:52:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/ingresos/usuario.php 15
ERROR - 2025-04-01 17:52:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/ingresos/usuario.php 15
ERROR - 2025-04-01 17:52:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/ingresos/usuario.php 15
ERROR - 2025-04-01 17:52:45 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:45 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:48 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-04-01 17:52:48 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-04-01 17:52:48 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-04-01 17:52:48 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-04-01 17:52:48 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-04-01 17:52:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 17:52:49 --> 404 Page Not Found: Images/small
ERROR - 2025-04-01 17:53:52 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 132
ERROR - 2025-04-01 17:54:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 132
ERROR - 2025-04-01 17:54:25 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.rp.id_realizar_prueba' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT *
FROM `realizar_prueba` `rp`
JOIN `pruebas` `p` ON `p`.`id_prueba` = `rp`.`id_prueba`
JOIN `core_participantes_pruebas` `cpp` ON `rp`.`id_participante` = `cpp`.`id_participante_prueba`
LEFT JOIN `instituciones_educativas` `ie` ON `cpp`.`institucion` = `ie`.`id_institucion_educativa`
LEFT JOIN `municipios` `m` ON `m`.`id_municipio` = `ie`.`id_municipio`
WHERE `cpp`.`identificacion` = '54321'
AND (p.materias LIKE '%503%' )
AND `p`.`tipo_prueba` = 4
AND (p.temas LIKE '%1%' )
AND (p.temas LIKE '%3%' )
GROUP BY `p`.`id_prueba`
ERROR - 2025-04-01 17:58:03 --> 404 Page Not Found: EstadisticasPruebas/index.php
ERROR - 2025-04-01 18:05:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 132
ERROR - 2025-04-01 18:05:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 132
ERROR - 2025-04-01 18:05:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 132
ERROR - 2025-04-01 18:05:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 132
ERROR - 2025-04-01 18:05:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 132
ERROR - 2025-04-01 18:15:35 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-04-01 18:26:09 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-04-01 18:26:09 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-04-01 18:28:42 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-04-01 18:28:42 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-04-01 18:28:42 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-04-01 18:28:42 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-04-01 18:28:42 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-04-01 18:28:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:28:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:28:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:28:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:28:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:28:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:28:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:28:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:28:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:28:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:28:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:28:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:28:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:28:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:28:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:28:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:28:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:28:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:28:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:28:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:28:42 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:28:43 --> 404 Page Not Found: Images/small
ERROR - 2025-04-01 18:28:45 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:28:45 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:28:46 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:28:46 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:30:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/ingresos/usuario.php 15
ERROR - 2025-04-01 18:30:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/ingresos/usuario.php 15
ERROR - 2025-04-01 18:31:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/ingresos/usuario.php 15
ERROR - 2025-04-01 18:31:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/ingresos/usuario.php 15
ERROR - 2025-04-01 18:33:16 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-04-01 18:33:16 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-04-01 18:33:16 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-04-01 18:33:16 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-04-01 18:33:16 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-04-01 18:33:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:33:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:33:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:33:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:33:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:33:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:33:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:33:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:33:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:33:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:33:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:33:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:33:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:33:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:33:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:33:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:33:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:33:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:33:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:33:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:33:16 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:33:17 --> 404 Page Not Found: Images/small
ERROR - 2025-04-01 18:33:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 132
ERROR - 2025-04-01 18:33:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 132
ERROR - 2025-04-01 18:36:03 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2025-04-01 18:37:59 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-04-01 18:37:59 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-04-01 18:37:59 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-04-01 18:37:59 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-04-01 18:37:59 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-04-01 18:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:37:59 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:38:00 --> 404 Page Not Found: Images/small
ERROR - 2025-04-01 18:38:05 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2025-04-01 18:38:42 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-04-01 18:38:42 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-04-01 18:38:42 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-04-01 18:38:42 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-04-01 18:38:43 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-04-01 18:38:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:38:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:38:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:38:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:38:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:38:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:38:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:38:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:38:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:38:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:38:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:38:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:38:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:38:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:38:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:38:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:38:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:38:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:38:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:38:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:38:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:38:43 --> 404 Page Not Found: Images/small
ERROR - 2025-04-01 18:38:56 --> 404 Page Not Found: PlanAula/index.php
ERROR - 2025-04-01 18:44:53 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-04-01 18:44:54 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-04-01 18:45:33 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-04-01 18:45:48 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-04-01 18:46:27 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-04-01 18:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 132
ERROR - 2025-04-01 18:46:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 344
ERROR - 2025-04-01 18:46:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 345
ERROR - 2025-04-01 18:46:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 346
ERROR - 2025-04-01 18:46:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 347
ERROR - 2025-04-01 18:46:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 349
ERROR - 2025-04-01 18:46:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 349
ERROR - 2025-04-01 18:46:43 --> Severity: Notice --> Undefined variable: like_query /Applications/MAMP/htdocs/integratic/application/models/Preguntas_Model.php 72
ERROR - 2025-04-01 18:46:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC' at line 6 - Invalid query: SELECT *
FROM `preguntas_prueba` `pp`
JOIN `cfg_materias` `cm` ON `cm`.`codmateria` = `pp`.`id_materia`
JOIN `temas` `t` ON `pp`.`id_tema` = `t`.`id_tema`
WHERE `id_materia` IN(0)
AND  IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC
ERROR - 2025-04-01 18:46:47 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-04-01 18:47:19 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-04-01 18:47:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 132
ERROR - 2025-04-01 18:47:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 344
ERROR - 2025-04-01 18:47:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 345
ERROR - 2025-04-01 18:47:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 346
ERROR - 2025-04-01 18:47:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 347
ERROR - 2025-04-01 18:47:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 349
ERROR - 2025-04-01 18:47:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 349
ERROR - 2025-04-01 18:47:31 --> Severity: Notice --> Undefined variable: like_query /Applications/MAMP/htdocs/integratic/application/models/Preguntas_Model.php 72
ERROR - 2025-04-01 18:47:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC' at line 6 - Invalid query: SELECT *
FROM `preguntas_prueba` `pp`
JOIN `cfg_materias` `cm` ON `cm`.`codmateria` = `pp`.`id_materia`
JOIN `temas` `t` ON `pp`.`id_tema` = `t`.`id_tema`
WHERE `id_materia` IN(0)
AND  IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC
ERROR - 2025-04-01 18:47:45 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-04-01 18:47:45 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-04-01 18:47:45 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-04-01 18:47:45 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-04-01 18:47:45 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-04-01 18:47:45 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:45 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:45 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:45 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:45 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:45 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:45 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:45 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:45 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:45 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:45 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:45 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:45 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:45 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:45 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:45 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:45 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:45 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:45 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:45 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:45 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:46 --> 404 Page Not Found: Images/small
ERROR - 2025-04-01 18:47:57 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-04-01 18:47:57 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-04-01 18:47:57 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-04-01 18:47:57 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-04-01 18:47:57 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-04-01 18:47:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:57 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:47:58 --> 404 Page Not Found: Images/small
ERROR - 2025-04-01 18:48:07 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 132
ERROR - 2025-04-01 18:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 290
ERROR - 2025-04-01 18:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 291
ERROR - 2025-04-01 18:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 292
ERROR - 2025-04-01 18:48:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-04-01 18:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 290
ERROR - 2025-04-01 18:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 291
ERROR - 2025-04-01 18:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 292
ERROR - 2025-04-01 18:48:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-04-01 18:48:28 --> Severity: Notice --> Undefined index: asignacion_preguntas /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 114
ERROR - 2025-04-01 18:48:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 344
ERROR - 2025-04-01 18:48:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 345
ERROR - 2025-04-01 18:48:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 346
ERROR - 2025-04-01 18:48:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 347
ERROR - 2025-04-01 18:48:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 349
ERROR - 2025-04-01 18:48:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 349
ERROR - 2025-04-01 18:48:28 --> Severity: Notice --> Undefined variable: like_query /Applications/MAMP/htdocs/integratic/application/models/Preguntas_Model.php 72
ERROR - 2025-04-01 18:48:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC' at line 6 - Invalid query: SELECT *
FROM `preguntas_prueba` `pp`
JOIN `cfg_materias` `cm` ON `cm`.`codmateria` = `pp`.`id_materia`
JOIN `temas` `t` ON `pp`.`id_tema` = `t`.`id_tema`
WHERE `id_materia` IN(0)
AND  IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC
ERROR - 2025-04-01 18:48:53 --> Severity: Notice --> Undefined index: asignacion_preguntas /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 114
ERROR - 2025-04-01 18:48:53 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 344
ERROR - 2025-04-01 18:48:53 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 345
ERROR - 2025-04-01 18:48:53 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 346
ERROR - 2025-04-01 18:48:53 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 347
ERROR - 2025-04-01 18:48:53 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 349
ERROR - 2025-04-01 18:48:53 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 349
ERROR - 2025-04-01 18:48:53 --> Severity: Notice --> Undefined variable: like_query /Applications/MAMP/htdocs/integratic/application/models/Preguntas_Model.php 72
ERROR - 2025-04-01 18:48:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC' at line 6 - Invalid query: SELECT *
FROM `preguntas_prueba` `pp`
JOIN `cfg_materias` `cm` ON `cm`.`codmateria` = `pp`.`id_materia`
JOIN `temas` `t` ON `pp`.`id_tema` = `t`.`id_tema`
WHERE `id_materia` IN(0)
AND  IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC
ERROR - 2025-04-01 18:48:58 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-04-01 18:48:58 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-04-01 18:48:58 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-04-01 18:48:58 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-04-01 18:48:58 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-04-01 18:48:58 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:48:58 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:48:58 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:48:58 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:48:58 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:48:58 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:48:58 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:48:58 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:48:58 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:48:58 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:48:58 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:48:58 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:48:58 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:48:58 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:48:58 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:48:58 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:48:58 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:48:58 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:48:58 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:48:58 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:48:58 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:48:59 --> 404 Page Not Found: Images/small
ERROR - 2025-04-01 18:49:05 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2025-04-01 18:49:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 154
ERROR - 2025-04-01 18:49:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 155
ERROR - 2025-04-01 18:49:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-04-01 18:49:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-04-01 18:49:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-04-01 18:49:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-04-01 18:49:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-04-01 18:49:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-04-01 18:49:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-04-01 18:49:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-04-01 18:49:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-04-01 18:49:07 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 239
ERROR - 2025-04-01 18:49:07 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 239
ERROR - 2025-04-01 18:49:07 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 184
ERROR - 2025-04-01 18:49:07 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 188
ERROR - 2025-04-01 18:49:07 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 189
ERROR - 2025-04-01 18:49:07 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 191
ERROR - 2025-04-01 18:49:07 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 192
ERROR - 2025-04-01 18:49:11 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 239
ERROR - 2025-04-01 18:49:11 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 239
ERROR - 2025-04-01 18:49:11 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 184
ERROR - 2025-04-01 18:49:11 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 188
ERROR - 2025-04-01 18:49:11 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 189
ERROR - 2025-04-01 18:49:11 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 191
ERROR - 2025-04-01 18:49:11 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 192
ERROR - 2025-04-01 18:49:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 184
ERROR - 2025-04-01 18:49:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 188
ERROR - 2025-04-01 18:49:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 189
ERROR - 2025-04-01 18:49:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 191
ERROR - 2025-04-01 18:49:22 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 192
ERROR - 2025-04-01 18:49:48 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-04-01 18:49:48 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-04-01 18:49:48 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-04-01 18:49:48 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-04-01 18:49:48 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-04-01 18:49:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:49:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:49:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:49:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:49:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:49:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:49:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:49:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:49:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:49:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:49:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:49:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:49:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:49:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:49:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:49:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:49:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:49:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:49:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:49:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:49:48 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-01 18:49:49 --> 404 Page Not Found: Images/small
ERROR - 2025-04-01 18:49:58 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 132
ERROR - 2025-04-01 18:50:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 290
ERROR - 2025-04-01 18:50:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 291
ERROR - 2025-04-01 18:50:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 292
ERROR - 2025-04-01 18:50:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-04-01 18:50:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 184
ERROR - 2025-04-01 18:50:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 191
ERROR - 2025-04-01 18:50:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 192
ERROR - 2025-04-01 18:50:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 184
ERROR - 2025-04-01 18:50:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 191
ERROR - 2025-04-01 18:50:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 192
ERROR - 2025-04-01 18:50:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 184
ERROR - 2025-04-01 18:50:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 191
ERROR - 2025-04-01 18:50:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 192
