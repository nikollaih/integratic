<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-02-07 14:49:44 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-07 14:49:44 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-07 14:49:44 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-07 14:49:44 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-07 14:49:44 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-02-07 14:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 14:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 14:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 14:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 14:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 14:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 14:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 14:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 14:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 14:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 14:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 14:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 14:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 14:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 14:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 14:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 14:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 14:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 14:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 14:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 14:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 14:49:50 --> 404 Page Not Found: Images/small
ERROR - 2025-02-07 14:49:58 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-07 14:49:58 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-07 15:19:34 --> Severity: Warning --> require_once(templates/piar_form): failed to open stream: No such file or directory /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 22
ERROR - 2025-02-07 15:19:34 --> Severity: Compile Error --> require_once(): Failed opening required 'templates/piar_form' (include_path='.:/Applications/MAMP/bin/php/php7.4.33/lib/php') /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 22
ERROR - 2025-02-07 15:19:49 --> Severity: Warning --> require_once(./templates/piar_form): failed to open stream: No such file or directory /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 22
ERROR - 2025-02-07 15:19:49 --> Severity: Compile Error --> require_once(): Failed opening required './templates/piar_form' (include_path='.:/Applications/MAMP/bin/php/php7.4.33/lib/php') /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 22
ERROR - 2025-02-07 15:20:05 --> Severity: Warning --> require_once(index): failed to open stream: No such file or directory /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 22
ERROR - 2025-02-07 15:20:05 --> Severity: Compile Error --> require_once(): Failed opening required 'index' (include_path='.:/Applications/MAMP/bin/php/php7.4.33/lib/php') /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 22
ERROR - 2025-02-07 15:20:18 --> Severity: Notice --> Undefined variable: piar /Applications/MAMP/htdocs/integratic/application/views/piar/view.php 24
ERROR - 2025-02-07 15:20:18 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/piar/view.php 24
ERROR - 2025-02-07 15:20:18 --> Severity: Notice --> Undefined index: nombres /Applications/MAMP/htdocs/integratic/application/views/piar/view.php 39
ERROR - 2025-02-07 15:20:18 --> Severity: Notice --> Undefined index: apellidos /Applications/MAMP/htdocs/integratic/application/views/piar/view.php 40
ERROR - 2025-02-07 15:20:18 --> Severity: Notice --> Undefined variable: preguntas /Applications/MAMP/htdocs/integratic/application/views/piar/view.php 44
ERROR - 2025-02-07 15:20:18 --> Severity: Notice --> Undefined variable: respuestas /Applications/MAMP/htdocs/integratic/application/views/piar/view.php 44
ERROR - 2025-02-07 15:20:18 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 94
ERROR - 2025-02-07 15:20:18 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 72
ERROR - 2025-02-07 15:20:18 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 72
ERROR - 2025-02-07 15:20:18 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 84
ERROR - 2025-02-07 15:20:18 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /Applications/MAMP/htdocs/integratic/application/helpers/caracterizacion_estudiantes_helper.php 74
ERROR - 2025-02-07 15:20:18 --> Severity: error --> Exception: DateTime::__construct(): Failed to parse time string (No completo) at position 0 (N): The timezone could not be found in the database /Applications/MAMP/htdocs/integratic/application/helpers/general_helper.php 152
ERROR - 2025-02-07 15:27:26 --> Severity: Notice --> Undefined variable: piar /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 56
ERROR - 2025-02-07 15:44:12 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-07 15:44:12 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-07 15:45:07 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-07 15:45:07 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-07 15:46:14 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-07 15:46:14 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-07 15:46:41 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-07 15:46:41 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-07 15:47:09 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-07 15:47:09 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-07 15:47:54 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-07 15:47:54 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-07 15:48:21 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-07 15:48:21 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-07 15:48:33 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-07 15:48:33 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-07 15:50:19 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-07 15:50:19 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-07 15:50:28 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-07 15:50:28 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-07 15:55:31 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-07 15:55:31 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-07 15:55:45 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-07 15:55:45 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-07 16:49:47 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-07 16:49:47 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-07 16:49:53 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-02-07 16:49:53 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-02-07 16:49:53 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-02-07 16:49:53 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-02-07 16:49:54 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-02-07 16:49:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 16:49:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 16:49:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 16:49:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 16:49:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 16:49:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 16:49:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 16:49:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 16:49:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 16:49:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 16:49:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 16:49:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 16:49:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 16:49:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 16:49:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 16:49:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 16:49:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 16:49:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 16:49:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 16:49:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 16:49:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-02-07 16:49:55 --> 404 Page Not Found: Images/small
ERROR - 2025-02-07 16:50:03 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-07 16:50:03 --> 404 Page Not Found: Img/iconos
ERROR - 2025-02-07 16:50:23 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-02-07 16:50:23 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-02-07 16:55:22 --> Severity: Notice --> Undefined index: ultimo_grado_cursado_observaciones /Applications/MAMP/htdocs/integratic/application/views/piar/templates/piar_form.php 329
ERROR - 2025-02-07 17:24:21 --> Severity: Notice --> Undefined index: es_bajo_proteccion /Applications/MAMP/htdocs/integratic/application/views/piar/view.php 152
ERROR - 2025-02-07 17:27:20 --> Severity: Notice --> Undefined index: es_vinculado_otra_institucion /Applications/MAMP/htdocs/integratic/application/views/piar/view.php 166
ERROR - 2025-02-07 17:41:50 --> Severity: Notice --> Undefined index: distancia_institucion_hogar /Applications/MAMP/htdocs/integratic/application/views/piar/view.php 200
