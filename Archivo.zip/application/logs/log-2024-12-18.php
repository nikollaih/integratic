<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-12-18 14:16:14 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-12-18 14:16:14 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-12-18 14:16:14 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-12-18 14:16:14 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-12-18 14:16:15 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-12-18 14:16:15 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 14:16:15 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 14:16:15 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 14:16:15 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 14:16:15 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 14:16:15 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 14:16:15 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 14:16:15 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 14:16:15 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 14:16:15 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 14:16:15 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 14:16:15 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 14:16:15 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 14:16:15 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 14:16:15 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 14:16:15 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 14:16:15 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 14:16:15 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 14:16:15 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 14:16:15 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 14:16:15 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 14:16:29 --> 404 Page Not Found: Images/small
ERROR - 2024-12-18 14:16:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 14:16:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 14:16:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 14:16:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:06:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:06:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:06:09 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:06:09 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:06:14 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-12-18 15:06:14 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-12-18 15:06:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-12-18 15:06:14 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-12-18 15:06:14 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-12-18 15:06:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-12-18 15:06:14 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-12-18 15:06:14 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-12-18 15:06:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-12-18 15:06:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:06:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:06:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 5
ERROR - 2024-12-18 15:06:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 5
ERROR - 2024-12-18 15:06:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/helpers/recuperaciones_helper.php 22
ERROR - 2024-12-18 15:06:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-12-18 15:06:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-12-18 15:06:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 152
ERROR - 2024-12-18 15:06:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-12-18 15:06:14 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-12-18 15:06:14 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-12-18 15:06:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-12-18 15:06:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-12-18 15:06:14 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-12-18 15:06:14 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-12-18 15:06:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-12-18 15:06:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-12-18 15:06:14 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-12-18 15:06:14 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-12-18 15:06:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-12-18 15:08:21 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-12-18 15:08:21 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-12-18 15:08:21 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-12-18 15:08:21 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-12-18 15:08:21 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-12-18 15:08:21 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-12-18 15:08:21 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-12-18 15:08:21 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-12-18 15:08:21 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-12-18 15:08:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:08:21 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:08:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 5
ERROR - 2024-12-18 15:08:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 5
ERROR - 2024-12-18 15:08:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/helpers/recuperaciones_helper.php 22
ERROR - 2024-12-18 15:08:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-12-18 15:08:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-12-18 15:08:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 152
ERROR - 2024-12-18 15:08:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-12-18 15:08:21 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-12-18 15:08:21 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-12-18 15:08:21 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-12-18 15:08:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-12-18 15:08:21 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-12-18 15:08:21 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-12-18 15:08:21 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-12-18 15:08:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-12-18 15:08:21 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-12-18 15:08:21 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-12-18 15:08:21 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-12-18 15:10:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:10:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:10:16 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-12-18 15:10:16 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-12-18 15:10:16 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-12-18 15:10:16 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-12-18 15:10:16 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-12-18 15:10:16 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-12-18 15:10:16 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-12-18 15:10:16 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-12-18 15:10:16 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-12-18 15:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:10:16 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:10:17 --> 404 Page Not Found: Images/small
ERROR - 2024-12-18 15:10:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:10:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:10:20 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.m.codmateria' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: Select * from cfg_areas a left join cfg_materias m on a.codarea = m.area join asg_materias am on am.materia = m.codmateria where m.grado = '11' and am.grupo = 'A' group by a.codarea
ERROR - 2024-12-18 15:10:25 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.m.codmateria' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: Select * from cfg_areas a left join cfg_materias m on a.codarea = m.area join asg_materias am on am.materia = m.codmateria where m.grado = '11' and am.grupo = 'A' group by a.codarea
ERROR - 2024-12-18 15:10:28 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:10:29 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:10:34 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-12-18 15:10:34 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-12-18 15:10:34 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-12-18 15:10:34 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-12-18 15:10:34 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-12-18 15:10:34 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-12-18 15:10:34 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-12-18 15:10:34 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-12-18 15:10:34 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-12-18 15:10:34 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:10:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 5
ERROR - 2024-12-18 15:10:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 5
ERROR - 2024-12-18 15:10:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/helpers/recuperaciones_helper.php 22
ERROR - 2024-12-18 15:10:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-12-18 15:10:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 11
ERROR - 2024-12-18 15:10:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/estudiante/view.php 114
ERROR - 2024-12-18 15:10:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 13
ERROR - 2024-12-18 15:10:35 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 20
ERROR - 2024-12-18 15:10:35 --> Severity: Notice --> Undefined variable: actividades_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-12-18 15:10:35 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_actividad_recuperacion.php 21
ERROR - 2024-12-18 15:10:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 13
ERROR - 2024-12-18 15:10:35 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 20
ERROR - 2024-12-18 15:10:35 --> Severity: Notice --> Undefined variable: pruebas_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-12-18 15:10:35 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_prueba_recuperacion.php 21
ERROR - 2024-12-18 15:10:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 13
ERROR - 2024-12-18 15:10:35 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 20
ERROR - 2024-12-18 15:10:35 --> Severity: Notice --> Undefined variable: estudiantes_disponibles /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-12-18 15:10:35 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 21
ERROR - 2024-12-18 15:47:30 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-12-18 15:47:32 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:47:32 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.m.codmateria' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: Select * from cfg_areas a left join cfg_materias m on a.codarea = m.area join asg_materias am on am.materia = m.codmateria where m.grado = '11' and am.grupo = 'A' group by a.codarea
ERROR - 2024-12-18 15:47:35 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-12-18 15:47:35 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-12-18 15:47:35 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-12-18 15:47:35 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-12-18 15:47:35 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-12-18 15:47:35 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-12-18 15:47:35 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-12-18 15:47:35 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-12-18 15:47:35 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-12-18 15:47:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:47:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:47:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:47:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:47:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:47:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:47:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:47:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:47:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:47:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:47:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:47:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:47:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:47:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:47:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:47:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:47:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:47:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:47:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:47:36 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:47:36 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-18 15:47:37 --> 404 Page Not Found: Images/small
ERROR - 2024-12-18 15:47:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:47:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:47:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:47:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:48:30 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.cm.codmateria' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT *
FROM `cfg_areas` `ca`
JOIN `cfg_materias` `cm` ON `ca`.`codarea` = `cm`.`area`
JOIN `asg_materias` `am` ON `am`.`materia` = `cm`.`codmateria`
WHERE `am`.`docente` = '12345'
GROUP BY `ca`.`codarea`
ERROR - 2024-12-18 15:48:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:48:57 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:49:02 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:49:02 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:49:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:49:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:49:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 98
ERROR - 2024-12-18 15:49:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 237
ERROR - 2024-12-18 15:49:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 238
ERROR - 2024-12-18 15:49:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 4 - Invalid query: SELECT *
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE materia IN()
ERROR - 2024-12-18 15:50:08 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:50:08 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:50:38 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:50:38 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:50:56 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:50:56 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:50:56 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:50:56 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:51:24 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:51:24 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:51:48 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:51:48 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:52:12 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:52:12 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:53:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:53:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:53:25 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-18 15:53:25 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-18 15:54:00 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-18 15:54:00 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-18 15:54:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:54:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:54:38 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:54:38 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:55:55 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:55:55 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:56:33 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:56:33 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:56:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:56:44 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:57:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:57:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:58:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 15:58:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 16:00:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 16:00:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 16:01:16 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-18 16:01:16 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-18 16:02:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 16:02:52 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 16:03:02 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-18 16:03:02 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-18 16:05:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 16:05:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 16:06:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 16:06:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 16:07:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 16:07:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 16:07:48 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 16:07:48 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 16:07:59 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-18 16:07:59 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-18 16:09:35 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-18 16:09:35 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-18 16:09:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 16:09:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 16:11:16 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-18 16:11:16 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-18 16:11:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-18 16:11:16 --> 404 Page Not Found: Img/iconos
