<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-03-20 09:22:36 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-20 09:22:36 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-20 09:22:36 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-20 09:22:36 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-20 09:22:37 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-20 09:22:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 09:22:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 09:22:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 09:22:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 09:22:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 09:22:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 09:22:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 09:22:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 09:22:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 09:22:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 09:22:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 09:22:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 09:22:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 09:22:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 09:22:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 09:22:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 09:22:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 09:22:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 09:22:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 09:22:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 09:22:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 09:22:39 --> 404 Page Not Found: Images/small
ERROR - 2025-03-20 09:22:46 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-20 09:22:46 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-20 09:25:32 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.am.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT *
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE `am`.`docente` = '12345'
GROUP BY `am`.`materia`
ERROR - 2025-03-20 09:26:53 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 09:28:05 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 09:28:05 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 09:29:33 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 09:29:33 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 09:29:33 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 09:32:36 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 09:32:36 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 09:32:36 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 09:33:16 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 09:33:16 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 09:33:16 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 09:36:21 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 09:40:04 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 09:40:09 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 09:40:09 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 09:45:28 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 09:45:29 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 09:45:29 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 09:46:06 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 09:46:07 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 09:46:07 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 09:46:22 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 09:46:22 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 09:46:22 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 09:47:02 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 09:47:02 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 09:47:02 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 09:47:09 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 09:47:09 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 09:47:09 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 09:47:46 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 09:47:47 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 09:47:47 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 09:47:58 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 09:47:59 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 09:47:59 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 09:48:12 --> Severity: Notice --> Undefined variable: dba /Applications/MAMP/htdocs/integratic/application/views/temas/crear.php 50
ERROR - 2025-03-20 09:48:12 --> 404 Page Not Found: Temas/index.php
ERROR - 2025-03-20 09:48:23 --> Severity: Notice --> Undefined variable: dba /Applications/MAMP/htdocs/integratic/application/views/temas/crear.php 50
ERROR - 2025-03-20 09:48:23 --> 404 Page Not Found: Temas/index.php
ERROR - 2025-03-20 09:48:27 --> Severity: Notice --> Undefined variable: dba /Applications/MAMP/htdocs/integratic/application/views/temas/crear.php 50
ERROR - 2025-03-20 09:48:27 --> 404 Page Not Found: Temas/index.php
ERROR - 2025-03-20 09:48:42 --> Severity: Notice --> Undefined variable: dba /Applications/MAMP/htdocs/integratic/application/views/temas/crear.php 50
ERROR - 2025-03-20 09:48:42 --> 404 Page Not Found: Temas/index.php
ERROR - 2025-03-20 09:48:54 --> Severity: Notice --> Undefined variable: dba /Applications/MAMP/htdocs/integratic/application/views/temas/crear.php 50
ERROR - 2025-03-20 09:48:55 --> 404 Page Not Found: Temas/index.php
ERROR - 2025-03-20 09:49:02 --> Severity: Notice --> Undefined variable: dba /Applications/MAMP/htdocs/integratic/application/views/temas/crear.php 50
ERROR - 2025-03-20 09:49:02 --> 404 Page Not Found: Temas/index.php
ERROR - 2025-03-20 09:49:03 --> Severity: Notice --> Undefined variable: dba /Applications/MAMP/htdocs/integratic/application/views/temas/crear.php 50
ERROR - 2025-03-20 09:49:03 --> 404 Page Not Found: Temas/index.php
ERROR - 2025-03-20 09:49:08 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 09:49:13 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 09:49:13 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 09:51:56 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 09:52:00 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 09:52:00 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 09:52:32 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 09:52:32 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 09:52:32 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 09:55:03 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 09:55:03 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 09:55:04 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 10:55:53 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 10:55:53 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 10:55:56 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 135
ERROR - 2025-03-20 10:55:57 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 10:55:57 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 10:56:05 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 135
ERROR - 2025-03-20 10:57:37 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 136
ERROR - 2025-03-20 10:57:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 134
ERROR - 2025-03-20 10:57:37 --> Severity: Notice --> Undefined variable: x /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 10:57:55 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 136
ERROR - 2025-03-20 10:57:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 134
ERROR - 2025-03-20 10:57:55 --> Severity: Notice --> Undefined variable: x /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 10:58:28 --> Severity: Notice --> Undefined variable: x /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 10:58:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 134
ERROR - 2025-03-20 10:58:28 --> Severity: Notice --> Undefined variable: x /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 10:58:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 135
ERROR - 2025-03-20 10:59:20 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 135
ERROR - 2025-03-20 10:59:20 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 10:59:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 135
ERROR - 2025-03-20 10:59:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 10:59:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 135
ERROR - 2025-03-20 10:59:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 10:59:41 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 135
ERROR - 2025-03-20 10:59:41 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 10:59:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 135
ERROR - 2025-03-20 10:59:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 10:59:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 135
ERROR - 2025-03-20 10:59:54 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 10:59:57 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 135
ERROR - 2025-03-20 10:59:57 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 11:00:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 135
ERROR - 2025-03-20 11:00:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 11:00:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 135
ERROR - 2025-03-20 11:00:04 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 11:00:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 135
ERROR - 2025-03-20 11:00:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 11:02:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 81
ERROR - 2025-03-20 11:02:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 82
ERROR - 2025-03-20 11:02:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 135
ERROR - 2025-03-20 11:02:13 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 11:02:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 81
ERROR - 2025-03-20 11:02:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 82
ERROR - 2025-03-20 11:02:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 135
ERROR - 2025-03-20 11:02:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 11:03:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 135
ERROR - 2025-03-20 11:03:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 11:03:36 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 11:03:36 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 11:03:49 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 135
ERROR - 2025-03-20 11:03:49 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 11:03:49 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 11:03:50 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 11:04:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 135
ERROR - 2025-03-20 11:04:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 11:04:18 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 11:04:18 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 11:04:23 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 11:04:23 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 11:04:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 135
ERROR - 2025-03-20 11:04:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 11:04:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 135
ERROR - 2025-03-20 11:04:32 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 11:04:32 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 11:04:32 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 11:04:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 135
ERROR - 2025-03-20 11:04:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 11:04:36 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 11:04:37 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 11:05:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 135
ERROR - 2025-03-20 11:05:37 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 11:05:37 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 11:05:38 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 11:05:55 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 11:05:55 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 11:05:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 135
ERROR - 2025-03-20 11:05:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 11:05:56 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 11:06:21 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 11:06:21 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 11:06:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 135
ERROR - 2025-03-20 11:06:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 11:06:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 135
ERROR - 2025-03-20 11:06:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 11:06:51 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-03-20 11:06:55 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 11:07:10 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/models/Temas_Model.php 28
ERROR - 2025-03-20 11:07:10 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/models/Temas_Model.php 30
ERROR - 2025-03-20 11:07:10 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/models/Temas_Model.php 30
ERROR - 2025-03-20 11:07:16 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 11:07:16 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 11:07:22 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 11:07:23 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 11:07:23 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 11:07:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/models/Temas_Model.php 28
ERROR - 2025-03-20 11:07:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/models/Temas_Model.php 30
ERROR - 2025-03-20 11:07:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/models/Temas_Model.php 30
ERROR - 2025-03-20 11:08:07 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 11:08:07 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 11:08:07 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 11:08:45 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 11:08:45 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 11:08:45 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 11:08:54 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 11:08:54 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 11:08:59 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 11:08:59 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 11:08:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 109
ERROR - 2025-03-20 11:09:03 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 11:09:03 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 11:09:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 319
ERROR - 2025-03-20 11:09:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 320
ERROR - 2025-03-20 11:09:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 322
ERROR - 2025-03-20 11:09:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 322
ERROR - 2025-03-20 11:09:03 --> Severity: Notice --> Undefined variable: like_query /Applications/MAMP/htdocs/integratic/application/models/Preguntas_Model.php 71
ERROR - 2025-03-20 11:09:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC' at line 5 - Invalid query: SELECT *
FROM `preguntas_prueba` `pp`
JOIN `cfg_materias` `cm` ON `cm`.`codmateria` = `pp`.`id_materia`
WHERE `id_materia` IN(0)
AND  IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC
ERROR - 2025-03-20 11:11:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 319
ERROR - 2025-03-20 11:11:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 320
ERROR - 2025-03-20 11:11:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 321
ERROR - 2025-03-20 11:11:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 323
ERROR - 2025-03-20 11:11:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 323
ERROR - 2025-03-20 11:11:24 --> Severity: Notice --> Undefined variable: like_query /Applications/MAMP/htdocs/integratic/application/models/Preguntas_Model.php 71
ERROR - 2025-03-20 11:11:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC' at line 5 - Invalid query: SELECT *
FROM `preguntas_prueba` `pp`
JOIN `cfg_materias` `cm` ON `cm`.`codmateria` = `pp`.`id_materia`
WHERE `id_materia` IN(0)
AND  IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC
ERROR - 2025-03-20 11:11:24 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 11:11:24 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 11:11:51 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 11:11:51 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 11:11:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 319
ERROR - 2025-03-20 11:11:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 320
ERROR - 2025-03-20 11:11:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 321
ERROR - 2025-03-20 11:11:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 323
ERROR - 2025-03-20 11:11:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 323
ERROR - 2025-03-20 11:11:51 --> Severity: Notice --> Undefined variable: like_query /Applications/MAMP/htdocs/integratic/application/models/Preguntas_Model.php 71
ERROR - 2025-03-20 11:11:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC' at line 5 - Invalid query: SELECT *
FROM `preguntas_prueba` `pp`
JOIN `cfg_materias` `cm` ON `cm`.`codmateria` = `pp`.`id_materia`
WHERE `id_materia` IN(0)
AND  IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC
ERROR - 2025-03-20 11:14:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 322
ERROR - 2025-03-20 11:14:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 323
ERROR - 2025-03-20 11:14:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 324
ERROR - 2025-03-20 11:14:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 326
ERROR - 2025-03-20 11:14:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 326
ERROR - 2025-03-20 11:14:16 --> Severity: Notice --> Undefined variable: like_query /Applications/MAMP/htdocs/integratic/application/models/Preguntas_Model.php 71
ERROR - 2025-03-20 11:14:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC' at line 5 - Invalid query: SELECT *
FROM `preguntas_prueba` `pp`
JOIN `cfg_materias` `cm` ON `cm`.`codmateria` = `pp`.`id_materia`
WHERE `id_materia` IN(0)
AND  IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC
ERROR - 2025-03-20 11:14:18 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 112
ERROR - 2025-03-20 11:14:19 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 11:14:19 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 11:14:25 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 11:16:07 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 11:16:09 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 11:16:19 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 11:16:19 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 11:17:08 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 11:17:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 110
ERROR - 2025-03-20 11:17:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 320
ERROR - 2025-03-20 11:17:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 321
ERROR - 2025-03-20 11:17:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 322
ERROR - 2025-03-20 11:17:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 324
ERROR - 2025-03-20 11:17:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 324
ERROR - 2025-03-20 11:17:51 --> Severity: Notice --> Undefined variable: like_query /Applications/MAMP/htdocs/integratic/application/models/Preguntas_Model.php 71
ERROR - 2025-03-20 11:17:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC' at line 5 - Invalid query: SELECT *
FROM `preguntas_prueba` `pp`
JOIN `cfg_materias` `cm` ON `cm`.`codmateria` = `pp`.`id_materia`
WHERE `id_materia` IN(0)
AND  IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC
ERROR - 2025-03-20 11:18:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 320
ERROR - 2025-03-20 11:18:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 321
ERROR - 2025-03-20 11:18:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 322
ERROR - 2025-03-20 11:18:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 324
ERROR - 2025-03-20 11:18:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 324
ERROR - 2025-03-20 11:18:03 --> Severity: Notice --> Undefined variable: like_query /Applications/MAMP/htdocs/integratic/application/models/Preguntas_Model.php 71
ERROR - 2025-03-20 11:18:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC' at line 5 - Invalid query: SELECT *
FROM `preguntas_prueba` `pp`
JOIN `cfg_materias` `cm` ON `cm`.`codmateria` = `pp`.`id_materia`
WHERE `id_materia` IN(0)
AND  IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC
ERROR - 2025-03-20 11:18:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 320
ERROR - 2025-03-20 11:18:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 321
ERROR - 2025-03-20 11:18:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 322
ERROR - 2025-03-20 11:18:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 324
ERROR - 2025-03-20 11:18:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 324
ERROR - 2025-03-20 11:18:59 --> Severity: Notice --> Undefined variable: like_query /Applications/MAMP/htdocs/integratic/application/models/Preguntas_Model.php 72
ERROR - 2025-03-20 11:18:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC' at line 6 - Invalid query: SELECT *
FROM `preguntas_prueba` `pp`
JOIN `cfg_materias` `cm` ON `cm`.`codmateria` = `pp`.`id_materia`
JOIN `temas` `t` ON `pp`.`id_tema` = `t`.`id_tema`
WHERE `id_materia` IN(0)
AND  IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC
ERROR - 2025-03-20 11:19:18 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 320
ERROR - 2025-03-20 11:19:18 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 321
ERROR - 2025-03-20 11:19:18 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 322
ERROR - 2025-03-20 11:19:18 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 324
ERROR - 2025-03-20 11:19:18 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 324
ERROR - 2025-03-20 11:19:18 --> Severity: Notice --> Undefined variable: like_query /Applications/MAMP/htdocs/integratic/application/models/Preguntas_Model.php 72
ERROR - 2025-03-20 11:19:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC' at line 6 - Invalid query: SELECT *
FROM `preguntas_prueba` `pp`
JOIN `cfg_materias` `cm` ON `cm`.`codmateria` = `pp`.`id_materia`
JOIN `temas` `t` ON `pp`.`id_tema` = `t`.`id_tema`
WHERE `id_materia` IN(0)
AND  IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC
ERROR - 2025-03-20 11:20:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 135
ERROR - 2025-03-20 11:20:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 11:20:01 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-03-20 11:20:44 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 11:21:24 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 11:21:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 110
ERROR - 2025-03-20 11:21:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 320
ERROR - 2025-03-20 11:21:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 321
ERROR - 2025-03-20 11:21:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 322
ERROR - 2025-03-20 11:21:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 324
ERROR - 2025-03-20 11:21:33 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 324
ERROR - 2025-03-20 11:21:33 --> Severity: Notice --> Undefined variable: like_query /Applications/MAMP/htdocs/integratic/application/models/Preguntas_Model.php 72
ERROR - 2025-03-20 11:21:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC' at line 6 - Invalid query: SELECT *
FROM `preguntas_prueba` `pp`
JOIN `cfg_materias` `cm` ON `cm`.`codmateria` = `pp`.`id_materia`
JOIN `temas` `t` ON `pp`.`id_tema` = `t`.`id_tema`
WHERE `id_materia` IN(0)
AND  IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC
ERROR - 2025-03-20 11:22:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 110
ERROR - 2025-03-20 11:25:08 --> Severity: Notice --> Undefined property: Pruebas::$Temas_Model /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 113
ERROR - 2025-03-20 11:25:08 --> Severity: error --> Exception: Call to a member function getByIds() on null /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 113
ERROR - 2025-03-20 11:25:37 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-20 11:25:37 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-20 11:25:37 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-20 11:25:37 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-20 11:25:37 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-20 11:25:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 11:25:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 11:25:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 11:25:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 11:25:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 11:25:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 11:25:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 11:25:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 11:25:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 11:25:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 11:25:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 11:25:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 11:25:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 11:25:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 11:25:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 11:25:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 11:25:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 11:25:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 11:25:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 11:25:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 11:25:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 11:25:38 --> 404 Page Not Found: Images/small
ERROR - 2025-03-20 11:25:45 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-20 11:25:45 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-20 11:25:50 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 110
ERROR - 2025-03-20 11:25:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 321
ERROR - 2025-03-20 11:25:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 322
ERROR - 2025-03-20 11:25:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 323
ERROR - 2025-03-20 11:25:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 325
ERROR - 2025-03-20 11:25:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 325
ERROR - 2025-03-20 11:25:55 --> Severity: Notice --> Undefined variable: like_query /Applications/MAMP/htdocs/integratic/application/models/Preguntas_Model.php 72
ERROR - 2025-03-20 11:25:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC' at line 6 - Invalid query: SELECT *
FROM `preguntas_prueba` `pp`
JOIN `cfg_materias` `cm` ON `cm`.`codmateria` = `pp`.`id_materia`
JOIN `temas` `t` ON `pp`.`id_tema` = `t`.`id_tema`
WHERE `id_materia` IN(0)
AND  IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC
ERROR - 2025-03-20 11:26:35 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/integratic/system/database/DB_query_builder.php 815
ERROR - 2025-03-20 11:26:35 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `preguntas_prueba` `pp`
JOIN `cfg_materias` `cm` ON `cm`.`codmateria` = `pp`.`id_materia`
JOIN `temas` `t` ON `pp`.`id_tema` = `t`.`id_tema`
WHERE `id_materia` IN('503')
AND `pp`.`id_tema` IN(Array)
AND (`dificultad` LIKE '%1%' OR `dificultad` LIKE '%2%' OR `dificultad` LIKE '%3%')
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC
ERROR - 2025-03-20 11:27:14 --> Severity: Warning --> Illegal string offset 'nombre_tema' /Applications/MAMP/htdocs/integratic/application/views/pruebas/asignacion_preguntas.php 85
ERROR - 2025-03-20 11:27:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 321
ERROR - 2025-03-20 11:27:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 322
ERROR - 2025-03-20 11:27:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 323
ERROR - 2025-03-20 11:27:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 324
ERROR - 2025-03-20 11:27:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 326
ERROR - 2025-03-20 11:27:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 326
ERROR - 2025-03-20 11:27:14 --> Severity: Notice --> Undefined variable: like_query /Applications/MAMP/htdocs/integratic/application/models/Preguntas_Model.php 72
ERROR - 2025-03-20 11:27:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC' at line 6 - Invalid query: SELECT *
FROM `preguntas_prueba` `pp`
JOIN `cfg_materias` `cm` ON `cm`.`codmateria` = `pp`.`id_materia`
JOIN `temas` `t` ON `pp`.`id_tema` = `t`.`id_tema`
WHERE `id_materia` IN(0)
AND  IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC
ERROR - 2025-03-20 11:27:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 321
ERROR - 2025-03-20 11:27:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 322
ERROR - 2025-03-20 11:27:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 323
ERROR - 2025-03-20 11:27:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 324
ERROR - 2025-03-20 11:27:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 326
ERROR - 2025-03-20 11:27:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 326
ERROR - 2025-03-20 11:27:35 --> Severity: Notice --> Undefined variable: like_query /Applications/MAMP/htdocs/integratic/application/models/Preguntas_Model.php 72
ERROR - 2025-03-20 11:27:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC' at line 6 - Invalid query: SELECT *
FROM `preguntas_prueba` `pp`
JOIN `cfg_materias` `cm` ON `cm`.`codmateria` = `pp`.`id_materia`
JOIN `temas` `t` ON `pp`.`id_tema` = `t`.`id_tema`
WHERE `id_materia` IN(0)
AND  IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC
ERROR - 2025-03-20 11:27:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 110
ERROR - 2025-03-20 11:27:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 268
ERROR - 2025-03-20 11:27:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 269
ERROR - 2025-03-20 11:27:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-20 11:28:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 268
ERROR - 2025-03-20 11:28:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 269
ERROR - 2025-03-20 11:28:34 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 270
ERROR - 2025-03-20 11:28:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-20 11:28:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 268
ERROR - 2025-03-20 11:28:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 269
ERROR - 2025-03-20 11:28:48 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 270
ERROR - 2025-03-20 11:28:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-20 11:29:07 --> Severity: Notice --> Undefined index: asignacion_preguntas /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 92
ERROR - 2025-03-20 11:29:08 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 322
ERROR - 2025-03-20 11:29:08 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 323
ERROR - 2025-03-20 11:29:08 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 324
ERROR - 2025-03-20 11:29:08 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 325
ERROR - 2025-03-20 11:29:08 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 327
ERROR - 2025-03-20 11:29:08 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 327
ERROR - 2025-03-20 11:29:08 --> Severity: Notice --> Undefined variable: like_query /Applications/MAMP/htdocs/integratic/application/models/Preguntas_Model.php 72
ERROR - 2025-03-20 11:29:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC' at line 6 - Invalid query: SELECT *
FROM `preguntas_prueba` `pp`
JOIN `cfg_materias` `cm` ON `cm`.`codmateria` = `pp`.`id_materia`
JOIN `temas` `t` ON `pp`.`id_tema` = `t`.`id_tema`
WHERE `id_materia` IN(0)
AND  IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC
ERROR - 2025-03-20 11:29:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 135
ERROR - 2025-03-20 11:29:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 11:29:35 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-03-20 11:30:12 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/preguntas/crear_pregunta.php 183
ERROR - 2025-03-20 11:30:12 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-03-20 11:30:23 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-03-20 11:30:33 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-03-20 11:32:05 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 11:32:05 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 11:32:31 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 11:32:32 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-03-20 11:32:32 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 11:32:34 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 11:32:35 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 11:32:35 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-03-20 11:33:02 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 11:33:02 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 11:33:20 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 110
ERROR - 2025-03-20 11:33:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 322
ERROR - 2025-03-20 11:33:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 323
ERROR - 2025-03-20 11:33:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 324
ERROR - 2025-03-20 11:33:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 325
ERROR - 2025-03-20 11:33:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 327
ERROR - 2025-03-20 11:33:21 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 327
ERROR - 2025-03-20 11:33:21 --> Severity: Notice --> Undefined variable: like_query /Applications/MAMP/htdocs/integratic/application/models/Preguntas_Model.php 72
ERROR - 2025-03-20 11:33:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC' at line 6 - Invalid query: SELECT *
FROM `preguntas_prueba` `pp`
JOIN `cfg_materias` `cm` ON `cm`.`codmateria` = `pp`.`id_materia`
JOIN `temas` `t` ON `pp`.`id_tema` = `t`.`id_tema`
WHERE `id_materia` IN(0)
AND  IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC
ERROR - 2025-03-20 11:33:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 110
ERROR - 2025-03-20 11:33:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 322
ERROR - 2025-03-20 11:33:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 323
ERROR - 2025-03-20 11:33:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 324
ERROR - 2025-03-20 11:33:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 325
ERROR - 2025-03-20 11:33:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 327
ERROR - 2025-03-20 11:33:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 327
ERROR - 2025-03-20 11:33:26 --> Severity: Notice --> Undefined variable: like_query /Applications/MAMP/htdocs/integratic/application/models/Preguntas_Model.php 72
ERROR - 2025-03-20 11:33:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC' at line 6 - Invalid query: SELECT *
FROM `preguntas_prueba` `pp`
JOIN `cfg_materias` `cm` ON `cm`.`codmateria` = `pp`.`id_materia`
JOIN `temas` `t` ON `pp`.`id_tema` = `t`.`id_tema`
WHERE `id_materia` IN(0)
AND  IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC
ERROR - 2025-03-20 11:33:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 322
ERROR - 2025-03-20 11:33:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 323
ERROR - 2025-03-20 11:33:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 324
ERROR - 2025-03-20 11:33:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 325
ERROR - 2025-03-20 11:33:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 327
ERROR - 2025-03-20 11:33:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 327
ERROR - 2025-03-20 11:33:44 --> Severity: Notice --> Undefined variable: like_query /Applications/MAMP/htdocs/integratic/application/models/Preguntas_Model.php 72
ERROR - 2025-03-20 11:33:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC' at line 6 - Invalid query: SELECT *
FROM `preguntas_prueba` `pp`
JOIN `cfg_materias` `cm` ON `cm`.`codmateria` = `pp`.`id_materia`
JOIN `temas` `t` ON `pp`.`id_tema` = `t`.`id_tema`
WHERE `id_materia` IN(0)
AND  IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC
ERROR - 2025-03-20 11:35:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 322
ERROR - 2025-03-20 11:35:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 323
ERROR - 2025-03-20 11:35:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 324
ERROR - 2025-03-20 11:35:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 325
ERROR - 2025-03-20 11:35:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 327
ERROR - 2025-03-20 11:35:17 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 327
ERROR - 2025-03-20 11:35:17 --> Severity: Notice --> Undefined variable: like_query /Applications/MAMP/htdocs/integratic/application/models/Preguntas_Model.php 72
ERROR - 2025-03-20 11:35:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC' at line 6 - Invalid query: SELECT *
FROM `preguntas_prueba` `pp`
JOIN `cfg_materias` `cm` ON `cm`.`codmateria` = `pp`.`id_materia`
JOIN `temas` `t` ON `pp`.`id_tema` = `t`.`id_tema`
WHERE `id_materia` IN(0)
AND  IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC
ERROR - 2025-03-20 11:35:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 322
ERROR - 2025-03-20 11:35:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 323
ERROR - 2025-03-20 11:35:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 324
ERROR - 2025-03-20 11:35:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 325
ERROR - 2025-03-20 11:35:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 327
ERROR - 2025-03-20 11:35:29 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 327
ERROR - 2025-03-20 11:35:29 --> Severity: Notice --> Undefined variable: like_query /Applications/MAMP/htdocs/integratic/application/models/Preguntas_Model.php 72
ERROR - 2025-03-20 11:35:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC' at line 6 - Invalid query: SELECT *
FROM `preguntas_prueba` `pp`
JOIN `cfg_materias` `cm` ON `cm`.`codmateria` = `pp`.`id_materia`
JOIN `temas` `t` ON `pp`.`id_tema` = `t`.`id_tema`
WHERE `id_materia` IN(0)
AND  IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC
ERROR - 2025-03-20 14:06:09 --> 404 Page Not Found: Simulacros/index
ERROR - 2025-03-20 14:09:54 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-20 14:09:54 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-20 14:09:54 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-20 14:09:54 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-20 14:09:54 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-20 14:09:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:09:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:09:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:09:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:09:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:09:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:09:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:09:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:09:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:09:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:09:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:09:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:09:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:09:54 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:09:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:09:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:09:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:09:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:09:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:09:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:09:55 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:09:56 --> 404 Page Not Found: Images/small
ERROR - 2025-03-20 14:10:02 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-20 14:10:02 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-20 14:23:04 --> Severity: Notice --> Undefined variable: prueba /Applications/MAMP/htdocs/integratic/application/views/pruebas/simulacros/index.php 16
ERROR - 2025-03-20 14:23:04 --> Severity: Notice --> Undefined variable: prueba /Applications/MAMP/htdocs/integratic/application/views/pruebas/simulacros/index.php 20
ERROR - 2025-03-20 14:23:04 --> Severity: Notice --> Undefined variable: prueba /Applications/MAMP/htdocs/integratic/application/views/pruebas/simulacros/index.php 22
ERROR - 2025-03-20 14:23:04 --> Severity: Notice --> Undefined variable: prueba /Applications/MAMP/htdocs/integratic/application/views/pruebas/simulacros/index.php 20
ERROR - 2025-03-20 14:23:04 --> Severity: Notice --> Undefined variable: prueba /Applications/MAMP/htdocs/integratic/application/views/pruebas/simulacros/index.php 22
ERROR - 2025-03-20 14:32:13 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 14:32:13 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 14:32:16 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 14:32:16 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 14:32:35 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 14:32:35 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 14:33:18 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 14:33:18 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 14:33:29 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 14:36:50 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-20 14:36:52 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-20 14:36:52 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-20 14:36:52 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-20 14:36:52 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-20 14:36:52 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-20 14:36:52 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-20 14:36:52 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-20 14:36:52 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-20 14:36:52 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-20 14:36:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:36:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:36:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:36:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:36:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:36:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:36:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:36:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:36:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:36:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:36:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:36:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:36:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:36:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:36:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:36:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:36:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:36:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:36:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:36:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:36:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:36:53 --> 404 Page Not Found: Images/small
ERROR - 2025-03-20 14:37:00 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:37:00 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:37:00 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:37:00 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:37:18 --> Severity: Warning --> mkdir(): No such file or directory /Applications/MAMP/htdocs/integratic/application/controllers/Asignacion.php 52
ERROR - 2025-03-20 14:37:24 --> Severity: Warning --> mkdir(): No such file or directory /Applications/MAMP/htdocs/integratic/application/controllers/Asignacion.php 52
ERROR - 2025-03-20 14:37:27 --> Severity: Warning --> mkdir(): No such file or directory /Applications/MAMP/htdocs/integratic/application/controllers/Asignacion.php 52
ERROR - 2025-03-20 14:37:29 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-20 14:37:29 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-20 14:37:29 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-20 14:37:29 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-20 14:37:29 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-20 14:37:29 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-20 14:37:29 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-20 14:37:29 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-20 14:37:29 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-20 14:37:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:37:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:37:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:37:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:37:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:37:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:37:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:37:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:37:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:37:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:37:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:37:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:37:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:37:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:37:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:37:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:37:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:37:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:37:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:37:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:37:29 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 14:37:30 --> 404 Page Not Found: Images/small
ERROR - 2025-03-20 14:37:37 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-20 14:37:37 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-20 14:37:42 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 14:47:28 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 14:47:28 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 14:47:59 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 14:47:59 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 14:51:12 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 14:51:12 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 14:51:13 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 14:51:13 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 14:51:42 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 14:51:42 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 14:54:16 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 14:54:16 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 14:54:54 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 14:54:55 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 14:58:31 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 14:58:32 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 14:58:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/models/Temas_Model.php 28
ERROR - 2025-03-20 14:58:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/models/Temas_Model.php 30
ERROR - 2025-03-20 14:58:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/models/Temas_Model.php 30
ERROR - 2025-03-20 14:59:03 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 14:59:03 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 14:59:30 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 14:59:30 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 15:02:00 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 15:02:00 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 15:02:14 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 15:02:14 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 15:02:14 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 15:02:26 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 15:02:26 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 15:02:46 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 15:02:46 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 15:03:01 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 15:03:02 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 15:03:53 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 15:03:53 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 15:04:15 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 15:04:15 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 15:04:33 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 15:04:34 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 15:05:44 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 15:05:44 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 15:06:54 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 15:06:54 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 15:07:26 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 15:07:26 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 15:07:57 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 15:07:57 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 15:08:20 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-20 15:08:22 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-20 15:08:22 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-20 15:08:22 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-20 15:08:22 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-20 15:08:22 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-20 15:08:22 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-20 15:08:22 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-20 15:08:22 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-20 15:08:22 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-20 15:08:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:22 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:23 --> 404 Page Not Found: Images/small
ERROR - 2025-03-20 15:08:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:25 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:38 --> Severity: Warning --> mkdir(): No such file or directory /Applications/MAMP/htdocs/integratic/application/controllers/Asignacion.php 52
ERROR - 2025-03-20 15:08:41 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-20 15:08:41 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-20 15:08:41 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-20 15:08:41 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-20 15:08:41 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-20 15:08:41 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-20 15:08:41 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-20 15:08:41 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-20 15:08:41 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-20 15:08:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:41 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:08:42 --> 404 Page Not Found: Images/small
ERROR - 2025-03-20 15:08:52 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-20 15:08:52 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-20 15:08:56 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 15:09:19 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 15:09:38 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 15:23:28 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 15:23:28 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 15:24:03 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-20 15:25:27 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 15:25:27 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 15:25:36 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 15:25:37 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 15:26:12 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 15:26:12 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 15:26:44 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 15:26:44 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 15:26:47 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 15:26:47 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 15:26:47 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-20 15:26:50 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 15:26:50 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 15:27:15 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 15:27:16 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 15:27:17 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-20 15:27:17 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-20 15:28:18 --> 404 Page Not Found: Preguntas/index
ERROR - 2025-03-20 15:29:05 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-03-20 15:30:54 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 15:30:56 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-03-20 15:31:35 --> 404 Page Not Found: Pruebas/index.php
ERROR - 2025-03-20 15:31:36 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-03-20 15:34:29 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-03-20 15:34:44 --> 404 Page Not Found: PreguntasPrueba/index.php
ERROR - 2025-03-20 15:40:58 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-20 15:41:04 --> 404 Page Not Found: EstadisticasPruebas/index.php
ERROR - 2025-03-20 15:42:58 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 110
ERROR - 2025-03-20 15:43:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 268
ERROR - 2025-03-20 15:43:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 269
ERROR - 2025-03-20 15:43:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 270
ERROR - 2025-03-20 15:43:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-20 15:43:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 268
ERROR - 2025-03-20 15:43:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 269
ERROR - 2025-03-20 15:43:09 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 270
ERROR - 2025-03-20 15:43:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-20 15:43:14 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 110
ERROR - 2025-03-20 15:43:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 268
ERROR - 2025-03-20 15:43:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 269
ERROR - 2025-03-20 15:43:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 270
ERROR - 2025-03-20 15:43:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-20 15:43:20 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 268
ERROR - 2025-03-20 15:43:20 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 269
ERROR - 2025-03-20 15:43:20 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 270
ERROR - 2025-03-20 15:43:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-20 15:43:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 110
ERROR - 2025-03-20 15:43:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 268
ERROR - 2025-03-20 15:43:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 269
ERROR - 2025-03-20 15:43:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 270
ERROR - 2025-03-20 15:43:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-20 15:43:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 268
ERROR - 2025-03-20 15:43:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 269
ERROR - 2025-03-20 15:43:31 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 270
ERROR - 2025-03-20 15:43:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-20 15:43:34 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-20 15:43:37 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-20 15:43:37 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-20 15:43:37 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-20 15:43:37 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-20 15:43:37 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-20 15:43:37 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-20 15:43:37 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-20 15:43:37 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-20 15:43:37 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-20 15:43:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:43:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:43:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:43:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:43:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:43:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:43:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:43:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:43:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:43:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:43:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:43:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:43:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:43:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:43:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:43:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:43:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:43:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:43:37 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:43:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:43:38 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:43:38 --> 404 Page Not Found: Images/small
ERROR - 2025-03-20 15:43:45 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-20 15:43:45 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-20 15:43:52 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-20 15:45:00 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2025-03-20 15:45:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 132
ERROR - 2025-03-20 15:45:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 133
ERROR - 2025-03-20 15:45:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-03-20 15:45:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-03-20 15:45:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-03-20 15:45:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-03-20 15:45:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-03-20 15:45:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-03-20 15:45:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-03-20 15:45:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-03-20 15:45:00 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-03-20 15:45:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 217
ERROR - 2025-03-20 15:45:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 217
ERROR - 2025-03-20 15:45:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 162
ERROR - 2025-03-20 15:45:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 166
ERROR - 2025-03-20 15:45:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 167
ERROR - 2025-03-20 15:45:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 169
ERROR - 2025-03-20 15:45:01 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 170
ERROR - 2025-03-20 15:45:10 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 162
ERROR - 2025-03-20 15:45:10 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 166
ERROR - 2025-03-20 15:45:10 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 167
ERROR - 2025-03-20 15:45:10 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 169
ERROR - 2025-03-20 15:45:10 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 170
ERROR - 2025-03-20 15:45:16 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2025-03-20 15:45:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 132
ERROR - 2025-03-20 15:45:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 133
ERROR - 2025-03-20 15:45:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-03-20 15:45:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-03-20 15:45:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-03-20 15:45:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-03-20 15:45:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-03-20 15:45:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-03-20 15:45:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-03-20 15:45:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-03-20 15:45:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-03-20 15:45:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 217
ERROR - 2025-03-20 15:45:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 217
ERROR - 2025-03-20 15:45:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 162
ERROR - 2025-03-20 15:45:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 166
ERROR - 2025-03-20 15:45:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 167
ERROR - 2025-03-20 15:45:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 169
ERROR - 2025-03-20 15:45:19 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 170
ERROR - 2025-03-20 15:45:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 217
ERROR - 2025-03-20 15:45:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 217
ERROR - 2025-03-20 15:45:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 162
ERROR - 2025-03-20 15:45:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 166
ERROR - 2025-03-20 15:45:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 167
ERROR - 2025-03-20 15:45:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 169
ERROR - 2025-03-20 15:45:26 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 170
ERROR - 2025-03-20 15:45:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 217
ERROR - 2025-03-20 15:45:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 217
ERROR - 2025-03-20 15:45:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 162
ERROR - 2025-03-20 15:45:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 166
ERROR - 2025-03-20 15:45:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 167
ERROR - 2025-03-20 15:45:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 169
ERROR - 2025-03-20 15:45:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 170
ERROR - 2025-03-20 15:45:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 162
ERROR - 2025-03-20 15:45:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 166
ERROR - 2025-03-20 15:45:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 167
ERROR - 2025-03-20 15:45:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 169
ERROR - 2025-03-20 15:45:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 170
ERROR - 2025-03-20 15:45:41 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2025-03-20 15:45:41 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 132
ERROR - 2025-03-20 15:45:41 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 133
ERROR - 2025-03-20 15:45:41 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-03-20 15:45:41 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-03-20 15:45:41 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-03-20 15:45:41 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-03-20 15:45:41 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-03-20 15:45:41 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-03-20 15:45:41 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-03-20 15:45:41 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-03-20 15:45:41 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-03-20 15:45:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 217
ERROR - 2025-03-20 15:45:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 217
ERROR - 2025-03-20 15:45:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 162
ERROR - 2025-03-20 15:45:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 166
ERROR - 2025-03-20 15:45:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 167
ERROR - 2025-03-20 15:45:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 169
ERROR - 2025-03-20 15:45:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 170
ERROR - 2025-03-20 15:45:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 217
ERROR - 2025-03-20 15:45:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 217
ERROR - 2025-03-20 15:45:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 162
ERROR - 2025-03-20 15:45:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 166
ERROR - 2025-03-20 15:45:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 167
ERROR - 2025-03-20 15:45:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 169
ERROR - 2025-03-20 15:45:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 170
ERROR - 2025-03-20 15:45:50 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 217
ERROR - 2025-03-20 15:45:50 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 217
ERROR - 2025-03-20 15:45:50 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 162
ERROR - 2025-03-20 15:45:50 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 166
ERROR - 2025-03-20 15:45:50 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 167
ERROR - 2025-03-20 15:45:50 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 169
ERROR - 2025-03-20 15:45:50 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 170
ERROR - 2025-03-20 15:45:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 217
ERROR - 2025-03-20 15:45:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 217
ERROR - 2025-03-20 15:45:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 162
ERROR - 2025-03-20 15:45:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 166
ERROR - 2025-03-20 15:45:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 167
ERROR - 2025-03-20 15:45:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 169
ERROR - 2025-03-20 15:45:56 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 170
ERROR - 2025-03-20 15:45:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 162
ERROR - 2025-03-20 15:45:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 166
ERROR - 2025-03-20 15:45:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 167
ERROR - 2025-03-20 15:45:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 169
ERROR - 2025-03-20 15:45:59 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 170
ERROR - 2025-03-20 15:46:03 --> 404 Page Not Found: Images/instrucciones_prueba.png
ERROR - 2025-03-20 15:46:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 132
ERROR - 2025-03-20 15:46:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 133
ERROR - 2025-03-20 15:46:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 33
ERROR - 2025-03-20 15:46:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 58
ERROR - 2025-03-20 15:46:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 62
ERROR - 2025-03-20 15:46:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 66
ERROR - 2025-03-20 15:46:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 70
ERROR - 2025-03-20 15:46:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 74
ERROR - 2025-03-20 15:46:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 78
ERROR - 2025-03-20 15:46:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 82
ERROR - 2025-03-20 15:46:03 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/views/pruebas/empezar_prueba.php 86
ERROR - 2025-03-20 15:46:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 162
ERROR - 2025-03-20 15:46:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 166
ERROR - 2025-03-20 15:46:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 167
ERROR - 2025-03-20 15:46:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 169
ERROR - 2025-03-20 15:46:05 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 170
ERROR - 2025-03-20 15:46:10 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-20 15:46:12 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-20 15:46:12 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-20 15:46:12 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-20 15:46:12 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-20 15:46:12 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-20 15:46:12 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-20 15:46:12 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-20 15:46:12 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-20 15:46:12 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-20 15:46:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:46:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:46:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:46:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:46:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:46:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:46:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:46:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:46:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:46:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:46:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:46:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:46:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:46:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:46:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:46:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:46:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:46:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:46:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:46:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:46:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-20 15:46:14 --> 404 Page Not Found: Images/small
ERROR - 2025-03-20 15:46:20 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-20 15:46:20 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-20 15:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 110
ERROR - 2025-03-20 15:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 268
ERROR - 2025-03-20 15:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 269
ERROR - 2025-03-20 15:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 270
ERROR - 2025-03-20 15:46:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-20 15:46:41 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 110
ERROR - 2025-03-20 15:46:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 268
ERROR - 2025-03-20 15:46:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 269
ERROR - 2025-03-20 15:46:43 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 270
ERROR - 2025-03-20 15:46:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-20 15:46:47 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 162
ERROR - 2025-03-20 15:46:47 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 169
ERROR - 2025-03-20 15:46:47 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 170
ERROR - 2025-03-20 15:46:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 162
ERROR - 2025-03-20 15:46:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 169
ERROR - 2025-03-20 15:46:51 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 170
ERROR - 2025-03-20 15:46:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 162
ERROR - 2025-03-20 15:46:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 169
ERROR - 2025-03-20 15:46:55 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 170
ERROR - 2025-03-20 15:51:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 110
ERROR - 2025-03-20 15:51:47 --> Severity: Notice --> Undefined index: is_close /Applications/MAMP/htdocs/integratic/application/views/pruebas/participantes.php 219
ERROR - 2025-03-20 15:51:47 --> Severity: Notice --> Undefined index: is_close /Applications/MAMP/htdocs/integratic/application/views/pruebas/participantes.php 219
ERROR - 2025-03-20 15:51:47 --> Severity: Notice --> Undefined index: is_close /Applications/MAMP/htdocs/integratic/application/views/pruebas/participantes.php 219
ERROR - 2025-03-20 15:51:47 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 268
ERROR - 2025-03-20 15:51:47 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 269
ERROR - 2025-03-20 15:51:47 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 270
ERROR - 2025-03-20 15:51:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-20 15:52:18 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 268
ERROR - 2025-03-20 15:52:18 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 269
ERROR - 2025-03-20 15:52:18 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 270
ERROR - 2025-03-20 15:52:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-20 15:52:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 268
ERROR - 2025-03-20 15:52:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 269
ERROR - 2025-03-20 15:52:23 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 270
ERROR - 2025-03-20 15:52:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-20 15:52:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 162
ERROR - 2025-03-20 15:52:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 169
ERROR - 2025-03-20 15:52:25 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 170
ERROR - 2025-03-20 15:52:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 162
ERROR - 2025-03-20 15:52:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 169
ERROR - 2025-03-20 15:52:35 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 170
ERROR - 2025-03-20 15:52:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 110
ERROR - 2025-03-20 15:52:41 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 268
ERROR - 2025-03-20 15:52:41 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 269
ERROR - 2025-03-20 15:52:41 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 270
ERROR - 2025-03-20 15:52:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-20 15:54:24 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 110
ERROR - 2025-03-20 15:54:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 322
ERROR - 2025-03-20 15:54:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 323
ERROR - 2025-03-20 15:54:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 324
ERROR - 2025-03-20 15:54:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 325
ERROR - 2025-03-20 15:54:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 327
ERROR - 2025-03-20 15:54:30 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 327
ERROR - 2025-03-20 15:54:30 --> Severity: Notice --> Undefined variable: like_query /Applications/MAMP/htdocs/integratic/application/models/Preguntas_Model.php 72
ERROR - 2025-03-20 15:54:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC' at line 6 - Invalid query: SELECT *
FROM `preguntas_prueba` `pp`
JOIN `cfg_materias` `cm` ON `cm`.`codmateria` = `pp`.`id_materia`
JOIN `temas` `t` ON `pp`.`id_tema` = `t`.`id_tema`
WHERE `id_materia` IN(0)
AND  IS NULL
AND `pp`.`estado` = 1
ORDER BY `pp`.`created_at` DESC
ERROR - 2025-03-20 15:54:34 --> 404 Page Not Found: EstadisticasPruebas/index.php
ERROR - 2025-03-20 15:55:15 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 110
ERROR - 2025-03-20 15:55:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 268
ERROR - 2025-03-20 15:55:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 269
ERROR - 2025-03-20 15:55:16 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 270
ERROR - 2025-03-20 15:55:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-20 15:55:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 268
ERROR - 2025-03-20 15:55:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 269
ERROR - 2025-03-20 15:55:36 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 270
ERROR - 2025-03-20 15:55:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-20 15:55:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 268
ERROR - 2025-03-20 15:55:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 269
ERROR - 2025-03-20 15:55:44 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 270
ERROR - 2025-03-20 15:55:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-20 15:55:47 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 162
ERROR - 2025-03-20 15:55:47 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 169
ERROR - 2025-03-20 15:55:47 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 170
