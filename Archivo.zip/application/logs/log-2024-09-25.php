<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-09-25 16:49:44 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-09-25 16:49:44 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-09-25 16:49:44 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-09-25 16:49:44 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-09-25 16:49:44 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-09-25 16:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-25 16:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-25 16:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-25 16:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-25 16:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-25 16:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-25 16:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-25 16:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-25 16:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-25 16:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-25 16:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-25 16:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-25 16:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-25 16:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-25 16:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-25 16:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-25 16:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-25 16:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-25 16:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-25 16:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-25 16:49:44 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-25 16:49:46 --> 404 Page Not Found: Images/small
ERROR - 2024-09-25 16:50:02 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 16:50:02 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 16:50:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 16:50:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 17:42:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 17:42:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 17:42:58 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 17:42:58 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 17:45:48 --> Severity: Notice --> Undefined index: titulo /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/index.php 34
ERROR - 2024-09-25 17:48:05 --> Severity: Notice --> Undefined index: periodo /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/index.php 37
ERROR - 2024-09-25 17:51:21 --> Severity: Notice --> Undefined variable: plan /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/index.php 40
ERROR - 2024-09-25 17:51:21 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/index.php 40
ERROR - 2024-09-25 17:51:21 --> Severity: Notice --> Undefined variable: plan /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/index.php 41
ERROR - 2024-09-25 17:51:21 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/index.php 41
ERROR - 2024-09-25 17:51:21 --> Severity: Notice --> Undefined variable: plan /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/index.php 42
ERROR - 2024-09-25 17:51:21 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/index.php 42
ERROR - 2024-09-25 18:03:34 --> 404 Page Not Found: Recuperaciones/create
ERROR - 2024-09-25 18:04:18 --> Severity: Notice --> Undefined variable: curso /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 10
ERROR - 2024-09-25 18:04:18 --> Severity: Notice --> Undefined variable: curso /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 12
ERROR - 2024-09-25 18:04:18 --> Severity: Notice --> Undefined variable: curso /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 18
ERROR - 2024-09-25 18:04:18 --> Severity: Notice --> Undefined variable: grados /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 26
ERROR - 2024-09-25 18:04:18 --> Severity: Notice --> Undefined variable: curso /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 41
ERROR - 2024-09-25 18:04:18 --> Severity: Notice --> Undefined variable: curso /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 47
ERROR - 2024-09-25 18:04:18 --> Severity: Notice --> Undefined variable: archivos /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 73
ERROR - 2024-09-25 18:04:18 --> Severity: Notice --> Undefined variable: curso /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 135
ERROR - 2024-09-25 18:04:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:04:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:04:18 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:04:45 --> Severity: Notice --> Undefined variable: curso /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 10
ERROR - 2024-09-25 18:04:45 --> Severity: Notice --> Undefined variable: curso /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 12
ERROR - 2024-09-25 18:04:45 --> Severity: Notice --> Undefined variable: curso /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 18
ERROR - 2024-09-25 18:04:45 --> Severity: Notice --> Undefined variable: grados /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 26
ERROR - 2024-09-25 18:04:45 --> Severity: Notice --> Undefined variable: curso /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 41
ERROR - 2024-09-25 18:04:45 --> Severity: Notice --> Undefined variable: curso /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 47
ERROR - 2024-09-25 18:04:45 --> Severity: Notice --> Undefined variable: archivos /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 73
ERROR - 2024-09-25 18:04:45 --> Severity: Notice --> Undefined variable: curso /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 135
ERROR - 2024-09-25 18:04:45 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:04:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:04:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:04:59 --> Severity: Notice --> Undefined variable: curso /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 10
ERROR - 2024-09-25 18:04:59 --> Severity: Notice --> Undefined variable: curso /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 12
ERROR - 2024-09-25 18:04:59 --> Severity: Notice --> Undefined variable: curso /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 18
ERROR - 2024-09-25 18:04:59 --> Severity: Notice --> Undefined variable: grados /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 26
ERROR - 2024-09-25 18:04:59 --> Severity: Notice --> Undefined variable: curso /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 41
ERROR - 2024-09-25 18:04:59 --> Severity: Notice --> Undefined variable: curso /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 47
ERROR - 2024-09-25 18:04:59 --> Severity: Notice --> Undefined variable: archivos /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 73
ERROR - 2024-09-25 18:04:59 --> Severity: Notice --> Undefined variable: curso /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 135
ERROR - 2024-09-25 18:04:59 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:06:22 --> Severity: Notice --> Undefined variable: grados /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 26
ERROR - 2024-09-25 18:06:22 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:06:55 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.estudiante.documento' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT *
FROM `estudiante`
GROUP BY `grado`
ORDER BY `grado` ASC
ERROR - 2024-09-25 18:07:17 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:11:19 --> Severity: Notice --> Undefined property: Recuperaciones::$Materias_Model /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 30
ERROR - 2024-09-25 18:11:19 --> Severity: error --> Exception: Call to a member function getMateriasDocente() on null /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 30
ERROR - 2024-09-25 18:11:28 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:11:43 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:11:57 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:12:05 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:14:25 --> Severity: error --> Exception: Call to undefined method Consultas_Model::getMateriasDocente() /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 31
ERROR - 2024-09-25 18:14:41 --> Severity: error --> Exception: Cannot use object of type stdClass as array /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 45
ERROR - 2024-09-25 18:15:33 --> Severity: error --> Exception: Cannot use object of type stdClass as array /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 45
ERROR - 2024-09-25 18:16:04 --> Severity: error --> Exception: Cannot use object of type stdClass as array /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/create.php 45
ERROR - 2024-09-25 18:16:07 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-09-25 18:22:01 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-09-25 18:22:02 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:22:02 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-09-25 18:22:10 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-09-25 18:22:10 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-09-25 18:22:10 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:22:20 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:23:02 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:23:29 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:24:34 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:25:44 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:25:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`r` (`id_recuperacion`, `nombre_recuperacion`, `materia`, `grupo`, `disponible_d' at line 1 - Invalid query: INSERT INTO `recuperaciones` `r` (`id_recuperacion`, `nombre_recuperacion`, `materia`, `grupo`, `disponible_desde`, `disponible_hasta`, `descripcion_recuperacion`, `created_by`) VALUES ('', '', 'Biologia', 'A', '', '', '', '12345')
ERROR - 2024-09-25 18:26:15 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:26:28 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:26:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`r` (`id_recuperacion`, `nombre_recuperacion`, `materia`, `grupo`, `disponible_d' at line 1 - Invalid query: INSERT INTO `recuperaciones` `r` (`id_recuperacion`, `nombre_recuperacion`, `materia`, `grupo`, `disponible_desde`, `disponible_hasta`, `descripcion_recuperacion`, `created_by`) VALUES ('', 'Recuperacion periodo 2', 'Biologia', 'A', '2024-09-25T18:26', '2024-10-02T18:26', '', '12345')
ERROR - 2024-09-25 18:28:24 --> Query error: Unknown column 'nombre_recuperacion' in 'field list' - Invalid query: INSERT INTO `recuperaciones` (`id_recuperacion`, `nombre_recuperacion`, `materia`, `grupo`, `disponible_desde`, `disponible_hasta`, `descripcion_recuperacion`, `created_by`) VALUES ('', 'Recuperacion periodo 2', 'Biologia', 'A', '2024-09-25T18:26', '2024-10-02T18:26', '', '12345')
ERROR - 2024-09-25 18:28:39 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:28:53 --> Query error: Unknown column 'grupo' in 'field list' - Invalid query: INSERT INTO `recuperaciones` (`id_recuperacion`, `title`, `materia`, `grupo`, `disponible_desde`, `disponible_hasta`, `descripcion_recuperacion`, `created_by`) VALUES ('', 'Recuperacion periodo 3', 'Biologia', 'A', '2024-09-25T18:28', '2024-10-02T18:28', '', '12345')
ERROR - 2024-09-25 18:29:14 --> Query error: Unknown column 'descripcion_recuperacion' in 'field list' - Invalid query: INSERT INTO `recuperaciones` (`id_recuperacion`, `title`, `materia`, `grupo`, `disponible_desde`, `disponible_hasta`, `descripcion_recuperacion`, `created_by`) VALUES ('', 'Recuperacion periodo 3', 'Biologia', 'A', '2024-09-25T18:28', '2024-10-02T18:28', '', '12345')
ERROR - 2024-09-25 18:29:36 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:29:45 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`integratic`.`recuperaciones`, CONSTRAINT `fk_recuperacion_periodo` FOREIGN KEY (`id_periodo`) REFERENCES `periodos` (`id_periodo`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: INSERT INTO `recuperaciones` (`id_recuperacion`, `title`, `materia`, `grupo`, `disponible_desde`, `disponible_hasta`, `description`, `created_by`) VALUES ('', 'Recuperacion periodo 3', 'Biologia', 'A', '2024-09-25T18:29', '2024-10-02T18:29', '', '12345')
ERROR - 2024-09-25 18:29:58 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`integratic`.`recuperaciones`, CONSTRAINT `fk_recuperacion_periodo` FOREIGN KEY (`id_periodo`) REFERENCES `periodos` (`id_periodo`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: INSERT INTO `recuperaciones` (`id_recuperacion`, `title`, `materia`, `grupo`, `disponible_desde`, `disponible_hasta`, `description`, `created_by`) VALUES ('', 'Recuperacion periodo 3', 'Biologia', 'A', '2024-09-25T18:29', '2024-10-02T18:29', '', '12345')
ERROR - 2024-09-25 18:30:23 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:30:32 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:30:58 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:30:58 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:31:06 --> Severity: Notice --> Undefined index: grado /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/index.php 41
ERROR - 2024-09-25 18:31:06 --> Severity: Notice --> Undefined index: grado /Applications/MAMP/htdocs/integratic/application/views/recuperaciones/index.php 41
ERROR - 2024-09-25 18:34:13 --> Query error: Table 'integratic.materias' doesn't exist - Invalid query: SELECT `recuperaciones`.*, `periodos`.`periodo`, `materias`.`nommateria`
FROM `recuperaciones`
JOIN `periodos` ON `periodos`.`id_periodo` = `recuperaciones`.`id_periodo`
JOIN `materias` ON `materias`.`codmateria` = `recuperaciones`.`materia`
WHERE `created_by` = '12345'
ERROR - 2024-09-25 18:34:34 --> Query error: Table 'integratic.cgf_materias' doesn't exist - Invalid query: SELECT `recuperaciones`.*, `periodos`.`periodo`, `cgf_materias`.`nommateria`
FROM `recuperaciones`
JOIN `periodos` ON `periodos`.`id_periodo` = `recuperaciones`.`id_periodo`
JOIN `cgf_materias` ON `cgf_materias`.`codmateria` = `recuperaciones`.`materia`
WHERE `created_by` = '12345'
ERROR - 2024-09-25 18:34:48 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:34:59 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:35:47 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:35:57 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:38:18 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:38:27 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:38:51 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:38:58 --> Severity: Notice --> Undefined index: id_recuperacion /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 42
ERROR - 2024-09-25 18:38:58 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:39:15 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-09-25 18:39:15 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-09-25 18:39:56 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:40:09 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:40:37 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:41:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:41:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:41:53 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-09-25 18:41:54 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:41:54 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:41:55 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:41:55 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:41:55 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-25 18:41:55 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-25 18:41:55 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-25 18:41:55 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-25 18:41:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:41:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:42:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:42:05 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:42:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:42:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:43:08 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:43:08 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:43:08 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:43:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:43:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:43:36 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:43:37 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:43:37 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:44:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:44:03 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:44:03 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:44:06 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:44:06 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:44:08 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:44:08 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:44:08 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:44:09 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:44:09 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:44:12 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:44:12 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:44:12 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:44:13 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:44:13 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:44:15 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:44:15 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:47:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:47:16 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:47:17 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:47:17 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:48:54 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:48:54 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:49:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:49:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:49:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:49:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:49:18 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:49:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:49:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:49:42 --> 404 Page Not Found: Recuperaciones/index.php
ERROR - 2024-09-25 18:49:48 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:49:48 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-25 18:49:48 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-09-25 18:49:48 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-09-25 18:49:48 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-09-25 18:49:48 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
