<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-04-02 10:35:21 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-04-02 10:35:21 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-04-02 10:35:21 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-04-02 10:35:21 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-04-02 10:35:21 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-04-02 10:35:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-02 10:35:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-02 10:35:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-02 10:35:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-02 10:35:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-02 10:35:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-02 10:35:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-02 10:35:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-02 10:35:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-02 10:35:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-02 10:35:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-02 10:35:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-02 10:35:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-02 10:35:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-02 10:35:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-02 10:35:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-02 10:35:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-02 10:35:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-02 10:35:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-02 10:35:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-02 10:35:21 --> 404 Page Not Found: Img/botones
ERROR - 2025-04-02 10:35:22 --> 404 Page Not Found: Images/small
ERROR - 2025-04-02 10:35:51 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.cm.codmateria' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT *
FROM `cfg_areas` `ca`
JOIN `cfg_materias` `cm` ON `ca`.`codarea` = `cm`.`area`
JOIN `asg_materias` `am` ON `am`.`materia` = `cm`.`codmateria`
WHERE `am`.`docente` = '12345'
GROUP BY `ca`.`codarea`
ERROR - 2025-04-02 10:37:59 --> 404 Page Not Found: PlanAula/index.php
ERROR - 2025-04-02 10:39:36 --> 404 Page Not Found: PlanAula/index.php
ERROR - 2025-04-02 10:39:46 --> 404 Page Not Found: PlanAula/index.php
ERROR - 2025-04-02 10:47:00 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-04-02 10:47:00 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-04-02 10:47:02 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-04-02 10:47:03 --> 404 Page Not Found: PlanAula/index.php
ERROR - 2025-04-02 10:47:03 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-04-02 10:47:44 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-04-02 10:47:44 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-04-02 10:47:44 --> 404 Page Not Found: PlanAula/index.php
ERROR - 2025-04-02 10:48:53 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-04-02 10:48:53 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-04-02 10:48:53 --> 404 Page Not Found: PlanAula/index.php
ERROR - 2025-04-02 10:49:10 --> 404 Page Not Found: PlanAula/index.php
ERROR - 2025-04-02 10:49:42 --> 404 Page Not Found: PlanAula/index.php
ERROR - 2025-04-02 10:50:08 --> 404 Page Not Found: PlanAula/index.php
ERROR - 2025-04-02 10:50:14 --> 404 Page Not Found: PlanAula/index.php
ERROR - 2025-04-02 10:50:33 --> 404 Page Not Found: PlanAula/index.php
ERROR - 2025-04-02 10:50:48 --> 404 Page Not Found: PlanAula/index.php
