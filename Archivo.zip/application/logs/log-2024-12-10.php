<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-12-10 15:54:35 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-12-10 15:54:35 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-12-10 15:54:35 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-12-10 15:54:35 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-12-10 15:54:35 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-12-10 15:54:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-10 15:54:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-10 15:54:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-10 15:54:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-10 15:54:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-10 15:54:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-10 15:54:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-10 15:54:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-10 15:54:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-10 15:54:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-10 15:54:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-10 15:54:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-10 15:54:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-10 15:54:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-10 15:54:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-10 15:54:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-10 15:54:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-10 15:54:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-10 15:54:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-10 15:54:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-10 15:54:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-12-10 15:54:36 --> 404 Page Not Found: Images/small
ERROR - 2024-12-10 15:54:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 15:54:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 15:54:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 15:54:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:05:26 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-10 16:05:26 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-10 16:05:59 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-10 16:05:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:05:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:05:59 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-10 16:09:25 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-10 16:09:25 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-10 16:09:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:09:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:09:30 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/integratic/system/database/DB_query_builder.php 662
ERROR - 2024-12-10 16:09:30 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `repositorio_actividades`
WHERE `materia` = `Array`
ERROR - 2024-12-10 16:10:26 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/integratic/system/database/DB_query_builder.php 662
ERROR - 2024-12-10 16:10:26 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `repositorio_actividades`
WHERE `materia` = `Array`
ERROR - 2024-12-10 16:10:52 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-10 16:10:53 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-10 16:10:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:10:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:10:58 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/integratic/system/database/DB_query_builder.php 662
ERROR - 2024-12-10 16:10:58 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `repositorio_actividades`
WHERE `materia` = `Array`
ERROR - 2024-12-10 16:11:29 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-10 16:11:29 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-10 16:11:29 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:11:29 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:12:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:12:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:12:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:12:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:15:28 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:15:28 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:16:43 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-10 16:16:43 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-10 16:19:15 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-10 16:19:15 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-10 16:19:15 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:19:15 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:22:28 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-10 16:22:28 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-10 16:22:28 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:22:28 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:27:04 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-10 16:27:04 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-10 16:27:04 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:27:04 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:27:40 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-10 16:27:40 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-10 16:27:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:27:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:29:33 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-10 16:29:33 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-10 16:35:04 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:35:04 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:35:22 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-10 16:35:22 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-10 16:37:55 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-10 16:37:55 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-10 16:38:15 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-10 16:38:15 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-10 16:38:15 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:38:15 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:47:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:47:14 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:47:18 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-10 16:47:18 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-10 16:48:53 --> Severity: Notice --> Undefined index: nueva-actividad-from-repo-id /Applications/MAMP/htdocs/integratic/application/controllers/Actividades.php 76
ERROR - 2024-12-10 16:50:24 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-10 16:50:25 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-10 16:50:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:50:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:52:34 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-10 16:52:34 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-10 16:52:34 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:52:34 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:53:57 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-10 16:53:58 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:53:58 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:53:58 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-10 16:55:35 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-10 16:55:36 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-10 16:55:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:55:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:57:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:57:25 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:58:10 --> 404 Page Not Found: Uploads/actividades
ERROR - 2024-12-10 16:59:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 16:59:00 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 17:10:17 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 17:10:17 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 17:10:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 17:10:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 17:11:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 17:11:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 17:11:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 17:11:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 17:11:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 17:11:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 17:12:01 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-12-10 17:12:01 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-12-10 17:12:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 17:12:20 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 17:12:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 17:12:46 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 17:13:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 17:13:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 17:14:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 17:14:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 17:15:41 --> 404 Page Not Found: Img/iconos
ERROR - 2024-12-10 17:15:41 --> 404 Page Not Found: Img/iconos
