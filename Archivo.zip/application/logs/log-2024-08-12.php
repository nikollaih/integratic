<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-08-12 09:44:24 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-12 09:44:24 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-12 09:44:24 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-12 09:44:24 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-12 09:44:24 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-08-12 09:44:24 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:44:24 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:44:24 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:44:24 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:44:24 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:44:24 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:44:24 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:44:24 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:44:24 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:44:24 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:44:24 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:44:24 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:44:24 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:44:24 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:44:24 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:44:24 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:44:24 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:44:24 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:44:24 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:44:24 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:44:24 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:45:00 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-12 09:45:00 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-12 09:45:00 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-12 09:45:01 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-12 09:45:01 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-08-12 09:45:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:45:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:45:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:45:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:45:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:45:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:45:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:45:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:45:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:45:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:45:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:45:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:45:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:45:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:45:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:45:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:45:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:45:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:45:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:45:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:45:01 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 09:45:03 --> 404 Page Not Found: Images/small
ERROR - 2024-08-12 09:45:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-12 09:45:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-12 09:45:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-12 09:45:11 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-12 10:07:51 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.u.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `u`.*, `e`.*, `e`.`email` as `email`, `cer_responses`.`caracterizacion_respuestas`
FROM `estudiante` `e`
LEFT JOIN `usuarios` `u` ON `e`.`documento` = `u`.`id`
LEFT OUTER JOIN (SELECT `cer`.`id_estudiante`, JSON_ARRAYAGG(JSON_OBJECT("id_pregunta", `cer`.`id_pregunta`, "respuesta", cer.respuesta)) as caracterizacion_respuestas
FROM `caracterizacion_estudiantes_respuestas` `cer`
GROUP BY `cer`.`id_estudiante`) as cer_responses ON `cer_responses`.`id_estudiante` = `u`.`id`
WHERE `e`.`grado` = '11A'
GROUP BY `e`.`documento`
ORDER BY `e`.`grado` ASC, `e`.`nombre` ASC
ERROR - 2024-08-12 10:09:18 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-12 10:13:25 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-12 10:14:29 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-12 10:14:37 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-12 10:14:52 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-12 10:17:28 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-12 10:18:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-12 10:18:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-12 10:18:50 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-12 10:18:50 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-08-12 10:18:50 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-12 10:18:50 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-08-12 10:18:50 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-12 10:18:50 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-08-12 10:18:50 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-12 10:18:50 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-08-12 10:18:50 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-08-12 10:18:50 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 10:18:50 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 10:18:50 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 10:18:50 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 10:18:50 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 10:18:50 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 10:18:50 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 10:18:50 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 10:18:50 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 10:18:50 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 10:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 10:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 10:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 10:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 10:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 10:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 10:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 10:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 10:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 10:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 10:18:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-08-12 10:18:52 --> 404 Page Not Found: Images/small
ERROR - 2024-08-12 10:18:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-12 10:18:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-12 10:18:54 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-12 10:18:54 --> 404 Page Not Found: Img/iconos
ERROR - 2024-08-12 10:18:56 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-12 10:21:34 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-12 10:22:00 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-12 10:22:45 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-12 10:25:05 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-12 10:25:18 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-12 10:25:42 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-12 10:30:32 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-12 10:37:57 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-12 10:38:36 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-12 10:38:55 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-08-12 10:40:59 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
