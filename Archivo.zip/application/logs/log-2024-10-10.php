<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-10-10 09:19:23 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-10-10 09:19:23 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-10-10 09:19:23 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-10-10 09:19:23 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-10-10 09:19:23 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-10-10 09:19:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 09:19:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 09:19:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 09:19:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 09:19:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 09:19:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 09:19:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 09:19:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 09:19:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 09:19:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 09:19:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 09:19:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 09:19:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 09:19:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 09:19:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 09:19:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 09:19:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 09:19:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 09:19:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 09:19:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 09:19:23 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 09:19:26 --> 404 Page Not Found: Images/small
ERROR - 2024-10-10 09:20:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 09:20:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 09:20:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 09:20:40 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 09:20:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 09:20:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 09:22:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 09:22:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 09:43:28 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 09:43:28 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 09:45:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 09:45:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 09:46:22 --> Severity: Notice --> Undefined index: nombres /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 23
ERROR - 2024-10-10 09:46:22 --> Severity: Notice --> Undefined index: nombres /Applications/MAMP/htdocs/integratic/application/views/modal/agregar_estudiante_recuperacion.php 23
ERROR - 2024-10-10 09:46:22 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 09:46:22 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 09:46:32 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 09:46:32 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 10:14:51 --> Query error: Table 'integratic.estudiantes' doesn't exist - Invalid query: SELECT `e`.*
FROM `recuperaciones_estudiantes` `re`
JOIN `estudiantes` `e` ON `re`.`id_estudiante` = `e`.`documento`
WHERE `re`.`id_recuperacion` = '2'
ERROR - 2024-10-10 10:15:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 10:15:07 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 10:15:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 10:15:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 10:48:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 10:48:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 10:48:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 10:48:53 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 10:48:56 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 10:48:56 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:01:15 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:01:15 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:01:22 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:01:22 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:01:27 --> Severity: Notice --> Undefined index: id_fk /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 182
ERROR - 2024-10-10 11:01:32 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-10 11:01:32 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-10 11:01:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:01:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:01:45 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-10 11:01:45 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-10 11:01:49 --> Severity: Notice --> Undefined index: id_fk /Applications/MAMP/htdocs/integratic/application/controllers/Recuperaciones.php 182
ERROR - 2024-10-10 11:02:24 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:02:24 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:02:25 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-10 11:02:25 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-10 11:02:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:02:31 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:02:31 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-10 11:02:31 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-10 11:02:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:02:42 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:19:06 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:19:06 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:19:43 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-10 11:19:43 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-10 11:36:33 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:36:33 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:36:33 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-10-10 11:36:33 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-10-10 11:36:33 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-10-10 11:36:33 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-10-10 11:36:35 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-10-10 11:36:35 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-10-10 11:36:35 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-10-10 11:36:35 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-10-10 11:36:35 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-10-10 11:36:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 11:36:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 11:36:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 11:36:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 11:36:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 11:36:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 11:36:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 11:36:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 11:36:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 11:36:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 11:36:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 11:36:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 11:36:35 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 11:36:36 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 11:36:36 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 11:36:36 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 11:36:36 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 11:36:36 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 11:36:36 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 11:36:36 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 11:36:36 --> 404 Page Not Found: Img/botones
ERROR - 2024-10-10 11:36:37 --> 404 Page Not Found: Images/small
ERROR - 2024-10-10 11:36:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:36:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:36:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:36:49 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:36:51 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:36:51 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:36:54 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:36:54 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:36:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:36:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:37:04 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/integratic/system/database/DB_driver.php 1524
ERROR - 2024-10-10 11:37:04 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `actividades` SET `id_actividad` = '16', `estudiantes_habilitados` = Array
WHERE `id_actividad` = '16'
ERROR - 2024-10-10 11:37:22 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:37:22 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:37:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:37:36 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:37:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:37:39 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:37:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:37:43 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:46:58 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-10 11:46:58 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-10 11:46:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:46:59 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:46:59 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-10 11:46:59 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-10 11:47:08 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:47:08 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:47:08 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-10 11:47:09 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-10-10 11:47:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:47:27 --> 404 Page Not Found: Img/iconos
ERROR - 2024-10-10 11:47:27 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-10-10 11:47:27 --> 404 Page Not Found: Js/chart.umd.js.map
