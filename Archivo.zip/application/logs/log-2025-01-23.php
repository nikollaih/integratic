<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-01-23 08:58:12 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-01-23 08:58:12 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-01-23 08:58:12 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-01-23 08:58:12 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-01-23 08:58:12 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-01-23 08:58:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 08:58:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 08:58:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 08:58:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 08:58:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 08:58:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 08:58:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 08:58:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 08:58:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 08:58:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 08:58:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 08:58:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 08:58:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 08:58:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 08:58:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 08:58:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 08:58:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 08:58:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 08:58:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 08:58:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 08:58:12 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 08:58:18 --> 404 Page Not Found: Images/small
ERROR - 2025-01-23 08:58:27 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-23 08:58:27 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-23 08:58:27 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-23 08:58:27 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-23 09:01:25 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-23 09:01:25 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-23 09:02:47 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-23 09:03:00 --> 404 Page Not Found: Piar/index
ERROR - 2025-01-23 09:03:30 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-23 09:18:27 --> Severity: Notice --> Undefined index: clave /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 47
ERROR - 2025-01-23 09:18:27 --> Severity: Notice --> Undefined index: id_pregunta /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 51
ERROR - 2025-01-23 09:19:02 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-23 09:19:06 --> Severity: Notice --> Undefined index: clave /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 47
ERROR - 2025-01-23 09:19:06 --> Severity: Notice --> Undefined index: id_pregunta /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 51
ERROR - 2025-01-23 09:30:50 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 09:30:50 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 09:31:24 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 09:31:24 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 09:41:06 --> 404 Page Not Found: Indexphp/Notificaciones
ERROR - 2025-01-23 09:45:06 --> Severity: Notice --> Undefined variable: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 16
ERROR - 2025-01-23 09:45:06 --> Severity: Notice --> Undefined variable: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 22
ERROR - 2025-01-23 09:45:06 --> Severity: Notice --> Undefined variable: estudiante /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 22
ERROR - 2025-01-23 09:45:06 --> Severity: Notice --> Undefined variable: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 28
ERROR - 2025-01-23 09:45:06 --> Severity: Notice --> Undefined variable: estudiante /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 28
ERROR - 2025-01-23 09:45:06 --> Severity: Notice --> Undefined variable: estudiante /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 34
ERROR - 2025-01-23 09:45:06 --> Severity: Notice --> Undefined variable: estudiante /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 40
ERROR - 2025-01-23 09:45:06 --> Severity: Notice --> Undefined variable: estudiante /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 47
ERROR - 2025-01-23 09:45:06 --> Severity: Notice --> Undefined variable: estudiante /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 48
ERROR - 2025-01-23 09:45:06 --> Severity: Notice --> Undefined variable: estudiante /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 55
ERROR - 2025-01-23 09:45:06 --> Severity: Notice --> Undefined variable: estudiante /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 61
ERROR - 2025-01-23 09:45:19 --> Severity: Notice --> Undefined variable: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 16
ERROR - 2025-01-23 09:45:19 --> Severity: Notice --> Undefined variable: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 22
ERROR - 2025-01-23 09:45:19 --> Severity: Notice --> Undefined variable: estudiante /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 22
ERROR - 2025-01-23 09:45:19 --> Severity: Notice --> Undefined variable: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 28
ERROR - 2025-01-23 09:45:19 --> Severity: Notice --> Undefined variable: estudiante /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 28
ERROR - 2025-01-23 09:45:19 --> Severity: Notice --> Undefined variable: estudiante /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 34
ERROR - 2025-01-23 09:45:19 --> Severity: Notice --> Undefined variable: estudiante /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 40
ERROR - 2025-01-23 09:45:19 --> Severity: Notice --> Undefined variable: estudiante /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 47
ERROR - 2025-01-23 09:45:19 --> Severity: Notice --> Undefined variable: estudiante /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 48
ERROR - 2025-01-23 09:45:19 --> Severity: Notice --> Undefined variable: estudiante /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 55
ERROR - 2025-01-23 09:45:19 --> Severity: Notice --> Undefined variable: estudiante /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 61
ERROR - 2025-01-23 09:58:38 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 36
ERROR - 2025-01-23 09:58:38 --> Severity: Notice --> Undefined index: nombre /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 36
ERROR - 2025-01-23 09:58:38 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 36
ERROR - 2025-01-23 09:58:38 --> Severity: Notice --> Undefined index: nombre /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 36
ERROR - 2025-01-23 09:58:48 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 36
ERROR - 2025-01-23 09:58:48 --> Severity: Notice --> Undefined index: nombre /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 36
ERROR - 2025-01-23 09:58:48 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 36
ERROR - 2025-01-23 09:58:48 --> Severity: Notice --> Undefined index: nombre /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 36
ERROR - 2025-01-23 09:58:54 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 36
ERROR - 2025-01-23 09:58:54 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 36
ERROR - 2025-01-23 09:59:17 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 36
ERROR - 2025-01-23 09:59:17 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 36
ERROR - 2025-01-23 10:01:16 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 36
ERROR - 2025-01-23 10:01:16 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 36
ERROR - 2025-01-23 10:01:16 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 52
ERROR - 2025-01-23 10:01:16 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 52
ERROR - 2025-01-23 10:01:33 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 10:01:33 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 10:01:33 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 54
ERROR - 2025-01-23 10:01:33 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 54
ERROR - 2025-01-23 10:03:24 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 10:03:24 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 10:03:24 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 54
ERROR - 2025-01-23 10:03:24 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 54
ERROR - 2025-01-23 10:03:36 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 10:03:36 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 10:03:36 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 54
ERROR - 2025-01-23 10:03:36 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 54
ERROR - 2025-01-23 10:07:55 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 10:07:55 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 10:07:55 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 54
ERROR - 2025-01-23 10:07:55 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 54
ERROR - 2025-01-23 10:07:57 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 10:07:57 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 10:07:57 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 54
ERROR - 2025-01-23 10:07:57 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 54
ERROR - 2025-01-23 10:07:58 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 10:07:58 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 10:07:58 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 54
ERROR - 2025-01-23 10:07:58 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 54
ERROR - 2025-01-23 10:08:01 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 10:08:01 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:29:38 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:29:38 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:29:38 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-01-23 12:29:38 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-01-23 12:29:38 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-01-23 12:29:38 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-01-23 12:29:39 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-01-23 12:29:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 12:29:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 12:29:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 12:29:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 12:29:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 12:29:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 12:29:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 12:29:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 12:29:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 12:29:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 12:29:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 12:29:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 12:29:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 12:29:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 12:29:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 12:29:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 12:29:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 12:29:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 12:29:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 12:29:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 12:29:39 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 12:29:41 --> 404 Page Not Found: Images/small
ERROR - 2025-01-23 12:29:47 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-23 12:29:47 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:29:47 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-23 12:29:47 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:29:51 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:29:51 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:29:55 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 12:29:55 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 12:29:55 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 54
ERROR - 2025-01-23 12:29:55 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 54
ERROR - 2025-01-23 12:29:56 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:29:56 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:32:02 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 12:32:02 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 12:32:02 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 54
ERROR - 2025-01-23 12:32:02 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 54
ERROR - 2025-01-23 12:32:03 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:32:03 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:32:24 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 12:32:24 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 12:32:24 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 54
ERROR - 2025-01-23 12:32:24 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 54
ERROR - 2025-01-23 12:32:57 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 12:32:57 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 12:32:57 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 54
ERROR - 2025-01-23 12:32:57 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 54
ERROR - 2025-01-23 12:33:59 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 12:33:59 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 12:33:59 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 54
ERROR - 2025-01-23 12:33:59 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 54
ERROR - 2025-01-23 12:35:02 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 12:35:02 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 12:35:02 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 54
ERROR - 2025-01-23 12:35:02 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 54
ERROR - 2025-01-23 12:35:07 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 12:35:07 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 12:35:07 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 54
ERROR - 2025-01-23 12:35:07 --> Severity: Notice --> Undefined index: documento /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 54
ERROR - 2025-01-23 12:35:13 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:35:13 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:35:56 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:35:56 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:36:53 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:36:53 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:36:55 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:36:55 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:37:08 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:37:08 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:39:06 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:39:06 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:45:17 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:45:17 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:47:27 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:47:27 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:47:30 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:47:30 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:47:51 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:47:51 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:48:27 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:48:27 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:48:44 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:48:44 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:48:57 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:48:57 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:49:00 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:49:00 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:50:19 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:50:19 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:50:21 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:50:21 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:50:27 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:50:27 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:50:41 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:50:41 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:50:43 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:50:43 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:51:09 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:51:09 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:51:35 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:51:35 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:51:48 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:51:48 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:51:50 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:51:51 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:52:50 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:52:50 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:52:52 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:52:52 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:53:13 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:53:13 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:54:04 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:54:04 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:54:11 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:54:11 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:54:20 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:54:20 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:54:21 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:54:21 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:57:47 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:57:47 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 12:58:50 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 12:58:50 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 13:01:07 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 13:01:07 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 13:01:11 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 13:01:11 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 13:01:20 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 13:01:20 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 13:01:28 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 13:01:28 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 13:10:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '54321) VALUES ('')' at line 1 - Invalid query: INSERT INTO `PIAR` (54321) VALUES ('')
ERROR - 2025-01-23 13:10:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '54321) VALUES ('')' at line 1 - Invalid query: INSERT INTO `PIAR` (54321) VALUES ('')
ERROR - 2025-01-23 13:14:47 --> Query error: Table 'integratic.estudiantes' doesn't exist - Invalid query: SELECT *
FROM `estudiantes` `e`
JOIN `piar` ON `estudiantes`.`id` = `piar`.`id_estudiante`
ERROR - 2025-01-23 13:15:05 --> Query error: Unknown column 'estudiante.id' in 'on clause' - Invalid query: SELECT *
FROM `estudiante` `e`
JOIN `piar` ON `estudiante`.`id` = `piar`.`id_estudiante`
ERROR - 2025-01-23 13:15:24 --> Query error: Unknown column 'estudiante.documento' in 'on clause' - Invalid query: SELECT *
FROM `estudiante` `e`
JOIN `piar` ON `estudiante`.`documento` = `piar`.`id_estudiante`
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 30
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 31
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'nombre' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 32
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'email' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 33
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'email_acudiente' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 34
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'grado' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 35
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'nee' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 36
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 38
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 30
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 31
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'nombre' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 32
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'email' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 33
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'email_acudiente' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 34
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'grado' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 35
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'nee' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 36
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 38
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 30
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 31
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'nombre' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 32
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'email' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 33
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'email_acudiente' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 34
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'grado' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 35
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'nee' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 36
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 38
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 30
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 31
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'nombre' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 32
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'email' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 33
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'email_acudiente' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 34
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'grado' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 35
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'nee' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 36
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 38
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 30
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 31
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'nombre' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 32
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'email' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 33
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'email_acudiente' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 34
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'grado' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 35
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'nee' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 36
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 38
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 30
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 31
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'nombre' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 32
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'email' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 33
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'email_acudiente' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 34
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'grado' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 35
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'nee' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 36
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 38
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 30
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 31
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'nombre' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 32
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'email' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 33
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'email_acudiente' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 34
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'grado' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 35
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'nee' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 36
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 38
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 30
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 31
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'nombre' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 32
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'email' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 33
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'email_acudiente' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 34
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'grado' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 35
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'nee' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 36
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 38
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 30
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 31
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'nombre' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 32
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'email' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 33
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'email_acudiente' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 34
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'grado' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 35
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'nee' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 36
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 38
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 30
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 31
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'nombre' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 32
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'email' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 33
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'email_acudiente' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 34
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'grado' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 35
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'nee' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 36
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 38
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 30
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 31
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'nombre' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 32
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'email' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 33
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'email_acudiente' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 34
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'grado' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 35
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'nee' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 36
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 38
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 30
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 31
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'nombre' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 32
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'email' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 33
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'email_acudiente' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 34
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'grado' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 35
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'nee' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 36
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 38
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 30
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 31
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'nombre' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 32
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'email' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 33
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'email_acudiente' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 34
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'grado' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 35
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'nee' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 36
ERROR - 2025-01-23 13:15:43 --> Severity: Warning --> Illegal string offset 'documento' /Applications/MAMP/htdocs/integratic/application/views/piar/index.php 38
ERROR - 2025-01-23 13:16:35 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 13:16:35 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 13:18:04 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 13:18:04 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 13:18:27 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 13:18:27 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 13:18:56 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 13:18:56 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 13:19:36 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 13:19:36 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 13:19:43 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 13:19:44 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 14:26:06 --> Query error: Not unique table/alias: 'piar' - Invalid query: SELECT *
FROM `piar`
JOIN `piar` ON `piar`.`id_estudiante` = `estudiante`.`documento`
WHERE `piar`.`id` = '1'
ERROR - 2025-01-23 14:26:29 --> Query error: Unknown column 'piar.id' in 'where clause' - Invalid query: SELECT *
FROM `piar`
JOIN `estudiante` ON `piar`.`id_estudiante` = `estudiante`.`documento`
WHERE `piar`.`id` = '1'
ERROR - 2025-01-23 14:27:00 --> Severity: Notice --> Undefined variable: estudiante /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 20
ERROR - 2025-01-23 14:27:00 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 20
ERROR - 2025-01-23 14:27:00 --> Severity: Notice --> Undefined variable: estudiante /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 21
ERROR - 2025-01-23 14:27:00 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 21
ERROR - 2025-01-23 14:27:00 --> Severity: Notice --> Undefined variable: estudiante /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 22
ERROR - 2025-01-23 14:27:00 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 22
ERROR - 2025-01-23 14:27:00 --> Severity: Notice --> Undefined variable: estudiante /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 23
ERROR - 2025-01-23 14:27:00 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 23
ERROR - 2025-01-23 14:27:00 --> Severity: Notice --> Undefined variable: estudiante /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 24
ERROR - 2025-01-23 14:27:00 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 24
ERROR - 2025-01-23 14:32:26 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-01-23 14:32:26 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-01-23 14:32:52 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-01-23 14:32:52 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-01-23 14:32:52 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-01-23 14:32:52 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-01-23 14:32:52 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-01-23 14:32:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 14:32:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 14:32:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 14:32:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 14:32:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 14:32:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 14:32:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 14:32:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 14:32:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 14:32:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 14:32:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 14:32:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 14:32:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 14:32:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 14:32:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 14:32:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 14:32:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 14:32:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 14:32:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 14:32:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 14:32:52 --> 404 Page Not Found: Img/botones
ERROR - 2025-01-23 14:32:53 --> 404 Page Not Found: Images/small
ERROR - 2025-01-23 14:32:59 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-23 14:33:00 --> 404 Page Not Found: Img/iconos
ERROR - 2025-01-23 14:35:37 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 14:35:37 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 14:35:45 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 14:35:45 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 14:36:11 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 14:36:11 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 14:36:45 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 14:36:45 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 14:37:37 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 14:37:37 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 14:37:44 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 14:37:44 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 14:38:02 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 14:38:02 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 14:38:16 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 14:38:16 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 14:38:18 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 14:38:18 --> Severity: Notice --> Undefined index: id_docente_aula /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 37
ERROR - 2025-01-23 14:38:18 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 55
ERROR - 2025-01-23 14:38:18 --> Severity: Notice --> Undefined index: id_docente_apoyo /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 55
ERROR - 2025-01-23 14:38:18 --> Severity: Notice --> Undefined index: entorno_personal /Applications/MAMP/htdocs/integratic/application/views/piar/crear.php 106
ERROR - 2025-01-23 14:38:18 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 14:38:18 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 14:38:42 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: UPDATE `piar` SET `id_docente_aula` = '12345', `id_docente_apoyo` = '2', `entorno_personal` = '<p>Prueba <strong>rgggth</strong><span style=\"font-size: 20px;\"><strong>retretretretre</strong></span></p>'
WHERE `id` = '54321'
ERROR - 2025-01-23 14:39:49 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 14:39:49 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 14:40:16 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 14:40:16 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 14:40:38 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 14:40:38 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 14:40:47 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 14:40:47 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 14:41:18 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 14:41:18 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 14:41:25 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 14:41:25 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 14:41:40 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 14:41:40 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 14:41:47 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-01-23 14:41:47 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 14:42:44 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-01-23 14:42:44 --> 404 Page Not Found: Js/chart.umd.js.map
