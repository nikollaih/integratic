<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-09-04 15:27:10 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-09-04 15:27:10 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-09-04 15:27:10 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-09-04 15:27:10 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-09-04 15:27:10 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-09-04 15:27:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:10 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:11 --> 404 Page Not Found: Images/small
ERROR - 2024-09-04 15:27:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 15:27:18 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 15:27:19 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 15:27:19 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 15:27:20 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 70
ERROR - 2024-09-04 15:27:24 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 15:27:24 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 15:27:30 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 15:27:30 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 15:27:30 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:30 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:30 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:30 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:32 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 15:27:32 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 15:27:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:32 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 15:27:35 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.u.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `u`.*, `e`.*, `e`.`email` as `email`, `cer_responses`.`caracterizacion_respuestas`
FROM `estudiante` `e`
LEFT JOIN `usuarios` `u` ON `e`.`documento` = `u`.`id`
LEFT OUTER JOIN (SELECT `cer`.`id_estudiante`, JSON_ARRAYAGG(JSON_OBJECT("id_pregunta", `cer`.`id_pregunta`, "respuesta", cer.respuesta)) as caracterizacion_respuestas
FROM `caracterizacion_estudiantes_respuestas` `cer`
GROUP BY `cer`.`id_estudiante`) as cer_responses ON `cer_responses`.`id_estudiante` = `u`.`id`
GROUP BY `e`.`documento`
ORDER BY `e`.`grado` ASC, `e`.`nombre` ASC
ERROR - 2024-09-04 15:27:59 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-09-04 15:30:01 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-09-04 15:30:02 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-09-04 15:30:29 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-09-04 15:31:06 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-09-04 15:31:22 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-09-04 15:31:28 --> 404 Page Not Found: CaracterizacionEstudiantes/index.php
ERROR - 2024-09-04 15:33:52 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2024-09-04 15:33:52 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2024-09-04 16:05:24 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 16:05:24 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 16:05:26 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 70
ERROR - 2024-09-04 16:06:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 16:06:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 16:06:27 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 70
ERROR - 2024-09-04 18:22:51 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-09-04 18:22:51 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-09-04 18:22:51 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-09-04 18:22:51 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-09-04 18:22:51 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-09-04 18:22:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:22:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:22:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:22:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:22:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:22:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:22:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:22:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:22:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:22:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:22:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:22:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:22:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:22:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:22:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:22:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:22:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:22:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:22:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:22:51 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:22:52 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:32:45 --> 404 Page Not Found: Images/small
ERROR - 2024-09-04 18:32:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 18:32:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 18:32:48 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 18:32:48 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 18:32:48 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 70
ERROR - 2024-09-04 18:41:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 18:41:26 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 18:45:51 --> Severity: Notice --> Undefined variable: semanas /Applications/MAMP/htdocs/integratic/application/views/plan_aula/evidencias_aprendizaje.php 70
ERROR - 2024-09-04 18:49:33 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 18:49:33 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 18:49:37 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-09-04 18:49:37 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2024-09-04 18:49:37 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-09-04 18:49:37 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2024-09-04 18:49:37 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-09-04 18:49:37 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2024-09-04 18:49:37 --> Severity: Warning --> Illegal string offset 'rol' /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-09-04 18:49:37 --> Severity: Notice --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2024-09-04 18:49:37 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2024-09-04 18:49:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:49:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:49:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:49:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:49:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:49:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:49:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:49:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:49:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:49:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:49:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:49:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:49:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:49:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:49:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:49:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:49:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:49:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:49:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:49:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:49:37 --> 404 Page Not Found: Img/botones
ERROR - 2024-09-04 18:49:38 --> 404 Page Not Found: Images/small
ERROR - 2024-09-04 18:49:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 18:49:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 18:49:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 18:49:45 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 18:49:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 18:49:47 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 18:49:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 18:49:50 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 18:50:28 --> 404 Page Not Found: Img/iconos
ERROR - 2024-09-04 18:50:28 --> 404 Page Not Found: Img/iconos
