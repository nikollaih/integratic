<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-03-21 09:09:43 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 14
ERROR - 2025-03-21 09:09:43 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 18
ERROR - 2025-03-21 09:09:43 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 27
ERROR - 2025-03-21 09:09:43 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/controllers/Notificaciones.php 31
ERROR - 2025-03-21 09:09:43 --> 404 Page Not Found: Img/banner%20ie%20integratic%20hosting%201.png
ERROR - 2025-03-21 09:09:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-21 09:09:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-21 09:09:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-21 09:09:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-21 09:09:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-21 09:09:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-21 09:09:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-21 09:09:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-21 09:09:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-21 09:09:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-21 09:09:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-21 09:09:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-21 09:09:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-21 09:09:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-21 09:09:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-21 09:09:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-21 09:09:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-21 09:09:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-21 09:09:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-21 09:09:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-21 09:09:43 --> 404 Page Not Found: Img/botones
ERROR - 2025-03-21 09:09:47 --> 404 Page Not Found: Images/small
ERROR - 2025-03-21 09:09:55 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-21 09:09:56 --> 404 Page Not Found: Img/iconos
ERROR - 2025-03-21 09:10:02 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'integratic.am.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT *
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE `am`.`docente` = '12345'
GROUP BY `am`.`materia`
ORDER BY `cm`.`nommateria` ASC, `am`.`grupo` ASC
ERROR - 2025-03-21 09:10:28 --> 404 Page Not Found: EstadisticasPruebas/index.php
ERROR - 2025-03-21 09:11:05 --> 404 Page Not Found: EstadisticasPruebas/index.php
ERROR - 2025-03-21 09:13:34 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:13:35 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:15:07 --> Severity: Notice --> Undefined variable: params /Applications/MAMP/htdocs/integratic/application/views/pruebas/simulacros/index.php 60
ERROR - 2025-03-21 09:15:08 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:15:08 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:15:48 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:15:48 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:16:52 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:16:52 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:19:45 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:19:45 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:19:53 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:19:53 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:20:52 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:20:52 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:22:10 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:22:10 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:22:24 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:22:25 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:26:42 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:26:42 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:26:43 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:26:43 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:27:00 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:27:00 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:27:03 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:27:03 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:27:55 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:27:55 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:28:24 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:28:24 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:29:30 --> 404 Page Not Found: EstadisticasPruebas/index.php
ERROR - 2025-03-21 09:29:38 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 110
ERROR - 2025-03-21 09:29:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 268
ERROR - 2025-03-21 09:29:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 269
ERROR - 2025-03-21 09:29:39 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 270
ERROR - 2025-03-21 09:29:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-21 09:29:45 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 110
ERROR - 2025-03-21 09:29:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 268
ERROR - 2025-03-21 09:29:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 269
ERROR - 2025-03-21 09:29:46 --> Severity: Notice --> Trying to access array offset on value of type bool /Applications/MAMP/htdocs/integratic/application/controllers/Pruebas.php 270
ERROR - 2025-03-21 09:29:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`' at line 4 - Invalid query: SELECT `cm`.`codmateria`, `cm`.`nommateria`, `am`.`grupo`, `cm`.`grado`, `cm`.`area`
FROM `asg_materias` `am`
JOIN `cfg_materias` `cm` ON `am`.`materia` = `cm`.`codmateria`
WHERE cm.codmateria IN()
GROUP BY `cm`.`codmateria`, `cm`.`grado`, `am`.`grupo`
ERROR - 2025-03-21 09:32:52 --> Severity: Notice --> Undefined variable: data_estudiante /Applications/MAMP/htdocs/integratic/application/views/pruebas/simulacros/index.php 60
ERROR - 2025-03-21 09:36:08 --> Severity: error --> Exception: Call to undefined method Realizar_Prueba_Model::get_by_participante_materia_tipo() /Applications/MAMP/htdocs/integratic/application/controllers/Simulacros.php 27
ERROR - 2025-03-21 09:40:15 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/integratic/application/views/pruebas/simulacros/index.php 83
ERROR - 2025-03-21 09:40:21 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:40:21 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:40:57 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:40:57 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:41:27 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:41:28 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:41:40 --> Severity: Notice --> Undefined variable: pruebas /Applications/MAMP/htdocs/integratic/application/views/pruebas/simulacros/index.php 83
ERROR - 2025-03-21 09:41:40 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:41:41 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:42:02 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/integratic/application/views/pruebas/simulacros/index.php 83
ERROR - 2025-03-21 09:42:03 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:42:03 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:42:26 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/integratic/application/views/pruebas/simulacros/index.php 83
ERROR - 2025-03-21 09:42:27 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:42:27 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:42:35 --> Severity: Notice --> Undefined variable: pruebas /Applications/MAMP/htdocs/integratic/application/views/pruebas/simulacros/index.php 83
ERROR - 2025-03-21 09:42:35 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/integratic/application/views/pruebas/simulacros/index.php 83
ERROR - 2025-03-21 09:42:35 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:42:35 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:43:16 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:43:16 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:43:36 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:43:36 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:43:59 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:43:59 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:44:11 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:44:11 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:44:17 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:44:17 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:48:13 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:48:13 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:48:32 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:48:32 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:49:06 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:49:06 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:49:22 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:49:22 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:49:26 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:49:26 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:49:37 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:49:37 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:50:16 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:50:16 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:50:33 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:50:33 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:51:23 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:51:23 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:51:28 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:51:28 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:51:38 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:51:38 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:51:43 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:51:43 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:52:02 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:52:02 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:52:19 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:52:19 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:56:49 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:56:49 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:57:11 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:57:11 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:58:52 --> Severity: Notice --> Undefined index: participate /Applications/MAMP/htdocs/integratic/application/views/pruebas/simulacros/index.php 38
ERROR - 2025-03-21 09:58:52 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/pruebas/simulacros/index.php 38
ERROR - 2025-03-21 09:58:52 --> Severity: Notice --> Undefined index: participate /Applications/MAMP/htdocs/integratic/application/views/pruebas/simulacros/index.php 38
ERROR - 2025-03-21 09:58:52 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/pruebas/simulacros/index.php 38
ERROR - 2025-03-21 09:58:53 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:58:53 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:59:09 --> Severity: Notice --> Undefined index: participate /Applications/MAMP/htdocs/integratic/application/views/pruebas/simulacros/index.php 38
ERROR - 2025-03-21 09:59:09 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/pruebas/simulacros/index.php 38
ERROR - 2025-03-21 09:59:09 --> Severity: Notice --> Undefined index: nombre /Applications/MAMP/htdocs/integratic/application/views/pruebas/simulacros/index.php 38
ERROR - 2025-03-21 09:59:10 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:59:10 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 09:59:36 --> Severity: Notice --> Undefined index: participate /Applications/MAMP/htdocs/integratic/application/views/pruebas/simulacros/index.php 38
ERROR - 2025-03-21 09:59:36 --> Severity: Notice --> Trying to access array offset on value of type null /Applications/MAMP/htdocs/integratic/application/views/pruebas/simulacros/index.php 38
ERROR - 2025-03-21 09:59:36 --> Severity: Notice --> Undefined index: nombre /Applications/MAMP/htdocs/integratic/application/views/pruebas/simulacros/index.php 38
ERROR - 2025-03-21 09:59:37 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 09:59:37 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 10:00:25 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 10:00:25 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 10:00:40 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 10:00:40 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 10:00:51 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 10:00:51 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 10:04:38 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 10:04:38 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 10:10:20 --> Severity: Notice --> Undefined index: temas /Applications/MAMP/htdocs/integratic/application/views/pruebas/simulacros/index.php 49
ERROR - 2025-03-21 10:10:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/views/pruebas/simulacros/index.php 49
ERROR - 2025-03-21 10:10:37 --> Severity: Notice --> Undefined index: temas /Applications/MAMP/htdocs/integratic/application/views/pruebas/simulacros/index.php 50
ERROR - 2025-03-21 10:10:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /Applications/MAMP/htdocs/integratic/application/views/pruebas/simulacros/index.php 50
ERROR - 2025-03-21 10:10:42 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 10:10:42 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 10:11:03 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 10:11:03 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 10:11:20 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 10:11:20 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 10:11:30 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 10:11:30 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 10:20:13 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 10:20:13 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 10:20:46 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 10:20:46 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 10:22:17 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/integratic/application/controllers/Simulacros.php 32
ERROR - 2025-03-21 10:22:27 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 10:22:27 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 10:22:50 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 10:22:50 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 10:23:25 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 10:23:25 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 10:23:31 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 10:23:31 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 10:23:40 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 10:23:40 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 10:24:42 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 10:24:42 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 10:24:54 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 10:24:54 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 10:25:00 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 10:25:00 --> 404 Page Not Found: Js/chart.umd.js.map
ERROR - 2025-03-21 10:25:06 --> 404 Page Not Found: Js/bootstrap-select.min.js.map
ERROR - 2025-03-21 10:25:06 --> 404 Page Not Found: Js/chart.umd.js.map
